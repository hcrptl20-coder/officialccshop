#!/bin/bash
awk '
/app.get\('\''\/api\/deposit\/generate-qr'\''/ {
    print $0
    getline
    print $0
    getline
    print $0
    print "  if (config.useStaticQr && config.staticQrUrl) {"
    print "    return res.json({ qrDataUrl: config.staticQrUrl, upiString: `upi://pay?pa=${config.upiId}&pn=${encodeURIComponent(config.merchantName)}&cu=INR` });"
    print "  }"
    next
}
{ print }
' server.ts > server_patched.ts
mv server_patched.ts server.ts
