#!/bin/bash
sed -i 's|<Smartphone className="w-5 h-5" />|<img src="/assets/upi.svg" alt="UPI" className="w-6 h-6 object-contain filter invert opacity-90" />|g' src/components/deposit/UpiAppLaunchers.tsx
