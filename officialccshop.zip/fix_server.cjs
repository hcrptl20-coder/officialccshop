const fs = require('fs');
let content = fs.readFileSync('server.ts', 'utf8');

content = content.replace(
  /const userSessions = db\.getDatabase\(\)\.sessions\.filter\(s => s\.userId === activeUser\.id\);\s*const token = req\.sessionToken \|\| \(userSessions\.length > 0 \? userSessions\[0\]\.id : null\);/,
  'const token = req.sessionToken || null;'
);

fs.writeFileSync('server.ts', content);
