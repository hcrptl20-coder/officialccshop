const fs = require('fs');
let content = fs.readFileSync('server.ts', 'utf8');

const target = `    if (defaultUser && defaultUser.status !== 'suspended') {
      const ip = req.ip || '127.0.0.1';
      const token = auth.generateToken();
      db.createSession(defaultUser.id, token, req.headers['user-agent'], ip);
      auth.setSessionCookie(res, token);
      activeUser = defaultUser;
    }
  }

  if (!activeUser) {
    return res.json({ user: null });
  }

  const { passwordHash, ...safeUser } = activeUser;
  const unreadNotifs = db.getNotificationsByUser(activeUser.id).filter((n) => !n.isRead).length;
  res.json({
    user: safeUser,
    unreadNotifications: unreadNotifs,
  });
});`;

const replacement = `    if (defaultUser && defaultUser.status !== 'suspended') {
      const ip = req.ip || '127.0.0.1';
      const token = auth.generateToken();
      db.createSession(defaultUser.id, token, req.headers['user-agent'], ip);
      auth.setSessionCookie(res, token);
      req.sessionToken = token; // Save token on req so we can send it
      activeUser = defaultUser;
    }
  }

  if (!activeUser) {
    return res.json({ user: null });
  }

  const { passwordHash, ...safeUser } = activeUser;
  const unreadNotifs = db.getNotificationsByUser(activeUser.id).filter((n) => !n.isRead).length;
  res.json({
    user: safeUser,
    token: req.sessionToken, // Pass token to frontend
    unreadNotifications: unreadNotifs,
  });
});`;

content = content.replace(target, replacement);
fs.writeFileSync('server.ts', content);
