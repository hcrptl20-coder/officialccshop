#!/bin/bash
sed -i 's|<Smartphone className="w-4 h-4 text-purple-400 group-hover:text-purple-300 transition-colors" />|<img src="/assets/upi.svg" alt="UPI" className="w-6 h-6 object-contain" />|g' src/components/cards/CardDetailModal.tsx
sed -i 's|<span className="text-orange-400 font-black text-lg group-hover:text-orange-300 transition-colors">a</span>|<img src="/assets/amazon.svg" alt="Amazon" className="w-5 h-5 object-contain" />|g' src/components/cards/CardDetailModal.tsx
sed -i 's|<span className="text-blue-400 font-black text-lg group-hover:text-blue-300 transition-colors">f</span>|<img src="/assets/flipkart.png" alt="Flipkart" className="w-5 h-5 object-contain rounded-md" />|g' src/components/cards/CardDetailModal.tsx
