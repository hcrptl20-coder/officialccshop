const fs = require('fs');
let content = fs.readFileSync('src/App.tsx', 'utf8');

// Remove the direct auto-login fallback
content = content.replace(/\/\/ Direct auto-login fallback: ensures zero verification or login page blocks access[\s\S]*?}, \[user, isLoading, oneClickLogin, demoLogin\]\);/, '');

fs.writeFileSync('src/App.tsx', content);
