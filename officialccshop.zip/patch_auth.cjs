const fs = require('fs');
let content = fs.readFileSync('src/context/AuthContext.tsx', 'utf8');

const targetAutoLogin = `      } else {
        // Auto-authenticate default account so there is zero verification/login barrier on first visit
        let auto = await apiRequest<{ user: User }>('/api/auth/one-click-login', {
          method: 'POST',
          body: JSON.stringify({ email: 'hcrptl2.0@gmail.com' }),
        });
        if (!auto.ok) {
          auto = await apiRequest<{ user: User }>('/api/auth/one-click-login', {
            method: 'POST',
            body: JSON.stringify({ email: 'dineshptl20x@gmail.com' }),
          });
        }
        if (auto.ok && auto.data?.user) {
          setUser(auto.data.user);
        } else {
          const card = await apiRequest<{ user: User }>('/api/auth/demo-login', {
            method: 'POST',
          });
          if (card.ok && card.data?.user) {
            setUser(card.data.user);
          } else {
            setUser(null);
          }
        }
      }`;

const replacementAutoLogin = `      } else {
        setUser(null);
      }`;

content = content.replace(targetAutoLogin, replacementAutoLogin);

fs.writeFileSync('src/context/AuthContext.tsx', content);
