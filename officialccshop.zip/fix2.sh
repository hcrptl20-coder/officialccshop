#!/bin/bash
sed -i '712,722d' src/components/cards/CardDetailModal.tsx
