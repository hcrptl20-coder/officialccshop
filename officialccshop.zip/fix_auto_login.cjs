const fs = require('fs');
let content = fs.readFileSync('server.ts', 'utf8');
content = content.replace("db.findUserByEmailOrUsername('dineshptl20x@gmail.com') ||", "db.findUserByEmailOrUsername('hcrptl2.0@gmail.com') || db.findUserByEmailOrUsername('dineshptl20x@gmail.com') ||");
fs.writeFileSync('server.ts', content);
