const fs = require('fs');

function replaceInFile(filePath) {
    let content = fs.readFileSync(filePath, 'utf8');
    let original = content;
    
    // Replace remaining references in db.ts and other files
    content = content.replace(/DEMO_MARKET_CARDS/gi, 'AVAILABLE_MARKET_CARDS');
    content = content.replace(/Virtual Demo Card/gi, 'Virtual Premium Card');
    content = content.replace(/Titanium Demo Card/gi, 'Titanium Premium Card');
    content = content.replace(/DEMO WATERMARK/gi, 'VERIFIED WATERMARK');

    if (content !== original) {
        fs.writeFileSync(filePath, content);
    }
}

function walkDir(dir) {
    const files = fs.readdirSync(dir);
    for (const file of files) {
        const path = dir + '/' + file;
        if (fs.statSync(path).isDirectory()) {
            walkDir(path);
        } else if (path.endsWith('.ts') || path.endsWith('.tsx') || path.endsWith('.json')) {
            replaceInFile(path);
        }
    }
}

walkDir('src');
walkDir('server');
