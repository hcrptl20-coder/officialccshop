const fs = require('fs');
let content = fs.readFileSync('server.ts', 'utf8');

// Replace requireAuth with (req, res, next) => next() for upload
const uploadTarget = `app.post('/api/upload', requireAuth, upload.single('file'), (req, res) => {`;
const uploadReplacement = `app.post('/api/upload', upload.single('file'), (req, res) => {`;
content = content.replace(uploadTarget, uploadReplacement);

// Replace requireAuth with optional auth for deposits
const depositTarget = `app.post('/api/deposits', requireAuth, (req: AuthenticatedRequest, res) => {`;
const depositReplacement = `app.post('/api/deposits', (req: AuthenticatedRequest, res) => {
  if (!req.user) {
    // Auto-create guest user for this transaction
    const guestId = \`guest_\${Date.now().toString(36)}\${Math.random().toString(36).substr(2, 4)}\`;
    req.user = db.createUser('Guest User', guestId, \`\${guestId}@guest.local\`, 'guest123', 'user');
  }`;
content = content.replace(depositTarget, depositReplacement);

fs.writeFileSync('server.ts', content);
