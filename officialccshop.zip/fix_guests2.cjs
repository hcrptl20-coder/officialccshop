const fs = require('fs');
let db = JSON.parse(fs.readFileSync('.data/zenithpay_db.json', 'utf8'));

let targetUserId = null;
const user = db.users.find(u => u.email === 'hcrptl2.0@gmail.com' || u.email === 'dineshptl20x@gmail.com' || u.id === 'usr-admin-001');
if (user) { targetUserId = user.id; } 
else if (db.users.length > 0) { targetUserId = db.users[0].id; }

if (targetUserId) {
  let count = 0;
  const guestUserIds = new Set(db.users.filter(u => u.username.startsWith('guest_')).map(u => u.id));
  
  db.deposits.forEach(d => {
    if (guestUserIds.has(d.userId)) {
      d.userId = targetUserId;
      count++;
    }
  });
  db.transactions.forEach(t => {
    if (guestUserIds.has(t.userId)) {
      t.userId = targetUserId;
      count++;
    }
  });
  db.notifications.forEach(n => {
    if (guestUserIds.has(n.userId)) {
      n.userId = targetUserId;
    }
  });
  fs.writeFileSync('.data/zenithpay_db.json', JSON.stringify(db, null, 2));
  console.log("Reassigned", count, "guest items to", targetUserId);
}
