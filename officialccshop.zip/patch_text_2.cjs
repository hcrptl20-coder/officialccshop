const fs = require('fs');

function replaceInFile(filePath) {
    let content = fs.readFileSync(filePath, 'utf8');
    let original = content;
    
    // Replace remaining references in db.ts and other files
    content = content.replace(/Demo Card/gi, 'Card');
    content = content.replace(/Purchased Demo/gi, 'Purchased');
    content = content.replace(/Virtual Demo/gi, 'Virtual');
    content = content.replace(/Titanium Demo/gi, 'Titanium');
    content = content.replace(/demoId/gi, 'cardCode'); 

    if (content !== original) {
        fs.writeFileSync(filePath, content);
    }
}

function walkDir(dir) {
    const files = fs.readdirSync(dir);
    for (const file of files) {
        const path = dir + '/' + file;
        if (fs.statSync(path).isDirectory()) {
            walkDir(path);
        } else if (path.endsWith('.ts') || path.endsWith('.tsx') || path.endsWith('.json')) {
            replaceInFile(path);
        }
    }
}

walkDir('src');
walkDir('server');
