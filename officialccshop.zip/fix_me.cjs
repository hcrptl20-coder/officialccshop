const fs = require('fs');
let content = fs.readFileSync('server.ts', 'utf8');

content = content.replace(/res\.json\(\{\n\s*user: safeUser,\n\s*unreadNotifications: unreadNotifs,\n\s*\}\);/g, 
  `const userSessions = db.getDatabase().sessions.filter(s => s.userId === activeUser.id);
  const token = req.sessionToken || (userSessions.length > 0 ? userSessions[0].id : null);
  res.json({
    user: safeUser,
    token: token,
    unreadNotifications: unreadNotifs,
  });`);

fs.writeFileSync('server.ts', content);
