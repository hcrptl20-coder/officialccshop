const fs = require('fs');
let content = fs.readFileSync('server/db.ts', 'utf8');
content = content.replace('data.demoCards.push(demoCard);', 'data.cardCards.push(cardCard);');
fs.writeFileSync('server/db.ts', content);
