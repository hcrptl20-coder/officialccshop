#!/bin/bash
cat << 'INNER_EOF' > src/App.tsx.patch
--- src/App.tsx
+++ src/App.tsx
@@ -194,15 +194,22 @@
       .then(data => {
         if (data.clientId) setClientId(data.clientId);
       })
       .catch(console.error);
   }, []);
 
-  if (!clientId) {
+  const [isReady, setIsReady] = useState(false);
+  useEffect(() => {
+    const timer = setTimeout(() => setIsReady(true), 500);
+    return () => clearTimeout(timer);
+  }, []);
+
+  if (!clientId && !isReady) {
     return (
       <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center text-white">
         <p className="text-xs font-mono uppercase tracking-widest text-slate-400">
           Initializing Auth...
         </p>
       </div>
     );
   }
 
+  if (!clientId) {
+    return (
+      <AuthProvider>
+        <AppContent />
+      </AuthProvider>
+    );
+  }
+
   return (
     <GoogleOAuthProvider clientId={clientId}>
       <AuthProvider>
INNER_EOF
patch src/App.tsx src/App.tsx.patch
