const fs = require('fs');
let content = fs.readFileSync('server/db.ts', 'utf8');

const target = `      dbCache = JSON.parse(fileData);
      if (dbCache) {`;
const replacement = `      dbCache = JSON.parse(fileData);
      if (dbCache) {
        dbCache.cardCards = dbCache.cardCards || dbCache.demoCards || [];
        dbCache.users = dbCache.users || [];
        dbCache.sessions = dbCache.sessions || [];
        dbCache.deposits = dbCache.deposits || [];
        dbCache.transactions = dbCache.transactions || [];
        dbCache.supportTickets = dbCache.supportTickets || [];
        dbCache.notifications = dbCache.notifications || [];
        dbCache.auditLogs = dbCache.auditLogs || [];`;
content = content.replace(target, replacement);

fs.writeFileSync('server/db.ts', content);
