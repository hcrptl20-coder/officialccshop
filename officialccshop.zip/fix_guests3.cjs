const fs = require('fs');
let db = JSON.parse(fs.readFileSync('.data/zenithpay_db.json', 'utf8'));

const targetUserId = 'usr-1788675939808-34n98e';

let count = 0;
const guestUserIds = new Set(db.users.filter(u => u.username.startsWith('guest_')).map(u => u.id));
// Wait, in fix_guests2.cjs I reassigned to 'usr-admin-001'.
// Let's also reassign everything that has 'usr-admin-001' to 'usr-1788675939808-34n98e' just in case.

guestUserIds.add('usr-admin-001');

db.deposits.forEach(d => {
if (guestUserIds.has(d.userId)) {
    d.userId = targetUserId;
    count++;
}
});
db.transactions.forEach(t => {
if (guestUserIds.has(t.userId)) {
    t.userId = targetUserId;
    count++;
}
});
db.notifications.forEach(n => {
if (guestUserIds.has(n.userId)) {
    n.userId = targetUserId;
}
});

fs.writeFileSync('.data/zenithpay_db.json', JSON.stringify(db, null, 2));
console.log("Reassigned", count, "guest/admin001 items to", targetUserId);

