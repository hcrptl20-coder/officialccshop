const fs = require('fs');
let content = fs.readFileSync('server/db.ts', 'utf8');

const target = `        // Enforce Airtel Payments Bank QR settings requested by user
        dbCache.settings = {
          qrImagePath: '/merchant-qr.png',
          useStaticQr: false,
          staticQrUrl: "",
          upiId: 'davidtl@axl',
          displayUpiId: 'davidtl@axl',
          merchantName: 'Airtel Payments Bank Limited - 9115',
          paymentInstructions:
            '1. Scan the Airtel Payments Bank QR code or tap any UPI app below to pay securely.\\n2. Complete payment via PhonePe, GPay, Paytm, or BHIM.\\n3. Copy the 12-digit UPI UTR / Reference number from your app.\\n4. Enter the UTR number and click Submit Deposit Request.',
          updatedAt: new Date().toISOString(),
        };`;

const replacement = `        // Keep saved custom QR settings or initialize defaults
        if (!dbCache.settings) {
          dbCache.settings = {
            qrImagePath: '/merchant-qr.png',
            useStaticQr: false,
            staticQrUrl: "",
            upiId: 'davidtl@axl',
            displayUpiId: 'davidtl@axl',
            merchantName: 'UPI Official Merchant',
            paymentInstructions:
              '1. Scan the QR code or tap any UPI app below to pay securely.\\n2. Complete payment via PhonePe, GPay, Paytm, or BHIM.\\n3. Copy the 12-digit UPI UTR / Reference number from your app.\\n4. Enter the UTR number and click Submit Deposit Request.',
            updatedAt: new Date().toISOString(),
          };
        }`;

if (content.includes(target)) {
  content = content.replace(target, replacement);
  fs.writeFileSync('server/db.ts', content);
  console.log("Replaced settings enforcement in server/db.ts");
} else {
  console.log("Target not found in server/db.ts");
}
