const fs = require('fs');
let content = fs.readFileSync('src/App.tsx', 'utf8');

const replacement = `export default function App() {
  const [clientId, setClientId] = useState<string>('');
  const [isReady, setIsReady] = useState(false);

  useEffect(() => {
    fetch('/api/auth/client-id')
      .then(res => res.json())
      .then(data => {
        if (data.clientId) setClientId(data.clientId);
      })
      .catch(console.error)
      .finally(() => setIsReady(true));
  }, []);

  if (!isReady && !clientId) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center text-white">
        <p className="text-xs font-mono uppercase tracking-widest text-slate-400">
          Initializing Auth...
        </p>
      </div>
    );
  }

  if (!clientId) {
    return (
      <AuthProvider>
        <AppContent />
      </AuthProvider>
    );
  }

  return (
    <GoogleOAuthProvider clientId={clientId}>
      <AuthProvider>
        <AppContent />
      </AuthProvider>
    </GoogleOAuthProvider>
  );
}`;

content = content.replace(/export default function App\(\) \{[\s\S]*/, replacement);
fs.writeFileSync('src/App.tsx', content);
