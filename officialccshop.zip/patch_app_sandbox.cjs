const fs = require('fs');

let content = fs.readFileSync('src/App.tsx', 'utf8');

const target = `      {/* Floating Sandbox Quick Role Switcher Bar at Bottom */}`;
const endTarget = `      </aside>`;
const startIndex = content.indexOf(target);
const endIndex = content.indexOf(endTarget) + endTarget.length;

if (startIndex !== -1 && endIndex !== -1) {
  content = content.substring(0, startIndex) + content.substring(endIndex);
  fs.writeFileSync('src/App.tsx', content);
}

