#!/bin/bash
awk '
/app.get\('\''\/api\/deposit\/generate-qr'\''/ {
    print "app.get(\"/api/settings\", (req, res) => {"
    print "  res.json(db.getPaymentConfig());"
    print "});"
    print ""
    print "app.post(\"/api/settings\", express.json(), (req, res) => {"
    print "  const authHeader = req.headers.authorization;"
    print "  if (!authHeader || !authHeader.startsWith(\"Bearer \")) return res.status(401).json({ error: \"Unauthorized\" });"
    print "  const token = authHeader.split(\" \")[1];"
    print "  const user = db.getUserBySession(token);"
    print "  if (!user || user.role !== \"admin\") return res.status(403).json({ error: \"Forbidden\" });"
    print "  db.updatePaymentConfig(req.body);"
    print "  res.json({ success: true });"
    print "});"
    print ""
    print "app.post(\"/api/settings/upload-qr\", upload.single(\"qrImage\"), (req, res) => {"
    print "  const authHeader = req.headers.authorization;"
    print "  if (!authHeader || !authHeader.startsWith(\"Bearer \")) return res.status(401).json({ error: \"Unauthorized\" });"
    print "  const token = authHeader.split(\" \")[1];"
    print "  const user = db.getUserBySession(token);"
    print "  if (!user || user.role !== \"admin\") return res.status(403).json({ error: \"Forbidden\" });"
    print "  if (!req.file) return res.status(400).json({error: \"no file\"});"
    print "  const url = `/uploads/${req.file.filename}`;"
    print "  db.updatePaymentConfig({ staticQrUrl: url, useStaticQr: true });"
    print "  res.json({ url });"
    print "});"
    print ""
    print $0
    next
}
{ print }
' server.ts > server_patched.ts
mv server_patched.ts server.ts
