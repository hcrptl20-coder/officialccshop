const fs = require('fs');

let content = fs.readFileSync('src/pages/user/CardsPage.tsx', 'utf8');

// The original paragraph text to be replaced
const targetText = 'Select and purchase high-limit virtual card cards in real-time. Prices are paired in USD and INR (₹94.49 = $1 USD). Instant sandbox credentials with verified billing addresses.';

// The replacement text inside an animated, gradient-styled paragraph
const replacementHtml = `<span className="inline-block bg-gradient-to-r from-cyan-400 via-purple-400 to-pink-400 bg-clip-text text-transparent font-extrabold animate-gradient-x text-base tracking-wide drop-shadow-sm">All Premium and Virtual Cards</span>`;

content = content.replace(targetText, replacementHtml);

fs.writeFileSync('src/pages/user/CardsPage.tsx', content);
