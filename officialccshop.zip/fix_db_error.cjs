const fs = require('fs');

let content = fs.readFileSync('server/db.ts', 'utf8');

const duplicateBlock = `    // Notify Admins
    const admins = data.users.filter(u => u.role === 'admin');
    admins.forEach(admin => {
      data.notifications.unshift({
        id: \`notif-admin-\${Date.now()}-\${Math.random()}\`,
        userId: admin.id,
        title: isCardBuy ? \`New Card Purchase (Pending)\` : \`New Deposit Request\`,
        message: \`User \${user?.username} submitted a \${isCardBuy ? 'card purchase' : 'deposit'} for ₹\${amount.toFixed(2)} via \${referenceNo}.\`,
        type: 'system',
        isRead: false,
        createdAt: new Date().toISOString(),
      });
    });

`;

content = content.replace(duplicateBlock, '');

// But wait, there is another injection I did in purchaseCard which might conflict if there was also an admin notification there.
// Let's check around line 737 for purchaseCard
fs.writeFileSync('server/db.ts', content);
