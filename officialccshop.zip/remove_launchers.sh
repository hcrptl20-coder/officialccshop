#!/bin/bash
sed -i '/import { UpiAppLaunchers }/d' src/pages/user/DepositPage.tsx
sed -i '256,264d' src/pages/user/DepositPage.tsx
