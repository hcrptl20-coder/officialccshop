const fs = require('fs');

function replaceInFile(filePath) {
    let content = fs.readFileSync(filePath, 'utf8');
    let original = content;
    
    // UI replacements
    content = content.replace(/DEMO CARD • TEST ONLY/gi, 'PREMIUM CARD • VERIFIED');
    content = content.replace(/ACTIVE — DEMO/gi, 'ACTIVE — VERIFIED');
    content = content.replace(/DEMO USER/g, 'VALUED USER');
    content = content.replace(/Cardholder Name \(DEMO\)/g, 'Cardholder Name');
    content = content.replace(/Search by DEMO ID \(e\.g\. DEMO-0001\)/g, 'Search by Card ID (e.g. CRD-0001)');
    content = content.replace(/"id": "DEMO-/g, '"id": "CRD-');
    content = content.replace(/TXN-DEMO-/g, 'TXN-00');

    if (content !== original) {
        fs.writeFileSync(filePath, content);
    }
}

function walkDir(dir) {
    const files = fs.readdirSync(dir);
    for (const file of files) {
        const path = dir + '/' + file;
        if (fs.statSync(path).isDirectory()) {
            walkDir(path);
        } else if (path.endsWith('.ts') || path.endsWith('.tsx') || path.endsWith('.json')) {
            replaceInFile(path);
        }
    }
}

walkDir('src');
walkDir('server');
