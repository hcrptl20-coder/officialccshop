const fs = require('fs');
let content = fs.readFileSync('src/pages/user/DashboardPage.tsx', 'utf8');

if (!content.includes('Sparkles,') && content.includes('lucide-react')) {
  content = content.replace("} from 'lucide-react';", "  Sparkles,\n} from 'lucide-react';");
}

fs.writeFileSync('src/pages/user/DashboardPage.tsx', content);
