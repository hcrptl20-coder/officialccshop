const fs = require('fs');

let content = fs.readFileSync('src/pages/user/SupportPage.tsx', 'utf8');

// Remove Instagram from imports
content = content.replace(/  Instagram,\n/g, '');

// Remove Instagram block from the array
const instaRegex = /\s*{\s*id:\s*'instagram'[\s\S]*?},\n/g;
content = content.replace(instaRegex, '');

fs.writeFileSync('src/pages/user/SupportPage.tsx', content);
