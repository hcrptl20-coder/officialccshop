const fs = require('fs');
let content = fs.readFileSync('server.ts', 'utf8');

const target = `// Register`;
const replacement = `// Guest Auto-Login
app.post('/api/auth/guest-login', (req, res) => {
  const ip = req.ip || '127.0.0.1';
  
  // Create a unique guest user
  const guestId = \`guest_\${Date.now().toString(36)}\${Math.random().toString(36).substr(2, 4)}\`;
  const username = guestId;
  const email = \`\${guestId}@guest.local\`;
  
  const user = db.createUser('Guest User', username, email, 'guest123', 'user');
  
  const token = auth.generateToken();
  db.createSession(user.id, token, req.headers['user-agent'], ip);
  auth.setSessionCookie(res, token);
  
  const { passwordHash, ...safeUser } = user;
  res.json({
    message: 'Signed in as Guest',
    user: safeUser,
    token,
  });
});

// Register`;

content = content.replace(target, replacement);
fs.writeFileSync('server.ts', content);
