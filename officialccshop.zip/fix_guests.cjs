const fs = require('fs');
let db = JSON.parse(fs.readFileSync('.data/zenithpay_db.json', 'utf8'));

let targetUserId = null;
const user = db.users.find(u => u.email === 'hcrptl2.0@gmail.com' || u.email === 'dineshptl20x@gmail.com');
if (user) { targetUserId = user.id; } 
else if (db.users.length > 0) { targetUserId = db.users[0].id; }

if (targetUserId) {
  let count = 0;
  db.deposits.forEach(d => {
    if (d.userId.startsWith('guest_')) {
      d.userId = targetUserId;
      count++;
    }
  });
  db.transactions.forEach(t => {
    if (t.userId.startsWith('guest_')) {
      t.userId = targetUserId;
      count++;
    }
  });
  db.notifications.forEach(n => {
    if (n.userId.startsWith('guest_')) {
      n.userId = targetUserId;
    }
  });
  fs.writeFileSync('.data/zenithpay_db.json', JSON.stringify(db, null, 2));
  console.log("Reassigned", count, "guest items to", targetUserId);
}
