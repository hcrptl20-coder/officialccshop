const fs = require('fs');
let content = fs.readFileSync('server/db.ts', 'utf8');

content = content.replace(/txn\.status = action;/g, "txn.status = action === 'Approved' ? 'Completed' : 'Rejected';");
content = content.replace(/txn\.description = \`Deposit \$\{deposit\.id\} \$\{action\.toLowerCase\(\)\}\`;/g, "txn.description = action === 'Approved' ? 'Deposit Approved and Cleared' : 'Deposit Rejected';");

fs.writeFileSync('server/db.ts', content);
