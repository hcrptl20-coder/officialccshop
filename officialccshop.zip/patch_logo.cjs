const fs = require('fs');
let content = fs.readFileSync('src/components/layout/Navbar.tsx', 'utf8');

const target = `            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-lg font-black tracking-tighter text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-blue-400 to-indigo-500 drop-shadow-sm">
                  Official<span className="text-white">CC</span>Shop
                </span>
                <span className="px-1.5 py-0.2 rounded text-[9px] font-bold tracking-wide uppercase bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                  Fintech
                </span>
              </div>
              <p className="text-[10px] text-slate-400 hidden sm:block -mt-0.5">
                Virtual Cards & Settlement
              </p>
            </div>`;

const replacement = `            <div>
              <div className="flex items-center gap-2">
                <span className="text-xl font-black tracking-widest uppercase drop-shadow-md flex items-center">
                  <span className="text-transparent bg-clip-text bg-gradient-to-r from-white to-slate-400">OFFICIAL</span>
                  <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-300 via-yellow-400 to-amber-600 drop-shadow-[0_0_8px_rgba(251,191,36,0.4)] mx-0.5">CC</span>
                  <span className="text-transparent bg-clip-text bg-gradient-to-r from-white to-slate-400">SHOP</span>
                </span>
                <span className="px-1.5 py-0.5 rounded text-[8px] font-black tracking-widest uppercase bg-amber-500/10 text-amber-400 border border-amber-500/20 hidden sm:inline-block">
                  PREMIUM
                </span>
              </div>
              <p className="text-[9px] font-semibold tracking-[0.2em] text-slate-400 hidden sm:block uppercase mt-0.5">
                Virtual Cards & Settlement
              </p>
            </div>`;

content = content.replace(target, replacement);

fs.writeFileSync('src/components/layout/Navbar.tsx', content);
