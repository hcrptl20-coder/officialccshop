const fs = require('fs');

let content = fs.readFileSync('src/data/demoCards.ts', 'utf8');

// Strip out the ending "];"
content = content.replace(/\];\s*$/, '');

const providers = ['VISA', 'MasterCard', 'Amex'];
const types = ['Debit', 'Credit', 'Prepaid'];
const countries = ['US', 'UK', 'CA', 'AU', 'IN', 'FR', 'DE', 'BR'];
let currentPriceUsd = 99.72; // Start from here based on user

let newCards = "";
for (let i = 101; i <= 500; i++) {
    // Generate price: increment by something random between 0.50 and 2.50
    currentPriceUsd += (Math.random() * 2 + 0.5);
    
    // Round to 2 decimals
    currentPriceUsd = Math.round(currentPriceUsd * 100) / 100;
    
    const priceInr = Math.round(currentPriceUsd * 94.49 * 100) / 100; // Roughly the conversion factor used 7953.22 / 84.17 = 94.489
    const priceFormatted = `$${currentPriceUsd.toFixed(2)} / ₹${priceInr.toLocaleString('en-IN', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`;
    
    const provider = providers[i % 3];
    const type = types[i % 3];
    const country = countries[i % countries.length];
    
    const last4 = String(1000 + Math.floor(Math.random() * 9000));
    const limitUsd = Math.floor(Math.random() * 2000) + 500;
    
    const cardObj = {
        id: `CRD-${String(i).padStart(4, '0')}`,
        cardCode: `DEMO-${String(i).padStart(4, '0')}`,
        provider: provider,
        cardType: type,
        expiry: "09/31",
        name: `Card ${provider} ${type} ${i}`,
        country: country,
        state: country,
        address: "Card Address",
        zip: `${country}***`,
        extras: "Auto Generated",
        bank: "Auto Bank",
        priceUsd: currentPriceUsd,
        priceInr: priceInr,
        priceFormatted: priceFormatted,
        last4: last4,
        limitUsd: limitUsd,
        inStock: true
    };
    
    newCards += ",\n  " + JSON.stringify(cardObj, null, 2).split('\n').map(l => l.replace(/^/, '  ')).join('\n').trim();
}

content += newCards + "\n];\n";
fs.writeFileSync('src/data/demoCards.ts', content);
console.log("Appended cards");
