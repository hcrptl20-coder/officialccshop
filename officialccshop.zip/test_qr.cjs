const QRCode = require('qrcode');

async function test(text) {
  const qr = QRCode.create(text, { errorCorrectionLevel: 'M' });
  console.log(`Version: ${qr.version}, Modules: ${qr.modules.size}`);
  let out = '';
  for (let r = 0; r < qr.modules.size; r++) {
    let row = '';
    for (let c = 0; c < qr.modules.size; c++) {
      row += qr.modules.get(r, c) ? '██' : '  ';
    }
    out += row + '\n';
  }
  return out;
}

test('upi://pay?pa=test@upi').then(console.log);
