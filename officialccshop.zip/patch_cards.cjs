const fs = require('fs');

let content = fs.readFileSync('src/pages/user/CardsPage.tsx', 'utf8');

const target1 = `<span className="px-3 py-1 rounded-full text-xs font-bold uppercase bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
              100 In-Stock Premium Cards
            </span>`;

const replacement1 = `<div className="relative group cursor-default">
              <div className="absolute -inset-0.5 bg-gradient-to-r from-pink-600 via-purple-600 to-cyan-600 rounded-full blur opacity-75 group-hover:opacity-100 transition duration-1000 group-hover:duration-200 animate-pulse"></div>
              <span className="relative px-3.5 py-1 rounded-full text-xs font-black uppercase bg-slate-950 flex items-center gap-1.5 text-transparent bg-clip-text bg-gradient-to-r from-pink-400 via-fuchsia-400 to-cyan-400 border border-white/10 shadow-[inset_0_0_10px_rgba(255,255,255,0.05)]">
                <Sparkles className="w-3.5 h-3.5 text-fuchsia-400" />
                1000+ Virtual Premium Cards
              </span>
            </div>`;

content = content.replace(target1, replacement1);

const target2 = `className="px-4 py-2 rounded-xl bg-cyan-500/10 border border-cyan-500/20 text-cyan-300 text-xs font-bold hover:bg-cyan-500/20 transition"
            >
              Browse 100 Premium Cards
            </button>`;

const replacement2 = `className="relative group px-4 py-2 rounded-xl bg-slate-900 border border-white/10 text-xs font-bold transition-all overflow-hidden"
            >
              <div className="absolute inset-0 bg-gradient-to-r from-pink-600/20 via-purple-600/20 to-cyan-600/20 opacity-0 group-hover:opacity-100 transition-opacity"></div>
              <span className="relative text-transparent bg-clip-text bg-gradient-to-r from-pink-400 via-purple-400 to-cyan-400">
                Browse 1000+ Premium Cards
              </span>
            </button>`;

content = content.replace(target2, replacement2);

fs.writeFileSync('src/pages/user/CardsPage.tsx', content);
