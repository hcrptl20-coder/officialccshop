const jsQR = require('jsqr');
const QRCode = require('qrcode');

async function test() {
  const qr = QRCode.create('upi://pay?pa=test@okaxis', { errorCorrectionLevel: 'M' });
  const size = qr.modules.size;
  console.log('Original size:', size);

  const scale = 10;
  const border = 4;
  const totalSize = (size + border * 2) * scale;
  const rgba = new Uint8ClampedArray(totalSize * totalSize * 4);
  rgba.fill(255); // white

  for (let r = 0; r < size; r++) {
    for (let c = 0; c < size; c++) {
      if (qr.modules.get(r, c)) {
        for (let y = 0; y < scale; y++) {
          for (let x = 0; x < scale; x++) {
            const py = (r + border) * scale + y;
            const px = (c + border) * scale + x;
            const idx = (py * totalSize + px) * 4;
            rgba[idx] = 0;
            rgba[idx + 1] = 0;
            rgba[idx + 2] = 0;
            rgba[idx + 3] = 255;
          }
        }
      }
    }
  }

  const code = jsQR(rgba, totalSize, totalSize);
  console.log('Decoded text:', code ? code.data : 'FAILED');
}

test();
