#!/bin/bash
sed -i 's/user.role ===/user?.role ===/g' src/App.tsx
