import sys

# Standard QR code generator in node to test if we can match
print("QR reader template ready")
