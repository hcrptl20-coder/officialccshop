const fs = require('fs');

let content = fs.readFileSync('src/context/AuthContext.tsx', 'utf8');

// I need to find refreshUser and rewrite it completely
const targetStart = `  const refreshUser = useCallback(async () => {
    try {
      const res = await apiRequest<{ user: User | null; unreadNotifications: number }>('/api/auth/me');
      if (res.ok && res.data?.user) {
        setUser(res.data.user);
        setUnreadCount(res.data.unreadNotifications || 0);
      } else {`;
      
const replacement = `  const refreshUser = useCallback(async () => {
    try {
      const res = await apiRequest<{ user: User | null; unreadNotifications: number }>('/api/auth/me');
      if (res.ok && res.data?.user) {
        setUser(res.data.user);
        setUnreadCount(res.data.unreadNotifications || 0);
      } else {
        // Guest Auto-Login
        const auto = await apiRequest<{ user: any; token: string }>('/api/auth/guest-login', {
          method: 'POST',
        });
        if (auto.ok && auto.data?.user) {
          if (typeof window !== 'undefined' && auto.data.token) {
            localStorage.setItem('zenith_auth_token', auto.data.token);
          }
          setUser(auto.data.user);
        } else {
          setUser(null);
        }
      }
    } catch (error) {
      console.error('Auth refresh failed:', error);
      setUser(null);
    } finally {
      setIsLoading(false);
    }
  }, []);`;

// Let's just do a regex replace to be safe.
content = content.replace(/  const refreshUser = useCallback\(async \(\) => \{[\s\S]*?\}, \[\]\);/, replacement);

fs.writeFileSync('src/context/AuthContext.tsx', content);
