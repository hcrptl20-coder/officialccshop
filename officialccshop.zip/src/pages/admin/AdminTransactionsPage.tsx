import React, { useEffect, useState } from 'react';
import { apiRequest } from '../../lib/api.ts';
import { Transaction } from '../../types/index.ts';
import { Badge } from '../../components/common/Badge.tsx';
import { Clock, Search, Download, RefreshCw, ArrowUpDown } from 'lucide-react';

export const AdminTransactionsPage: React.FC = () => {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [selectedType, setSelectedType] = useState('All');
  const [selectedStatus, setSelectedStatus] = useState('All');
  const [sortOrder, setSortOrder] = useState<'desc' | 'asc'>('desc');

  const fetchTransactions = async () => {
    setIsLoading(true);
    try {
      let url = '/api/admin/transactions?';
      if (selectedType !== 'All') url += `type=${encodeURIComponent(selectedType)}&`;
      if (selectedStatus !== 'All') url += `status=${encodeURIComponent(selectedStatus)}&`;
      if (search) url += `search=${encodeURIComponent(search)}&`;

      const res = await apiRequest<Transaction[]>(url);
      if (res.ok && res.data) {
        setTransactions(res.data);
      }
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchTransactions();
  }, [selectedType, selectedStatus]);

  const sortedTransactions = [...transactions].sort((a, b) => {
    const timeA = new Date(a.date).getTime();
    const timeB = new Date(b.date).getTime();
    return sortOrder === 'desc' ? timeB - timeA : timeA - timeB;
  });

  const handleExportCSV = () => {
    if (transactions.length === 0) return;
    const headers = 'Transaction ID,User ID,Type,Amount,Status,Payment Method,Reference,Date\n';
    const rows = sortedTransactions
      .map(
        (t) =>
          `"${t.id}","${t.userId}","${t.type}","${t.amount}","${t.status}","${t.paymentMethod}","${t.reference}","${t.date}"`
      )
      .join('\n');
    const blob = new Blob([headers + rows], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `officialccshop_admin_ledger_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            Platform Master Ledger
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Auditable log of all credits, card debits, manual settlements, and system events
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={fetchTransactions}
            className="p-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-white/[0.08] text-slate-300 hover:text-white transition-colors"
            title="Refresh Ledger"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
          <button
            onClick={handleExportCSV}
            className="px-3.5 py-2 rounded-xl text-xs font-semibold bg-slate-900 hover:bg-slate-800 text-slate-200 border border-white/[0.08] transition-all flex items-center gap-2"
          >
            <Download className="w-3.5 h-3.5 text-purple-400" />
            <span>Export Audit Log (CSV)</span>
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="p-4 rounded-2xl bg-slate-900/80 border border-white/[0.08] backdrop-blur-xl flex flex-col md:flex-row items-center gap-3">
        <div className="relative flex-1 w-full">
          <Search className="w-4 h-4 text-slate-500 absolute inset-y-0 left-3 my-auto pointer-events-none" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && fetchTransactions()}
            placeholder="Search by ID, user ID, or reference..."
            className="w-full pl-9 pr-3 py-2 rounded-xl bg-slate-950 border border-white/[0.08] text-white text-xs placeholder-slate-500 focus:outline-none focus:border-purple-500/60"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
          <select
            value={selectedType}
            onChange={(e) => setSelectedType(e.target.value)}
            className="px-3 py-2 rounded-xl bg-slate-950 border border-white/[0.08] text-white text-xs focus:outline-none focus:border-purple-500/60"
          >
            <option value="All">All Types</option>
            <option value="Deposit">Deposit</option>
            <option value="Virtual Card Payment">Card Payment</option>
            <option value="Refund">Refund</option>
            <option value="Fee">Fee</option>
          </select>

          <select
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value)}
            className="px-3 py-2 rounded-xl bg-slate-950 border border-white/[0.08] text-white text-xs focus:outline-none focus:border-purple-500/60"
          >
            <option value="All">All Statuses</option>
            <option value="Approved">Approved</option>
            <option value="Completed">Completed</option>
            <option value="Pending">Pending</option>
            <option value="Rejected">Rejected</option>
          </select>

          <button
            onClick={() => setSortOrder((prev) => (prev === 'desc' ? 'asc' : 'desc'))}
            className="px-3 py-2 rounded-xl bg-slate-950 hover:bg-slate-800 border border-white/[0.08] text-slate-300 text-xs font-semibold flex items-center gap-1.5"
          >
            <ArrowUpDown className="w-3.5 h-3.5 text-purple-400" />
            <span>{sortOrder === 'desc' ? 'Newest' : 'Oldest'}</span>
          </button>
        </div>
      </div>

      {/* Ledger Table */}
      <div className="rounded-2xl bg-slate-900/80 border border-white/[0.08] backdrop-blur-xl overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-white/[0.06] text-slate-400 uppercase tracking-wider text-[10px] bg-slate-950/40">
                <th className="py-3.5 px-4">Transaction ID</th>
                <th className="py-3.5 px-4">User ID</th>
                <th className="py-3.5 px-4">Type</th>
                <th className="py-3.5 px-4">Amount</th>
                <th className="py-3.5 px-4">Status</th>
                <th className="py-3.5 px-4">Method</th>
                <th className="py-3.5 px-4">Reference</th>
                <th className="py-3.5 px-4 text-right">Date</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/[0.04]">
              {sortedTransactions.map((txn) => (
                <tr key={txn.id} className="hover:bg-slate-800/40 transition-colors">
                  <td className="py-3.5 px-4 font-mono font-bold text-slate-200">
                    {txn.id}
                  </td>
                  <td className="py-3.5 px-4 font-mono text-purple-300 font-medium">
                    {txn.userId}
                  </td>
                  <td className="py-3.5 px-4 text-white font-medium">
                    {txn.type}
                  </td>
                  <td className="py-3.5 px-4 font-mono font-bold text-sm">
                    <span className={txn.amount > 0 ? 'text-emerald-400' : 'text-slate-300'}>
                      {txn.amount > 0 ? `+₹${txn.amount.toLocaleString()}` : `-₹${Math.abs(txn.amount).toLocaleString()}`}
                    </span>
                  </td>
                  <td className="py-3.5 px-4">
                    <Badge status={txn.status} size="sm" />
                  </td>
                  <td className="py-3.5 px-4 text-slate-300">
                    {txn.paymentMethod}
                  </td>
                  <td className="py-3.5 px-4 font-mono text-slate-400">
                    {txn.reference}
                  </td>
                  <td className="py-3.5 px-4 text-right text-slate-400 whitespace-nowrap">
                    {new Date(txn.date).toLocaleDateString()} {new Date(txn.date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </td>
                </tr>
              ))}

              {sortedTransactions.length === 0 && !isLoading && (
                <tr>
                  <td colSpan={8} className="py-12 text-center text-slate-500">
                    No transactions found matching your criteria.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
