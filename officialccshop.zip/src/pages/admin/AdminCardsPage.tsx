import React, { useEffect, useState } from 'react';
import { apiRequest } from '../../lib/api.ts';
import { CardCard, User } from '../../types/index.ts';
import { Badge } from '../../components/common/Badge.tsx';
import {
  CreditCard,
  Plus,
  Snowflake,
  ShieldCheck,
  Search,
  X,
  Sparkles,
} from 'lucide-react';

export const AdminCardsPage: React.FC = () => {
  const [cards, setCards] = useState<CardCard[]>([]);
  const [users, setUsers] = useState<User[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('All');
  const [showAssignModal, setShowAssignModal] = useState(false);

  // Assign card state
  const [selectedUserId, setSelectedUserId] = useState('');
  const [cardholderName, setCardholderName] = useState('');
  const [spendingLimit, setSpendingLimit] = useState('50000');
  const [colorTheme, setColorTheme] = useState<'emerald' | 'cyan' | 'purple' | 'amber'>('emerald');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const fetchData = async () => {
    setIsLoading(true);
    try {
      const [cardsRes, usersRes] = await Promise.all([
        apiRequest<CardCard[]>('/api/admin/cards'),
        apiRequest<User[]>('/api/admin/users'),
      ]);

      if (cardsRes.ok && cardsRes.data) setCards(cardsRes.data);
      if (usersRes.ok && usersRes.data) {
        setUsers(usersRes.data);
        if (usersRes.data.length > 0) setSelectedUserId(usersRes.data[0].id);
      }
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleToggleFreeze = async (cardId: string) => {
    const res = await apiRequest<CardCard>(`/api/cards/${cardId}/toggle-freeze`, {
      method: 'POST',
    });
    if (res.ok && res.data) {
      setCards((prev) => prev.map((c) => (c.id === cardId ? res.data! : c)));
    }
  };

  const handleAssignCard = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedUserId) return;

    setIsSubmitting(true);
    const res = await apiRequest<CardCard>('/api/admin/cards/assign', {
      method: 'POST',
      body: JSON.stringify({
        userId: selectedUserId,
        cardholderName: cardholderName || 'VALUED USER',
        spendingLimit: Number(spendingLimit) || 50000,
        colorTheme,
      }),
    });
    setIsSubmitting(false);

    if (res.ok && res.data) {
      setCards((prev) => [res.data!, ...prev]);
      setShowAssignModal(false);
      setCardholderName('');
    }
  };

  const filteredCards = cards.filter((c) => {
    const matchesSearch =
      c.maskedNumber.includes(search) ||
      c.cardholderName.toLowerCase().includes(search.toLowerCase()) ||
      c.userId.toLowerCase().includes(search.toLowerCase());
    const matchesStatus = statusFilter === 'All' || c.status.toUpperCase() === statusFilter.toUpperCase();
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            Virtual Premium Cards Administration
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Global repository of simulated cards, freeze states, and sandbox card allocation
          </p>
        </div>

        <button
          onClick={() => setShowAssignModal(true)}
          className="px-4 py-2.5 rounded-xl text-xs font-bold bg-purple-600 hover:bg-purple-500 text-white transition-all shadow-md shadow-purple-600/20 flex items-center gap-2 self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Assign Premium Card to User</span>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="p-4 rounded-2xl bg-slate-900/80 border border-white/[0.08] backdrop-blur-xl flex flex-col sm:flex-row items-center gap-3">
        <div className="relative flex-1 w-full">
          <Search className="w-4 h-4 text-slate-500 absolute inset-y-0 left-3 my-auto pointer-events-none" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by cardholder, masked number, or user ID..."
            className="w-full pl-9 pr-3 py-2 rounded-xl bg-slate-950 border border-white/[0.08] text-white text-xs placeholder-slate-500 focus:outline-none focus:border-purple-500/60"
          />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <span className="text-[11px] text-slate-400 font-medium">Status:</span>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-3 py-2 rounded-xl bg-slate-950 border border-white/[0.08] text-white text-xs focus:outline-none focus:border-purple-500/60"
          >
            <option value="All">All Cards</option>
            <option value="ACTIVE">Active Only</option>
            <option value="FROZEN">Frozen Only</option>
          </select>
        </div>
      </div>

      {/* Cards Table */}
      <div className="rounded-2xl bg-slate-900/80 border border-white/[0.08] backdrop-blur-xl overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-white/[0.06] text-slate-400 uppercase tracking-wider text-[10px] bg-slate-950/40">
                <th className="py-3.5 px-4">Card Identifier</th>
                <th className="py-3.5 px-4">Cardholder</th>
                <th className="py-3.5 px-4">Masked Number</th>
                <th className="py-3.5 px-4">Status</th>
                <th className="py-3.5 px-4">Limit / Spent</th>
                <th className="py-3.5 px-4">Expiry</th>
                <th className="py-3.5 px-4 text-right">Freeze Control</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/[0.04]">
              {filteredCards.map((card) => (
                <tr key={card.id} className="hover:bg-slate-800/40 transition-colors">
                  <td className="py-3.5 px-4 font-mono font-bold text-slate-200">
                    {card.id}
                  </td>
                  <td className="py-3.5 px-4">
                    <p className="text-white font-bold uppercase">{card.cardholderName}</p>
                    <p className="text-[10px] text-slate-400 font-mono">User: {card.userId}</p>
                  </td>
                  <td className="py-3.5 px-4 font-mono font-bold text-slate-100 tracking-wider">
                    {card.maskedNumber}
                  </td>
                  <td className="py-3.5 px-4">
                    <Badge status={card.status} size="sm" />
                  </td>
                  <td className="py-3.5 px-4 font-mono">
                    <span className="text-white font-semibold">₹{card.spendingLimit.toLocaleString()}</span>
                    <span className="text-slate-400 text-[11px] block">
                      Spent: ₹{card.spentAmount.toLocaleString()}
                    </span>
                  </td>
                  <td className="py-3.5 px-4 font-mono text-slate-300">
                    {card.expiryMonth}/{card.expiryYear}
                  </td>
                  <td className="py-3.5 px-4 text-right">
                    <button
                      onClick={() => handleToggleFreeze(card.id)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all ${
                        card.status === 'FROZEN'
                          ? 'bg-emerald-950/40 hover:bg-emerald-900/50 border-emerald-500/30 text-emerald-300'
                          : 'bg-rose-950/40 hover:bg-rose-900/50 border-rose-500/30 text-rose-300'
                      }`}
                    >
                      {card.status === 'FROZEN' ? 'Unfreeze' : 'Freeze Card'}
                    </button>
                  </td>
                </tr>
              ))}

              {filteredCards.length === 0 && !isLoading && (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-slate-500">
                    No virtual card cards match your criteria.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Assign Card Modal */}
      {showAssignModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-md rounded-2xl bg-slate-900 border border-white/[0.1] shadow-2xl p-6 space-y-5">
            <div className="flex items-center justify-between pb-3 border-b border-white/[0.08]">
              <div className="flex items-center gap-2">
                <CreditCard className="w-5 h-5 text-purple-400" />
                <h3 className="text-base font-bold text-white">Assign Premium Card</h3>
              </div>
              <button
                onClick={() => setShowAssignModal(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAssignCard} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Select User Account
                </label>
                <select
                  value={selectedUserId}
                  onChange={(e) => setSelectedUserId(e.target.value)}
                  className="w-full px-3 py-2.5 rounded-xl bg-slate-950 border border-white/[0.08] text-white text-xs focus:outline-none focus:border-purple-500/60"
                >
                  {users.map((u) => (
                    <option key={u.id} value={u.id}>
                      {u.name} (@{u.username})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Cardholder Name
                </label>
                <input
                  type="text"
                  required
                  value={cardholderName}
                  onChange={(e) => setCardholderName(e.target.value)}
                  placeholder="VALUED USER"
                  className="w-full px-3 py-2.5 rounded-xl bg-slate-950 border border-white/[0.08] text-white text-xs focus:outline-none focus:border-purple-500/60"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Monthly Spending Limit
                </label>
                <select
                  value={spendingLimit}
                  onChange={(e) => setSpendingLimit(e.target.value)}
                  className="w-full px-3 py-2.5 rounded-xl bg-slate-950 border border-white/[0.08] text-white text-xs focus:outline-none focus:border-purple-500/60"
                >
                  <option value="25000">₹25,000 / month</option>
                  <option value="50000">₹50,000 / month</option>
                  <option value="100000">₹1,00,000 / month</option>
                  <option value="500000">₹5,00,000 / month</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Theme
                </label>
                <div className="grid grid-cols-4 gap-2">
                  {(['emerald', 'cyan', 'purple', 'amber'] as const).map((theme) => (
                    <button
                      key={theme}
                      type="button"
                      onClick={() => setColorTheme(theme)}
                      className={`p-2 rounded-xl text-xs font-bold capitalize border ${
                        colorTheme === theme
                          ? 'border-purple-400 bg-purple-950/40 text-purple-300'
                          : 'border-white/[0.06] bg-slate-950 text-slate-400'
                      }`}
                    >
                      {theme}
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex items-center justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAssignModal(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs font-semibold hover:bg-slate-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold shadow-md shadow-purple-600/20 disabled:opacity-50"
                >
                  {isSubmitting ? 'Issuing...' : 'Assign Card'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
