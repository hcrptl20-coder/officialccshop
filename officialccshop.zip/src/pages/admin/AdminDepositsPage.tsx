import React, { useEffect, useState } from 'react';
import { apiRequest } from '../../lib/api.ts';
import { Deposit } from '../../types/index.ts';
import { Badge } from '../../components/common/Badge.tsx';
import { formatUSD } from '../../lib/currency.ts';
import {
  ArrowDownCircle,
  Search,
  CheckCircle2,
  XCircle,
  Clock,
  ExternalLink,
  FileText,
  X,
  AlertCircle,
  RefreshCw,
  CreditCard,
  Image as ImageIcon,
  Copy,
  Check,
  Eye,
  ShieldAlert,
  Wallet,
  Download,
} from 'lucide-react';

export const AdminDepositsPage: React.FC<{ filterMode?: 'transactions' | 'vouchers' }> = ({ filterMode = 'transactions' }) => {
  const [deposits, setDeposits] = useState<Deposit[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState<'All' | 'Pending' | 'Approved' | 'Rejected'>('All');
  const [typeFilter, setTypeFilter] = useState<'all' | 'card' | 'deposit'>('all');
  const [search, setSearch] = useState('');
  const [selectedDepositForReview, setSelectedDepositForReview] = useState<Deposit | null>(null);

  // Review modal states
  const [reviewStatus, setReviewStatus] = useState<'Approved' | 'Rejected'>('Approved');
  const [adminNotes, setAdminNotes] = useState('Verified against merchant bank statement UTR.');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [proofPreviewDeposit, setProofPreviewDeposit] = useState<Deposit | null>(null);
  const [copiedUtr, setCopiedUtr] = useState<string | null>(null);

  const fetchDeposits = async (silent = false) => {
    if (!silent) setIsLoading(true);
    try {
      let url = '/api/admin/deposits?';
      if (statusFilter !== 'All') url += `status=${encodeURIComponent(statusFilter)}&`;
      if (search) url += `search=${encodeURIComponent(search)}&`;

      const res = await apiRequest<Deposit[]>(url);
      if (res.ok && res.data) {
        setDeposits(res.data);
      }
    } finally {
      if (!silent) setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchDeposits(false);
    // Real-time polling every 4 seconds to sync all customer card orders & deposits live
    const interval = setInterval(() => {
      fetchDeposits(true);
    }, 4000);
    return () => clearInterval(interval);
  }, [statusFilter]);

  const handleCopyUtr = (utr: string) => {
    navigator.clipboard.writeText(utr);
    setCopiedUtr(utr);
    setTimeout(() => setCopiedUtr(null), 2000);
  };

  const openReviewModal = (dep: Deposit, status: 'Approved' | 'Rejected') => {
    setSelectedDepositForReview(dep);
    setReviewStatus(status);
    const isCard = Boolean(dep.cardName || dep.cardId);
    setAdminNotes(
      status === 'Approved'
        ? isCard
          ? `Verified UTR ${dep.referenceNo}. Approving and unlocking ${dep.cardName || 'card'} for customer.`
          : `Verified UTR ${dep.referenceNo} against bank statement. Balance credited.`
        : `Payment reference ${dep.referenceNo} could not be matched with bank ledger.`
    );
  };

  const handleQuickApprove = async (dep: Deposit) => {
    const isCard = Boolean(dep.cardName || dep.cardId);
    const notes = isCard
      ? `Verified UTR ${dep.referenceNo}. Card ${dep.cardName || ''} activated.`
      : `Verified UTR ${dep.referenceNo}. Balance credited.`;

    const res = await apiRequest<{ message: string; deposit: Deposit }>(
      `/api/admin/deposits/${dep.id}/review`,
      {
        method: 'POST',
        body: JSON.stringify({
          action: 'Approved',
          status: 'Approved',
          adminNotes: notes,
        }),
      }
    );

    if (res.ok && res.data) {
      setDeposits((prev) =>
        prev.map((d) => (d.id === dep.id ? { ...d, status: 'Approved', adminNotes: notes } : d))
      );
    } else {
      alert(res.error || 'Quick approve failed.');
    }
  };

  const handleReviewSubmit = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const dep = selectedDepositForReview || proofPreviewDeposit;
    if (!dep) return;

    setIsSubmitting(true);
    const res = await apiRequest<{ message: string; deposit: Deposit }>(
      `/api/admin/deposits/${dep.id}/review`,
      {
        method: 'POST',
        body: JSON.stringify({
          action: reviewStatus,
          status: reviewStatus,
          adminNotes,
        }),
      }
    );
    setIsSubmitting(false);

    if (res.ok && res.data) {
      setDeposits((prev) =>
        prev.map((d) => (d.id === dep.id ? { ...d, status: reviewStatus, adminNotes } : d))
      );
      setSelectedDepositForReview(null);
      setProofPreviewDeposit(null);
    } else {
      alert(res.error || 'Review operation failed.');
    }
  };

  // Filter list by type and search
  const filteredDeposits = deposits.filter((dep) => {
    // Mode filtering
    const isVoucher = Boolean(dep.purpose?.toLowerCase().includes('voucher'));
    if (filterMode === 'vouchers' && !isVoucher) return false;
    if (filterMode === 'transactions' && isVoucher) return false;

    // Type filtering
    const isCard = Boolean(dep.cardName || dep.cardId || dep.purpose?.toLowerCase().includes('card'));
    if (typeFilter === 'card' && !isCard) return false;
    if (typeFilter === 'deposit' && isCard) return false;

    if (search.trim()) {
      const q = search.toLowerCase();
      const matchUtr = dep.referenceNo?.toLowerCase().includes(q);
      const matchName = dep.userName?.toLowerCase().includes(q) || dep.username?.toLowerCase().includes(q);
      const matchEmail = dep.userEmail?.toLowerCase().includes(q);
      const matchId = dep.id?.toLowerCase().includes(q);
      const matchCard = dep.cardName?.toLowerCase().includes(q);
      return matchUtr || matchName || matchEmail || matchId || matchCard;
    }
    return true;
  });

  const pendingCount = deposits.filter((d) => d.status === 'Pending').length;
  const cardOrdersCount = deposits.filter((d) => Boolean(d.cardName || d.cardId)).length;
  const totalApprovedSum = deposits
    .filter((d) => d.status === 'Approved')
    .reduce((sum, d) => sum + d.amount, 0);

  return (
    <div id="admin-deposits-page" className="space-y-6">
      {/* Header & Metrics */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-white/[0.06]">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-purple-500/10 text-purple-300 border border-purple-500/20">
              Admin Compliance
            </span>
            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-mono bg-emerald-500/10 text-emerald-300 border border-emerald-500/20">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              <span>Live Sync (4s)</span>
            </span>
            <span className="text-xs text-slate-400 font-mono">Secure Session</span>
          </div>
          <h1 className="text-2xl font-black text-white tracking-tight mt-1 flex items-center gap-2.5">
            <ArrowDownCircle className="w-6 h-6 text-purple-400" />
            <span>{filterMode === 'vouchers' ? 'Customer Gift Vouchers' : 'Customer UPI Payments'}</span>
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            {filterMode === 'vouchers' 
              ? 'Review Amazon and Flipkart gift vouchers submitted by users for card purchases.'
              : 'Review customer-submitted UTR references and payment screenshots for Card Purchases and Wallet Deposits.'}
          </p>
        </div>

        <button
          onClick={fetchDeposits}
          className="flex items-center gap-2 px-3 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 border border-white/[0.08] text-xs font-semibold transition-all active:scale-95 self-stretch sm:self-auto justify-center"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
          <span>Refresh Queue</span>
        </button>
      </div>

      {/* KPI Stats Overview */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <div className="p-4 rounded-2xl bg-slate-900/80 border border-white/[0.08]">
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-400 font-medium">Pending Review</span>
            <span className="p-1.5 rounded-lg bg-amber-500/10 text-amber-400">
              <Clock className="w-4 h-4" />
            </span>
          </div>
          <p className="text-xl sm:text-2xl font-black text-amber-400 font-mono mt-2">
            {pendingCount}
          </p>
          <span className="text-[11px] text-slate-400 mt-0.5 block">Requires approval</span>
        </div>

        <div className="p-4 rounded-2xl bg-slate-900/80 border border-white/[0.08]">
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-400 font-medium">Card Orders</span>
            <span className="p-1.5 rounded-lg bg-purple-500/10 text-purple-400">
              <CreditCard className="w-4 h-4" />
            </span>
          </div>
          <p className="text-xl sm:text-2xl font-black text-purple-300 font-mono mt-2">
            {cardOrdersCount}
          </p>
          <span className="text-[11px] text-slate-400 mt-0.5 block">Cards requested with UTR</span>
        </div>

        <div className="p-4 rounded-2xl bg-slate-900/80 border border-white/[0.08]">
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-400 font-medium">Total Orders</span>
            <span className="p-1.5 rounded-lg bg-blue-500/10 text-blue-400">
              <FileText className="w-4 h-4" />
            </span>
          </div>
          <p className="text-xl sm:text-2xl font-black text-white font-mono mt-2">
            {deposits.length}
          </p>
          <span className="text-[11px] text-slate-400 mt-0.5 block">All queue submissions</span>
        </div>

        <div className="p-4 rounded-2xl bg-slate-900/80 border border-white/[0.08]">
          <div className="flex items-center justify-between">
            <span className="text-xs text-slate-400 font-medium">Approved Volume</span>
            <span className="p-1.5 rounded-lg bg-emerald-500/10 text-emerald-400">
              <CheckCircle2 className="w-4 h-4" />
            </span>
          </div>
          <p className="text-xl sm:text-2xl font-black text-emerald-400 font-mono mt-2 truncate">
            ₹{totalApprovedSum.toLocaleString('en-IN')}
          </p>
          <span className="text-[11px] text-slate-400 mt-0.5 block">
            ≈ ${formatUSD(totalApprovedSum)} USD
          </span>
        </div>
      </div>

      {/* Control Filter Bar */}
      <div className="p-4 rounded-2xl bg-slate-900/80 border border-white/[0.08] flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
        {/* Type / Category Tabs */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 md:pb-0">
          <button
            onClick={() => setTypeFilter('all')}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all shrink-0 ${
              typeFilter === 'all'
                ? 'bg-purple-600 text-white shadow-md shadow-purple-600/20'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            All Submissions ({deposits.length})
          </button>
          <button
            onClick={() => setTypeFilter('card')}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all shrink-0 ${
              typeFilter === 'card'
                ? 'bg-purple-600 text-white shadow-md shadow-purple-600/20'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <CreditCard className="w-3.5 h-3.5 text-purple-400" />
            <span>Card Purchases Only ({cardOrdersCount})</span>
          </button>
          <button
            onClick={() => setTypeFilter('deposit')}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all shrink-0 ${
              typeFilter === 'deposit'
                ? 'bg-purple-600 text-white shadow-md shadow-purple-600/20'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <Wallet className="w-3.5 h-3.5 text-emerald-400" />
            <span>Wallet Deposits Only</span>
          </button>
        </div>

        {/* Search & Status Controls */}
        <div className="flex items-center gap-2">
          {/* Status Dropdown */}
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value as any)}
            className="px-3 py-2 rounded-xl bg-slate-950 border border-white/[0.08] text-xs font-semibold text-slate-200 focus:outline-none focus:border-purple-500/50"
          >
            <option value="All">Status: All</option>
            <option value="Pending">Pending Only</option>
            <option value="Approved">Approved Only</option>
            <option value="Rejected">Rejected Only</option>
          </select>

          {/* Search Box */}
          <div className="relative flex-1 md:w-64">
            <Search className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search UTR, Card, User..."
              className="w-full pl-9 pr-3 py-2 rounded-xl bg-slate-950 border border-white/[0.08] text-xs text-white placeholder-slate-500 focus:outline-none focus:border-purple-500/50 transition-all"
            />
          </div>
        </div>
      </div>

      {/* Main Submissions Table */}
      <div className="rounded-2xl bg-slate-900/90 border border-white/[0.08] overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-950/80 text-[11px] uppercase tracking-wider text-slate-400 font-semibold border-b border-white/[0.06]">
              <tr>
                <th className="py-3.5 px-4">Order ID & Type</th>
                <th className="py-3.5 px-4">Customer</th>
                <th className="py-3.5 px-4">Amount</th>
                <th className="py-3.5 px-4">{filterMode === 'vouchers' ? 'Voucher Code' : 'UTR Reference'}</th>
                <th className="py-3.5 px-4">{filterMode === 'vouchers' ? 'Payment Method' : 'Payment Screenshot'}</th>
                <th className="py-3.5 px-4">Status</th>
                <th className="py-3.5 px-4">Submitted Time</th>
                <th className="py-3.5 px-4 text-right">Verification Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/[0.04]">
              {filteredDeposits.map((dep) => {
                const isCardPurchase = Boolean(dep.cardName || dep.cardId);
                return (
                  <tr
                    key={dep.id}
                    className="hover:bg-slate-800/40 transition-colors group"
                  >
                    {/* Order ID & Type */}
                    <td className="py-3.5 px-4">
                      <div className="font-mono font-bold text-white text-xs">{dep.id}</div>
                      {isCardPurchase ? (
                        <div className="mt-1 inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-purple-500/10 border border-purple-500/20 text-purple-300 text-[10px] font-semibold">
                          <CreditCard className="w-3 h-3 text-purple-400" />
                          <span>{dep.cardName || 'Card Purchase'}</span>
                        </div>
                      ) : (
                        <div className="mt-1 inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 text-[10px] font-semibold">
                          <Wallet className="w-3 h-3 text-emerald-400" />
                          <span>Wallet Deposit</span>
                        </div>
                      )}
                    </td>

                    {/* Customer */}
                    <td className="py-3.5 px-4">
                      <p className="text-white font-bold">{dep.userName || dep.username || 'User'}</p>
                      <p className="text-[11px] text-slate-400 font-mono">
                        {dep.userEmail || dep.userId}
                      </p>
                    </td>

                    {/* Amount */}
                    <td className="py-3.5 px-4 font-mono">
                      <div className="font-bold text-emerald-400 text-sm">
                        ₹{dep.amount.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                      </div>
                      <div className="text-[10px] text-slate-400">
                        ≈ ${formatUSD(dep.amount)} USD
                      </div>
                    </td>

                    {/* 12-Digit UTR */}
                    <td className="py-3.5 px-4">
                      <div className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-slate-950 border border-purple-500/30 text-purple-300 font-mono font-bold text-xs shadow-inner">
                        <span>{dep.referenceNo}</span>
                        <button
                          type="button"
                          onClick={() => handleCopyUtr(dep.referenceNo)}
                          title="Copy UTR number"
                          className="text-slate-400 hover:text-white p-0.5 transition-colors"
                        >
                          {copiedUtr === dep.referenceNo ? (
                            <Check className="w-3.5 h-3.5 text-emerald-400" />
                          ) : (
                            <Copy className="w-3.5 h-3.5" />
                          )}
                        </button>
                      </div>
                    </td>

                    {/* Payment Screenshot Proof or Voucher Mode */}
                    <td className="py-3.5 px-4">
                      {dep.proofUrl ? (
                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={() => setProofPreviewDeposit(dep)}
                            className="relative w-12 h-12 rounded-lg overflow-hidden border border-white/10 group-hover:border-purple-500/40 bg-slate-950 shrink-0 shadow-sm"
                          >
                            <img
                              src={dep.proofUrl}
                              alt="Payment Screenshot"
                              className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                            />
                            <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                              <Eye className="w-3.5 h-3.5 text-white" />
                            </div>
                          </button>
                          <div>
                            <button
                              type="button"
                              onClick={() => setProofPreviewDeposit(dep)}
                              className="text-xs font-semibold text-purple-400 hover:text-purple-300 flex items-center gap-1 transition-colors"
                            >
                              <span>View Screenshot</span>
                              <ExternalLink className="w-3 h-3" />
                            </button>
                            <span className="text-[10px] text-emerald-400 block font-mono">
                              Screenshot Attached
                            </span>
                          </div>
                        </div>
                      ) : (
                        <div>
                           <span className="text-slate-300 text-xs font-semibold">{dep.purpose || 'Direct Deposit'}</span>
                           <span className="text-slate-500 text-[10px] block font-mono italic mt-0.5">No screenshot attached</span>
                        </div>
                      )}
                    </td>

                    {/* Status */}
                    <td className="py-3.5 px-4">
                      <Badge status={dep.status} size="sm" />
                      {dep.reviewedBy && (
                        <span className="text-[10px] text-slate-400 block mt-0.5 font-mono">
                          By: {dep.reviewedBy}
                        </span>
                      )}
                    </td>

                    {/* Date */}
                    <td className="py-3.5 px-4 text-slate-400 whitespace-nowrap">
                      <div>{new Date(dep.createdAt).toLocaleDateString()}</div>
                      <div className="text-[10px] font-mono text-slate-500">
                        {new Date(dep.createdAt).toLocaleTimeString([], {
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </div>
                    </td>

                    {/* Review Actions */}
                    <td className="py-3.5 px-4 text-right">
                      {dep.status === 'Pending' ? (
                        <div className="flex items-center justify-end gap-2">
                          <button
                            type="button"
                            onClick={() => openReviewModal(dep, 'Approved')}
                            className="px-3 py-1.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs flex items-center gap-1 shadow-md shadow-emerald-500/20 active:scale-95 transition-all"
                          >
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            <span>Approve</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => openReviewModal(dep, 'Rejected')}
                            className="px-3 py-1.5 rounded-xl bg-rose-950/40 hover:bg-rose-900/50 text-rose-300 border border-rose-500/30 text-xs font-semibold flex items-center gap-1 active:scale-95 transition-all"
                          >
                            <XCircle className="w-3.5 h-3.5" />
                            <span>Reject</span>
                          </button>
                        </div>
                      ) : (
                        <div className="text-right">
                          <span className="text-[11px] text-slate-500 font-mono">
                            {dep.status === 'Approved' ? '✓ Settled' : '✕ Rejected'}
                          </span>
                          {dep.adminNotes && (
                            <p className="text-[10px] text-slate-400 truncate max-w-[140px] ml-auto">
                              {dep.adminNotes}
                            </p>
                          )}
                        </div>
                      )}
                    </td>
                  </tr>
                );
              })}

              {filteredDeposits.length === 0 && !isLoading && (
                <tr>
                  <td colSpan={8} className="py-12 text-center text-slate-500">
                    <ShieldAlert className="w-8 h-8 text-slate-600 mx-auto mb-2" />
                    <p className="text-sm font-semibold text-slate-400">
                      No matching records found
                    </p>
                    <p className="text-xs text-slate-500 mt-1">
                      Try adjusting your status or search filters.
                    </p>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Review Confirmation Modal */}
      {selectedDepositForReview && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in">
          <div className="w-full max-w-lg rounded-3xl bg-slate-900 border border-purple-500/30 shadow-2xl p-6 space-y-5">
            <div className="flex items-center justify-between pb-3 border-b border-white/[0.08]">
              <div>
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <span
                    className={`w-2.5 h-2.5 rounded-full ${
                      reviewStatus === 'Approved' ? 'bg-emerald-500' : 'bg-rose-500'
                    }`}
                  />
                  <span>
                    {reviewStatus === 'Approved'
                      ? 'Approve Order & Fulfill'
                      : 'Reject Payment Submission'}
                  </span>
                </h3>
                <p className="text-xs text-slate-400 mt-0.5 font-mono">
                  {selectedDepositForReview.id} • User: {selectedDepositForReview.userName}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setSelectedDepositForReview(null)}
                className="p-1.5 rounded-xl text-slate-400 hover:text-white bg-slate-800 hover:bg-slate-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Submission Detail Card */}
            <div className="p-4 rounded-2xl bg-slate-950 border border-white/[0.06] space-y-3">
              <div className="flex justify-between items-center text-xs">
                <span className="text-slate-400">Order Type:</span>
                <span className="font-bold text-white">
                  {selectedDepositForReview.cardName ? (
                    <span className="text-purple-300">
                      💳 Card Purchase: {selectedDepositForReview.cardName}
                    </span>
                  ) : (
                    <span className="text-emerald-300">💰 Wallet Deposit</span>
                  )}
                </span>
              </div>

              <div className="flex justify-between items-center text-xs">
                <span className="text-slate-400">Claimed Amount:</span>
                <span className="font-mono font-bold text-emerald-400">
                  ₹{selectedDepositForReview.amount.toLocaleString()} (≈ $
                  {formatUSD(selectedDepositForReview.amount)} USD)
                </span>
              </div>

              <div className="flex justify-between items-center text-xs">
                <span className="text-slate-400">12-Digit UTR:</span>
                <div className="flex items-center gap-1 font-mono font-bold text-purple-300">
                  <span>{selectedDepositForReview.referenceNo}</span>
                  <button
                    type="button"
                    onClick={() => handleCopyUtr(selectedDepositForReview.referenceNo)}
                    className="text-slate-400 hover:text-white p-0.5"
                  >
                    <Copy className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {selectedDepositForReview.proofUrl && (
                <div className="pt-2 border-t border-white/[0.06] flex items-center justify-between">
                  <span className="text-slate-400 text-xs">Payment Screenshot:</span>
                  <button
                    type="button"
                    onClick={() => setProofPreviewDeposit(selectedDepositForReview)}
                    className="text-xs text-purple-400 hover:text-purple-300 font-semibold flex items-center gap-1"
                  >
                    <ImageIcon className="w-3.5 h-3.5" />
                    <span>View Customer Screenshot</span>
                  </button>
                </div>
              )}
            </div>

            {/* Review Form */}
            <form onSubmit={handleReviewSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Admin Resolution Note:
                </label>
                <textarea
                  required
                  rows={3}
                  value={adminNotes}
                  onChange={(e) => setAdminNotes(e.target.value)}
                  className="w-full px-3 py-2.5 rounded-xl bg-slate-950 border border-white/[0.08] text-xs text-white placeholder-slate-500 focus:outline-none focus:border-purple-500/50"
                  placeholder="Enter audit / compliance note..."
                />
              </div>

              {reviewStatus === 'Approved' && selectedDepositForReview.cardName && (
                <div className="p-3 rounded-xl bg-purple-500/10 border border-purple-500/20 text-purple-200 text-xs flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-purple-400 shrink-0" />
                  <span>
                    Approving this order will automatically issue and activate{' '}
                    <strong>{selectedDepositForReview.cardName}</strong> for customer{' '}
                    <strong>{selectedDepositForReview.userName}</strong>.
                  </span>
                </div>
              )}

              <div className="flex items-center justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setSelectedDepositForReview(null)}
                  className="px-4 py-2.5 rounded-xl bg-slate-800 text-slate-300 text-xs font-semibold hover:bg-slate-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className={`px-5 py-2.5 rounded-xl text-xs font-bold shadow-lg disabled:opacity-50 active:scale-95 transition-all ${
                    reviewStatus === 'Approved'
                      ? 'bg-emerald-500 hover:bg-emerald-400 text-slate-950 shadow-emerald-500/20'
                      : 'bg-rose-600 hover:bg-rose-500 text-white shadow-rose-600/20'
                  }`}
                >
                  {isSubmitting ? 'Saving Review...' : `Confirm ${reviewStatus}`}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Proof Preview Lightbox Modal */}
      {proofPreviewDeposit && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-xl animate-in fade-in"
          onClick={() => setProofPreviewDeposit(null)}
        >
          <div
            className="relative max-w-3xl w-full bg-slate-900 rounded-3xl p-5 border border-purple-500/30 shadow-2xl space-y-4"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-3 border-b border-white/[0.08]">
              <div>
                <h4 className="text-sm font-bold text-white flex items-center gap-2">
                  <ImageIcon className="w-4 h-4 text-purple-400" />
                  <span>Customer Payment Screenshot Proof</span>
                </h4>
                <p className="text-xs text-slate-400 mt-0.5">
                  Customer: <strong className="text-white">{proofPreviewDeposit.userName}</strong> • UTR:{' '}
                  <strong className="text-purple-300 font-mono">{proofPreviewDeposit.referenceNo}</strong> • Amount:{' '}
                  <strong className="text-emerald-400 font-mono">₹{proofPreviewDeposit.amount.toLocaleString()}</strong>
                </p>
              </div>
              <button
                type="button"
                onClick={() => setProofPreviewDeposit(null)}
                className="p-1.5 rounded-xl bg-slate-800 text-white hover:bg-slate-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* High-res Image Display */}
            <div className="max-h-[62vh] overflow-auto rounded-2xl bg-slate-950 border border-white/[0.06] flex items-center justify-center p-2">
              <img
                src={proofPreviewDeposit.proofUrl}
                alt="Deposit Proof"
                className="max-h-[58vh] max-w-full object-contain rounded-xl shadow-lg"
              />
            </div>

            {/* Action Bar inside Lightbox */}
            <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
              <a
                href={proofPreviewDeposit.proofUrl}
                target="_blank"
                rel="noreferrer"
                className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-1.5"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Open Original Image</span>
              </a>

              {proofPreviewDeposit.status === 'Pending' && (
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      openReviewModal(proofPreviewDeposit, 'Rejected');
                      setProofPreviewDeposit(null);
                    }}
                    className="px-4 py-2 rounded-xl bg-rose-950/50 hover:bg-rose-900/60 text-rose-300 border border-rose-500/30 text-xs font-semibold flex items-center gap-1.5"
                  >
                    <XCircle className="w-4 h-4" />
                    <span>Reject</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      openReviewModal(proofPreviewDeposit, 'Approved');
                      setProofPreviewDeposit(null);
                    }}
                    className="px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 shadow-md shadow-emerald-500/20"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Approve Payment</span>
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
