import React, { useEffect, useState } from 'react';
import { apiRequest } from '../../lib/api.ts';
import { User } from '../../types/index.ts';
import { Badge } from '../../components/common/Badge.tsx';
import {
  Users,
  Search,
  Shield,
  UserCheck,
  UserX,
  PlusCircle,
  MinusCircle,
  X,
  CheckCircle2,
  AlertCircle,
} from 'lucide-react';

export const AdminUsersPage: React.FC = () => {
  const [users, setUsers] = useState<User[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [selectedUserForBalance, setSelectedUserForBalance] = useState<User | null>(null);

  // Balance adjustment modal
  const [adjustType, setAdjustType] = useState<'credit' | 'debit'>('credit');
  const [adjustAmount, setAdjustAmount] = useState('');
  const [adjustReason, setAdjustReason] = useState('Manual Sandbox Ledger Credit');
  const [isAdjusting, setIsAdjusting] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const fetchUsers = async () => {
    setIsLoading(true);
    try {
      const res = await apiRequest<User[]>('/api/admin/users');
      if (res.ok && res.data) {
        setUsers(res.data);
      }
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  const handleToggleStatus = async (user: User) => {
    const nextStatus = user.status === 'active' ? 'suspended' : 'active';
    const res = await apiRequest(`/api/admin/users/${user.id}/status`, {
      method: 'POST',
      body: JSON.stringify({ status: nextStatus }),
    });

    if (res.ok) {
      setUsers((prev) =>
        prev.map((u) => (u.id === user.id ? { ...u, status: nextStatus } : u))
      );
    }
  };

  const handleToggleRole = async (user: User) => {
    const nextRole = user.role === 'admin' ? 'user' : 'admin';
    const res = await apiRequest(`/api/admin/users/${user.id}/role`, {
      method: 'POST',
      body: JSON.stringify({ role: nextRole }),
    });

    if (res.ok) {
      setUsers((prev) =>
        prev.map((u) => (u.id === user.id ? { ...u, role: nextRole } : u))
      );
    }
  };

  const handleBalanceSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedUserForBalance) return;
    const num = Number(adjustAmount);
    if (!num || num <= 0) return;

    setIsAdjusting(true);
    setMessage(null);

    const res = await apiRequest<{ message: string; user: User }>(
      `/api/admin/users/${selectedUserForBalance.id}/balance`,
      {
        method: 'POST',
        body: JSON.stringify({
          amount: num,
          type: adjustType,
          reason: adjustReason,
        }),
      }
    );
    setIsAdjusting(false);

    if (res.ok && res.data?.user) {
      setUsers((prev) =>
        prev.map((u) => (u.id === selectedUserForBalance.id ? res.data!.user : u))
      );
      setMessage({ type: 'success', text: res.data.message });
      setTimeout(() => {
        setSelectedUserForBalance(null);
        setAdjustAmount('');
        setMessage(null);
      }, 1500);
    } else {
      setMessage({ type: 'error', text: res.error || 'Failed to adjust balance' });
    }
  };

  const filteredUsers = users.filter(
    (u) =>
      u.name.toLowerCase().includes(search.toLowerCase()) ||
      u.email.toLowerCase().includes(search.toLowerCase()) ||
      u.username.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            User Accounts & Permissions
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Audit registered identities, grant administrator credentials, and manage ledger balances
          </p>
        </div>

        <div className="relative w-full sm:w-64">
          <Search className="w-4 h-4 text-slate-500 absolute inset-y-0 left-3 my-auto pointer-events-none" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search accounts..."
            className="w-full pl-9 pr-3 py-2 rounded-xl bg-slate-900 border border-white/[0.08] text-white text-xs placeholder-slate-500 focus:outline-none focus:border-purple-500/60"
          />
        </div>
      </div>

      {/* Users Table */}
      <div className="rounded-2xl bg-slate-900/80 border border-white/[0.08] backdrop-blur-xl overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-white/[0.06] text-slate-400 uppercase tracking-wider text-[10px] bg-slate-950/40">
                <th className="py-3.5 px-4">User</th>
                <th className="py-3.5 px-4">Role</th>
                <th className="py-3.5 px-4">Status</th>
                <th className="py-3.5 px-4">Balance</th>
                <th className="py-3.5 px-4">Created</th>
                <th className="py-3.5 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/[0.04]">
              {filteredUsers.map((user) => (
                <tr key={user.id} className="hover:bg-slate-800/40 transition-colors">
                  <td className="py-3.5 px-4">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-xl bg-slate-800 border border-white/10 flex items-center justify-center font-bold text-white text-xs">
                        {user.name.charAt(0)}
                      </div>
                      <div>
                        <p className="font-bold text-white">{user.name}</p>
                        <p className="text-[11px] text-slate-400">@{user.username} • {user.email}</p>
                      </div>
                    </div>
                  </td>
                  <td className="py-3.5 px-4">
                    <button
                      onClick={() => handleToggleRole(user)}
                      className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase border transition-colors ${
                        user.role === 'admin'
                          ? 'bg-purple-950/40 text-purple-300 border-purple-500/30'
                          : 'bg-slate-800 text-slate-400 border-slate-700'
                      }`}
                      title="Click to toggle role"
                    >
                      {user.role}
                    </button>
                  </td>
                  <td className="py-3.5 px-4">
                    <Badge status={user.status === 'active' ? 'ACTIVE' : 'SUSPENDED'} size="sm" />
                  </td>
                  <td className="py-3.5 px-4 font-mono font-bold text-white">
                    ₹{user.balance.toLocaleString()}
                  </td>
                  <td className="py-3.5 px-4 text-slate-400 whitespace-nowrap">
                    {new Date(user.createdAt).toLocaleDateString()}
                  </td>
                  <td className="py-3.5 px-4 text-right">
                    <div className="flex items-center justify-end gap-2">
                      <button
                        onClick={() => setSelectedUserForBalance(user)}
                        className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-1 transition-colors"
                      >
                        <span>Adjust Balance</span>
                      </button>

                      <button
                        onClick={() => handleToggleStatus(user)}
                        className={`p-1.5 rounded-lg border text-xs font-semibold transition-colors ${
                          user.status === 'active'
                            ? 'bg-rose-950/40 text-rose-300 border-rose-500/30 hover:bg-rose-900/50'
                            : 'bg-emerald-950/40 text-emerald-300 border-emerald-500/30 hover:bg-emerald-900/50'
                        }`}
                        title={user.status === 'active' ? 'Suspend User' : 'Reactivate User'}
                      >
                        {user.status === 'active' ? (
                          <UserX className="w-3.5 h-3.5" />
                        ) : (
                          <UserCheck className="w-3.5 h-3.5" />
                        )}
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Adjust Balance Modal */}
      {selectedUserForBalance && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-md rounded-2xl bg-slate-900 border border-white/[0.1] shadow-2xl p-6 space-y-5">
            <div className="flex items-center justify-between pb-3 border-b border-white/[0.08]">
              <div>
                <h3 className="text-base font-bold text-white">Adjust User Balance</h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Account: {selectedUserForBalance.name} (Current: ₹{selectedUserForBalance.balance.toLocaleString()})
                </p>
              </div>
              <button
                onClick={() => setSelectedUserForBalance(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {message && (
              <div
                className={`p-3 rounded-xl text-xs flex items-center gap-2 ${
                  message.type === 'success'
                    ? 'bg-emerald-950/40 border border-emerald-500/40 text-emerald-300'
                    : 'bg-rose-950/40 border border-rose-500/40 text-rose-300'
                }`}
              >
                {message.type === 'success' ? (
                  <CheckCircle2 className="w-4 h-4" />
                ) : (
                  <AlertCircle className="w-4 h-4" />
                )}
                <span>{message.text}</span>
              </div>
            )}

            <form onSubmit={handleBalanceSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setAdjustType('credit')}
                  className={`py-2 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 border transition-all ${
                    adjustType === 'credit'
                      ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                      : 'bg-slate-950 text-slate-400 border-white/[0.06]'
                  }`}
                >
                  <PlusCircle className="w-4 h-4" />
                  <span>Credit (Add Funds)</span>
                </button>
                <button
                  type="button"
                  onClick={() => setAdjustType('debit')}
                  className={`py-2 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 border transition-all ${
                    adjustType === 'debit'
                      ? 'bg-rose-500/20 text-rose-300 border-rose-500/40'
                      : 'bg-slate-950 text-slate-400 border-white/[0.06]'
                  }`}
                >
                  <MinusCircle className="w-4 h-4" />
                  <span>Debit (Deduct)</span>
                </button>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Adjustment Amount (INR)
                </label>
                <input
                  type="number"
                  min="1"
                  step="1"
                  required
                  value={adjustAmount}
                  onChange={(e) => setAdjustAmount(e.target.value)}
                  placeholder="5000"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-white/[0.08] text-white font-mono text-sm focus:outline-none focus:border-purple-500/60"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Reason / Audit Log
                </label>
                <input
                  type="text"
                  required
                  value={adjustReason}
                  onChange={(e) => setAdjustReason(e.target.value)}
                  placeholder="e.g. Ledger discrepancy correction"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-white/[0.08] text-white text-xs focus:outline-none focus:border-purple-500/60"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setSelectedUserForBalance(null)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs font-semibold hover:bg-slate-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isAdjusting}
                  className="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold shadow-md shadow-purple-600/20 disabled:opacity-50"
                >
                  {isAdjusting ? 'Processing...' : 'Apply Ledger Adjustment'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
