import React, { useEffect, useState } from 'react';
import { apiRequest } from '../../lib/api.ts';
import { AdminStats, Deposit } from '../../types/index.ts';
import { Badge } from '../../components/common/Badge.tsx';
import { formatUSD } from '../../lib/currency.ts';
import {
  Users,
  ArrowDownCircle,
  CreditCard,
  Clock,
  ShieldCheck,
  AlertCircle,
  CheckCircle2,
  XCircle,
  ChevronRight,
  TrendingUp,
  Settings,
  Copy,
  Check,
  Eye,
  RefreshCw,
  X,
  Wallet,
  ExternalLink,
} from 'lucide-react';

interface AdminDashboardPageProps {
  onNavigate: (path: string) => void;
}

export const AdminDashboardPage: React.FC<AdminDashboardPageProps> = ({ onNavigate }) => {
  const [stats, setStats] = useState<AdminStats | null>(null);
  const [pendingDeposits, setPendingDeposits] = useState<Deposit[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState<string | null>(null);
  const [previewProof, setPreviewProof] = useState<Deposit | null>(null);
  const [copiedUtr, setCopiedUtr] = useState<string | null>(null);

  const loadData = async (silent = false) => {
    if (!silent) setIsLoading(true);
    try {
      const [statsRes, depositsRes] = await Promise.all([
        apiRequest<AdminStats>('/api/admin/stats'),
        apiRequest<Deposit[]>('/api/admin/deposits?status=Pending'),
      ]);

      if (statsRes.ok && statsRes.data) setStats(statsRes.data);
      if (depositsRes.ok && depositsRes.data) {
        setPendingDeposits(depositsRes.data);
      }
    } finally {
      if (!silent) setIsLoading(false);
    }
  };

  useEffect(() => {
    loadData(false);
    // Real-time polling every 4 seconds to instantly catch incoming card orders & deposits
    const interval = setInterval(() => {
      loadData(true);
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  const handleCopyUtr = (utr: string) => {
    navigator.clipboard.writeText(utr);
    setCopiedUtr(utr);
    setTimeout(() => setCopiedUtr(null), 2000);
  };

  const handleReviewDeposit = async (id: string, status: 'Approved' | 'Rejected', cardName?: string) => {
    setActionLoading(id);
    const notes =
      status === 'Approved'
        ? cardName
          ? `Verified UTR payment proof. Approved and activated ${cardName} for customer.`
          : 'Verified with bank statement UTR. Wallet credited.'
        : 'UTR reference could not be verified against bank records.';

    const res = await apiRequest(`/api/admin/deposits/${id}/review`, {
      method: 'POST',
      body: JSON.stringify({ action: status, status, adminNotes: notes }),
    });
    setActionLoading(null);

    if (res.ok) {
      loadData(true);
      if (previewProof?.id === id) setPreviewProof(null);
    } else {
      alert(res.error || 'Failed to update deposit review.');
    }
  };

  return (
    <div className="space-y-8 max-w-7xl mx-auto">
      {/* Admin Title Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              Administrative Control Center
            </h1>
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase bg-purple-500/20 text-purple-300 border border-purple-500/30">
              Super Admin
            </span>
            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-mono bg-emerald-500/10 text-emerald-300 border border-emerald-500/20">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              <span>Live Queue Sync</span>
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Real-time customer card orders, manual UTR payment approvals, ledger governance, and QR management
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => loadData(false)}
            className="px-3 py-2 rounded-xl text-xs font-semibold bg-slate-900 hover:bg-slate-800 text-slate-300 border border-white/[0.08] transition-all flex items-center gap-1.5"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
            <span>Refresh</span>
          </button>

          <button
            onClick={() => onNavigate('/admin/settings')}
            className="px-3.5 py-2 rounded-xl text-xs font-semibold bg-slate-900 hover:bg-slate-800 text-slate-200 border border-white/[0.08] transition-all flex items-center gap-2"
          >
            <Settings className="w-3.5 h-3.5 text-purple-400" />
            <span>Payment & QR Settings</span>
          </button>
        </div>
      </div>

      {/* 4 Stat Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Users */}
        <div className="p-5 rounded-2xl bg-slate-900/80 border border-purple-500/20 backdrop-blur-xl shadow-xl">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400">Total Users</span>
            <div className="p-2 rounded-xl bg-purple-500/10 text-purple-400 border border-purple-500/20">
              <Users className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl sm:text-3xl font-extrabold text-white font-mono-numbers">
              {stats?.totalUsers ?? '...'}
            </div>
            <p className="mt-2 text-[11px] text-slate-400">Registered platform accounts</p>
          </div>
        </div>

        {/* Pending Deposits */}
        <div className="p-5 rounded-2xl bg-slate-900/80 border border-amber-500/20 backdrop-blur-xl shadow-xl">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400">Pending Approvals</span>
            <div className="p-2 rounded-xl bg-amber-500/10 text-amber-400 border border-amber-500/20">
              <ArrowDownCircle className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl sm:text-3xl font-extrabold text-amber-400 font-mono-numbers">
              {pendingDeposits.length}
            </div>
            <p className="mt-2 text-[11px] text-slate-400">Card orders & deposits awaiting verification</p>
          </div>
        </div>

        {/* Total Volume */}
        <div className="p-5 rounded-2xl bg-slate-900/80 border border-emerald-500/20 backdrop-blur-xl shadow-xl">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400">Approved Volume</span>
            <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl sm:text-3xl font-extrabold text-emerald-400 font-mono-numbers">
              ₹{(stats?.totalApprovedVolume ?? 0).toLocaleString('en-IN')}
            </div>
            <p className="mt-2 text-[11px] text-slate-400">Verified settled transaction volume</p>
          </div>
        </div>

        {/* Active Premium Cards */}
        <div className="p-5 rounded-2xl bg-slate-900/80 border border-white/[0.08] backdrop-blur-xl shadow-xl">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400">Unlocked Cards</span>
            <div className="p-2 rounded-xl bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
              <CreditCard className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl sm:text-3xl font-extrabold text-white font-mono-numbers">
              {stats?.totalCards ?? '...'}
            </div>
            <p className="mt-2 text-[11px] text-slate-400">Active virtual cards in circulation</p>
          </div>
        </div>
      </div>

      {/* Critical Section: Immediate Pending Deposit & Card Order Review Queue */}
      <div className="p-6 rounded-2xl bg-slate-900/80 border border-amber-500/30 backdrop-blur-xl space-y-4 shadow-2xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <div className="flex items-center gap-2">
              <span className="p-1 rounded-md bg-amber-500/20 text-amber-400">
                <AlertCircle className="w-4 h-4" />
              </span>
              <h2 className="text-base font-bold text-white">
                Pending Verification Queue ({pendingDeposits.length})
              </h2>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Live submissions from customers with UTR reference numbers and uploaded payment screenshots.
            </p>
          </div>

          <button
            onClick={() => onNavigate('/admin/deposits')}
            className="text-xs font-semibold text-purple-400 hover:text-purple-300 flex items-center gap-1 self-start sm:self-auto"
          >
            <span>Open Full Submissions Table</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-white/[0.06] text-slate-400 uppercase tracking-wider text-[10px]">
                <th className="py-3 px-3">Order ID & Type</th>
                <th className="py-3 px-3">Customer</th>
                <th className="py-3 px-3">Amount</th>
                <th className="py-3 px-3">12-Digit UTR Reference</th>
                <th className="py-3 px-3">Payment Proof</th>
                <th className="py-3 px-3">Submitted At</th>
                <th className="py-3 px-3 text-right">Verification Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/[0.04]">
              {pendingDeposits.map((dep) => {
                const isCardPurchase = Boolean(dep.cardName || dep.cardId);
                return (
                  <tr key={dep.id} className="hover:bg-slate-800/40 transition-colors">
                    {/* Order ID & Type */}
                    <td className="py-3.5 px-3">
                      <div className="font-mono font-bold text-slate-200 text-xs">{dep.id}</div>
                      {isCardPurchase ? (
                        <div className="mt-1 inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-purple-500/10 border border-purple-500/20 text-purple-300 text-[10px] font-semibold">
                          <CreditCard className="w-3 h-3 text-purple-400" />
                          <span>{dep.cardName || 'Card Purchase'}</span>
                        </div>
                      ) : (
                        <div className="mt-1 inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 text-[10px] font-semibold">
                          <Wallet className="w-3 h-3 text-emerald-400" />
                          <span>Wallet Deposit</span>
                        </div>
                      )}
                    </td>

                    {/* Customer */}
                    <td className="py-3.5 px-3">
                      <p className="text-white font-bold">{dep.userName || dep.username || 'User'}</p>
                      <p className="text-[11px] text-slate-400 font-mono">{dep.userEmail || dep.userId}</p>
                    </td>

                    {/* Amount */}
                    <td className="py-3.5 px-3 font-mono">
                      <div className="font-bold text-emerald-400 text-sm">
                        ₹{dep.amount.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                      </div>
                      <div className="text-[10px] text-slate-400">
                        ≈ ${formatUSD(dep.amount)} USD
                      </div>
                    </td>

                    {/* 12-Digit UTR */}
                    <td className="py-3.5 px-3">
                      <div className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-slate-950 border border-purple-500/30 text-purple-300 font-mono font-bold text-xs shadow-inner">
                        <span>{dep.referenceNo}</span>
                        <button
                          type="button"
                          onClick={() => handleCopyUtr(dep.referenceNo)}
                          title="Copy UTR number"
                          className="text-slate-400 hover:text-white p-0.5 transition-colors"
                        >
                          {copiedUtr === dep.referenceNo ? (
                            <Check className="w-3.5 h-3.5 text-emerald-400" />
                          ) : (
                            <Copy className="w-3.5 h-3.5" />
                          )}
                        </button>
                      </div>
                    </td>

                    {/* Proof Screenshot */}
                    <td className="py-3.5 px-3">
                      {dep.proofUrl ? (
                        <button
                          type="button"
                          onClick={() => setPreviewProof(dep)}
                          className="flex items-center gap-2 group cursor-pointer text-left"
                        >
                          <div className="relative w-10 h-10 rounded-lg overflow-hidden border border-white/10 group-hover:border-purple-500/50 bg-slate-950 shrink-0 shadow-sm">
                            <img
                              src={dep.proofUrl}
                              alt="Payment Screenshot"
                              className="w-full h-full object-cover group-hover:scale-110 transition-transform"
                            />
                            <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                              <Eye className="w-3 h-3 text-white" />
                            </div>
                          </div>
                          <span className="text-[11px] text-purple-400 group-hover:text-purple-300 font-semibold underline flex items-center gap-0.5">
                            View Receipt <ExternalLink className="w-2.5 h-2.5" />
                          </span>
                        </button>
                      ) : (
                        <span className="text-slate-500 text-[11px] italic">No screenshot</span>
                      )}
                    </td>

                    {/* Date */}
                    <td className="py-3.5 px-3 text-slate-400">
                      <div>{new Date(dep.createdAt).toLocaleDateString()}</div>
                      <div className="text-[10px] font-mono text-slate-500">
                        {new Date(dep.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </div>
                    </td>

                    {/* Review Action */}
                    <td className="py-3.5 px-3 text-right">
                      <div className="flex items-center justify-end gap-2">
                        <button
                          onClick={() => handleReviewDeposit(dep.id, 'Approved', dep.cardName)}
                          disabled={actionLoading === dep.id}
                          className="px-3 py-1.5 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs flex items-center gap-1 transition-all active:scale-95 shadow-sm disabled:opacity-50"
                        >
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>Approve</span>
                        </button>
                        <button
                          onClick={() => handleReviewDeposit(dep.id, 'Rejected', dep.cardName)}
                          disabled={actionLoading === dep.id}
                          className="px-3 py-1.5 rounded-lg bg-rose-950/60 hover:bg-rose-900/60 text-rose-300 border border-rose-500/40 text-xs font-semibold flex items-center gap-1 transition-all active:scale-95 disabled:opacity-50"
                        >
                          <XCircle className="w-3.5 h-3.5" />
                          <span>Reject</span>
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}

              {pendingDeposits.length === 0 && (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-slate-500">
                    <ShieldCheck className="w-10 h-10 text-emerald-500/50 mx-auto mb-2" />
                    <p className="text-sm font-bold text-white">Queue Clear!</p>
                    <p className="text-xs text-slate-400 mt-0.5">
                      No pending requests right now. New customer card orders and deposits will appear here automatically in real time.
                    </p>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Proof Preview Modal */}
      {previewProof && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
          <div className="bg-slate-900 border border-white/10 rounded-2xl max-w-xl w-full p-6 space-y-4 shadow-2xl relative">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div>
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <Eye className="w-4 h-4 text-purple-400" />
                  <span>Payment Screenshot Proof</span>
                </h3>
                <p className="text-xs text-slate-400 font-mono mt-0.5">
                  Order ID: {previewProof.id} • UTR: {previewProof.referenceNo}
                </p>
              </div>
              <button
                onClick={() => setPreviewProof(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-white/5"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="rounded-xl overflow-hidden bg-black/60 border border-white/10 max-h-[60vh] flex items-center justify-center p-2">
              <img
                src={previewProof.proofUrl}
                alt="Payment Slip Proof"
                className="max-h-[55vh] w-auto object-contain rounded-lg shadow-lg"
              />
            </div>

            <div className="flex items-center justify-between text-xs pt-2">
              <a
                href={previewProof.proofUrl}
                target="_blank"
                rel="noreferrer"
                className="text-purple-400 hover:underline flex items-center gap-1 font-semibold"
              >
                <span>Open in full resolution</span>
                <ExternalLink className="w-3 h-3" />
              </a>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => handleReviewDeposit(previewProof.id, 'Rejected', previewProof.cardName)}
                  disabled={actionLoading === previewProof.id}
                  className="px-3 py-1.5 rounded-lg bg-rose-950/60 hover:bg-rose-900/60 text-rose-300 border border-rose-500/40 font-semibold"
                >
                  Reject
                </button>
                <button
                  onClick={() => handleReviewDeposit(previewProof.id, 'Approved', previewProof.cardName)}
                  disabled={actionLoading === previewProof.id}
                  className="px-4 py-1.5 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold flex items-center gap-1"
                >
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Approve Payment</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Quick Nav Row for Admin Sections */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        <button
          onClick={() => onNavigate('/admin/users')}
          className="p-5 rounded-2xl bg-slate-900/80 border border-white/[0.08] hover:border-purple-500/40 text-left transition-all group"
        >
          <Users className="w-5 h-5 text-purple-400 mb-2 group-hover:scale-110 transition-transform" />
          <h3 className="text-sm font-bold text-white">Users Directory</h3>
          <p className="text-xs text-slate-400 mt-1">Adjust user balances, toggle statuses, and audit roles</p>
        </button>

        <button
          onClick={() => onNavigate('/admin/deposits')}
          className="p-5 rounded-2xl bg-slate-900/80 border border-white/[0.08] hover:border-purple-500/40 text-left transition-all group"
        >
          <ArrowDownCircle className="w-5 h-5 text-amber-400 mb-2 group-hover:scale-110 transition-transform" />
          <h3 className="text-sm font-bold text-white">Card Orders & Deposits Queue</h3>
          <p className="text-xs text-slate-400 mt-1">Detailed audit ledger with UTR verification & screenshot previews</p>
        </button>

        <button
          onClick={() => onNavigate('/admin/cards')}
          className="p-5 rounded-2xl bg-slate-900/80 border border-white/[0.08] hover:border-purple-500/40 text-left transition-all group sm:col-span-2 lg:col-span-1"
        >
          <CreditCard className="w-5 h-5 text-indigo-400 mb-2 group-hover:scale-110 transition-transform" />
          <h3 className="text-sm font-bold text-white">Premium Cards Catalog</h3>
          <p className="text-xs text-slate-400 mt-1">Generate new cards, freeze credentials, and configure limits</p>
        </button>
      </div>
    </div>
  );
};
