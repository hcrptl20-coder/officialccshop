import React, { useEffect, useState } from 'react';
import { apiRequest } from '../../lib/api.ts';
import { SupportTicket } from '../../types/index.ts';
import { Badge } from '../../components/common/Badge.tsx';
import {
  HelpCircle,
  MessageSquare,
  Send,
  CheckCircle2,
  Clock,
  Filter,
} from 'lucide-react';

export const AdminSupportPage: React.FC = () => {
  const [tickets, setTickets] = useState<SupportTicket[]>([]);
  const [selectedTicket, setSelectedTicket] = useState<SupportTicket | null>(null);
  const [statusFilter, setStatusFilter] = useState('All');
  const [replyMessage, setReplyMessage] = useState('');
  const [isReplying, setIsReplying] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  const fetchTickets = async () => {
    setIsLoading(true);
    try {
      const res = await apiRequest<SupportTicket[]>('/api/admin/support/tickets');
      if (res.ok && res.data) {
        setTickets(res.data);
      }
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchTickets();
  }, []);

  const handleSendReply = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTicket || !replyMessage.trim()) return;

    setIsReplying(true);
    const res = await apiRequest<SupportTicket>(`/api/support/tickets/${selectedTicket.id}/reply`, {
      method: 'POST',
      body: JSON.stringify({ message: replyMessage }),
    });
    setIsReplying(false);

    if (res.ok && res.data) {
      setSelectedTicket(res.data);
      setTickets((prev) => prev.map((t) => (t.id === res.data!.id ? res.data! : t)));
      setReplyMessage('');
    }
  };

  const handleUpdateStatus = async (ticketId: string, newStatus: 'Open' | 'In Progress' | 'Resolved') => {
    const res = await apiRequest<SupportTicket>(`/api/admin/support/tickets/${ticketId}/status`, {
      method: 'POST',
      body: JSON.stringify({ status: newStatus }),
    });

    if (res.ok && res.data) {
      setSelectedTicket(res.data);
      setTickets((prev) => prev.map((t) => (t.id === ticketId ? res.data! : t)));
    }
  };

  const filteredTickets = tickets.filter(
    (t) => statusFilter === 'All' || t.status.toUpperCase() === statusFilter.toUpperCase()
  );

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            Compliance & Helpdesk Dispatch
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Resolve user deposit inquiries, card concerns, and platform questions
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-400">Filter:</span>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-3 py-2 rounded-xl bg-slate-900 border border-white/[0.08] text-white text-xs focus:outline-none focus:border-purple-500/60"
          >
            <option value="All">All Inquiries</option>
            <option value="Open">Open</option>
            <option value="In Progress">In Progress</option>
            <option value="Resolved">Resolved</option>
          </select>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Ticket List */}
        <div className="lg:col-span-5 space-y-3">
          <div className="p-4 rounded-2xl bg-slate-900/80 border border-white/[0.08] backdrop-blur-xl">
            <h2 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3">
              User Ticket Queue ({filteredTickets.length})
            </h2>

            <div className="space-y-2.5">
              {filteredTickets.map((t) => (
                <div
                  key={t.id}
                  onClick={() => setSelectedTicket(t)}
                  className={`p-3.5 rounded-xl border cursor-pointer transition-all ${
                    selectedTicket?.id === t.id
                      ? 'bg-slate-800/80 border-purple-500/40 shadow-sm'
                      : 'bg-slate-950/60 border-white/[0.06] hover:border-white/[0.15]'
                  }`}
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-[10px] font-mono text-purple-300 font-semibold">{t.id}</span>
                    <Badge status={t.status} size="sm" />
                  </div>
                  <h3 className="text-xs font-bold text-white mt-1 line-clamp-1">{t.subject}</h3>
                  <div className="flex items-center justify-between text-[10px] text-slate-400 mt-2">
                    <span className="text-slate-300 font-medium">User: {t.userName}</span>
                    <span className="px-1.5 py-0.5 rounded bg-slate-800">{t.category}</span>
                  </div>
                </div>
              ))}

              {filteredTickets.length === 0 && !isLoading && (
                <div className="text-center py-8 text-slate-500 text-xs">
                  No tickets found in this queue.
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Selected Ticket Thread */}
        <div className="lg:col-span-7">
          {selectedTicket ? (
            <div className="p-6 rounded-2xl bg-slate-900/80 border border-white/[0.08] backdrop-blur-xl space-y-5 flex flex-col h-full min-h-[500px]">
              {/* Header */}
              <div className="border-b border-white/[0.08] pb-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-xs text-purple-300 font-bold">{selectedTicket.id}</span>
                    <Badge status={selectedTicket.status} size="sm" />
                  </div>
                  <h2 className="text-base font-bold text-white mt-1">{selectedTicket.subject}</h2>
                  <p className="text-xs text-slate-400 mt-0.5">
                    User: {selectedTicket.userName} ({selectedTicket.userId}) • Category: {selectedTicket.category}
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <select
                    value={selectedTicket.status}
                    onChange={(e) => handleUpdateStatus(selectedTicket.id, e.target.value as any)}
                    className="px-2.5 py-1.5 rounded-lg bg-slate-950 border border-white/[0.08] text-white text-xs font-semibold"
                  >
                    <option value="Open">Open</option>
                    <option value="In Progress">In Progress</option>
                    <option value="Resolved">Resolved</option>
                  </select>
                </div>
              </div>

              {/* Message Thread */}
              <div className="flex-1 overflow-y-auto space-y-4 pr-1 max-h-[360px]">
                {selectedTicket.replies.map((reply) => (
                  <div
                    key={reply.id}
                    className={`p-4 rounded-xl text-xs space-y-1 ${
                      reply.senderRole === 'admin'
                        ? 'bg-purple-950/20 border border-purple-500/20 ml-4'
                        : 'bg-slate-950 border border-white/[0.06] mr-4'
                    }`}
                  >
                    <div className="flex items-center justify-between text-[11px]">
                      <span
                        className={`font-semibold ${
                          reply.senderRole === 'admin' ? 'text-purple-300' : 'text-emerald-400'
                        }`}
                      >
                        {reply.senderName} {reply.senderRole === 'admin' ? '(Operator/Admin)' : '(Client)'}
                      </span>
                      <span className="text-slate-500 text-[10px]">
                        {new Date(reply.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>
                    <p className="text-slate-300 leading-relaxed whitespace-pre-wrap">{reply.message}</p>
                  </div>
                ))}
              </div>

              {/* Reply Form */}
              <form onSubmit={handleSendReply} className="pt-3 border-t border-white/[0.06] space-y-3">
                <textarea
                  rows={3}
                  required
                  value={replyMessage}
                  onChange={(e) => setReplyMessage(e.target.value)}
                  placeholder="Draft official operator reply to user..."
                  className="w-full p-3 rounded-xl bg-slate-950 border border-white/[0.08] text-white text-xs placeholder-slate-500 focus:outline-none focus:border-purple-500/60"
                />

                <div className="flex justify-end">
                  <button
                    type="submit"
                    disabled={isReplying || !replyMessage.trim()}
                    className="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold transition-all shadow-md shadow-purple-600/20 flex items-center gap-1.5 disabled:opacity-50"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>{isReplying ? 'Dispatching...' : 'Dispatch Reply'}</span>
                  </button>
                </div>
              </form>
            </div>
          ) : (
            <div className="p-12 rounded-2xl bg-slate-900/60 border border-white/[0.06] text-center flex flex-col items-center justify-center min-h-[400px]">
              <MessageSquare className="w-12 h-12 text-slate-700 mb-3" />
              <h3 className="text-sm font-bold text-white">Select a Support Ticket</h3>
              <p className="text-xs text-slate-400 mt-1 max-w-xs">
                Pick a ticket from the left panel to review client inquiries and post resolutions.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
