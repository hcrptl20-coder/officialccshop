import React, { useEffect, useState } from 'react';
import { apiRequest } from '../../lib/api.ts';
import { useAuth } from '../../context/AuthContext.tsx';
import { NotificationItem } from '../../types/index.ts';
import {
  Bell,
  CheckCircle2,
  CheckCheck,
  AlertCircle,
  CreditCard,
  Lock,
  ArrowDownCircle,
  Trash2,
} from 'lucide-react';

export const NotificationsPage: React.FC = () => {
  const { refreshUser } = useAuth();
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const fetchNotifications = async () => {
    setIsLoading(true);
    try {
      const res = await apiRequest<NotificationItem[]>('/api/notifications');
      if (res.ok && res.data) {
        setNotifications(res.data);
      }
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchNotifications();
  }, []);

  const handleMarkAsRead = async (id: string) => {
    const res = await apiRequest(`/api/notifications/${id}/read`, { method: 'POST' });
    if (res.ok) {
      setNotifications((prev) =>
        prev.map((n) => (n.id === id ? { ...n, read: true } : n))
      );
      refreshUser();
    }
  };

  const handleMarkAllRead = async () => {
    const res = await apiRequest('/api/notifications/read-all', { method: 'POST' });
    if (res.ok) {
      setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
      refreshUser();
    }
  };

  const getIcon = (type: NotificationItem['type']) => {
    switch (type) {
      case 'deposit_approved':
        return <CheckCircle2 className="w-4 h-4 text-emerald-400" />;
      case 'deposit_rejected':
        return <AlertCircle className="w-4 h-4 text-rose-400" />;
      case 'card_frozen':
        return <CreditCard className="w-4 h-4 text-amber-400" />;
      case 'password_changed':
      case 'security_alert':
        return <Lock className="w-4 h-4 text-indigo-400" />;
      default:
        return <Bell className="w-4 h-4 text-slate-400" />;
    }
  };

  const unreadCount = notifications.filter((n) => !n.read).length;

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              Activity & Notifications
            </h1>
            {unreadCount > 0 && (
              <span className="px-2 py-0.5 rounded-full text-xs font-bold bg-emerald-500 text-slate-950">
                {unreadCount} new
              </span>
            )}
          </div>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Real-time ledger events, deposit status verifications, and account security signals
          </p>
        </div>

        {unreadCount > 0 && (
          <button
            onClick={handleMarkAllRead}
            className="px-3.5 py-2 rounded-xl text-xs font-semibold bg-slate-900 hover:bg-slate-800 text-slate-300 border border-white/[0.08] flex items-center gap-2 transition-all self-start sm:self-auto"
          >
            <CheckCheck className="w-4 h-4 text-emerald-400" />
            <span>Mark All as Read</span>
          </button>
        )}
      </div>

      {/* Notifications List */}
      <div className="rounded-2xl bg-slate-900/80 border border-white/[0.08] backdrop-blur-xl overflow-hidden shadow-xl divide-y divide-white/[0.04]">
        {notifications.map((item) => (
          <div
            key={item.id}
            className={`p-4 sm:p-5 flex items-start justify-between gap-4 transition-colors ${
              !item.read ? 'bg-slate-800/30' : 'hover:bg-slate-800/20'
            }`}
          >
            <div className="flex items-start gap-3.5">
              <div className="p-2 rounded-xl bg-slate-950 border border-white/[0.08] shrink-0 mt-0.5">
                {getIcon(item.type)}
              </div>
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <h3 className="text-xs sm:text-sm font-bold text-white">{item.title}</h3>
                  {!item.read && (
                    <span className="w-2 h-2 rounded-full bg-emerald-400 shrink-0" />
                  )}
                </div>
                <p className="text-xs text-slate-400 leading-relaxed">{item.message}</p>
                <span className="text-[10px] text-slate-500 font-mono block pt-1">
                  {new Date(item.createdAt).toLocaleDateString()} at{' '}
                  {new Date(item.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </span>
              </div>
            </div>

            {!item.read && (
              <button
                onClick={() => handleMarkAsRead(item.id)}
                className="px-2.5 py-1 rounded-lg bg-slate-950 hover:bg-slate-800 border border-white/[0.06] text-[11px] font-semibold text-slate-300 hover:text-emerald-400 transition-colors shrink-0"
              >
                Mark Read
              </button>
            )}
          </div>
        ))}

        {notifications.length === 0 && !isLoading && (
          <div className="py-12 text-center text-slate-500">
            <Bell className="w-10 h-10 text-slate-700 mx-auto mb-2" />
            <p className="text-xs">No notifications in your terminal inbox.</p>
          </div>
        )}
      </div>
    </div>
  );
};
