import React, { useEffect, useState, useRef } from 'react';
import { apiRequest } from '../../lib/api.ts';
import { PaymentConfig, Deposit } from '../../types/index.ts';
import { Badge } from '../../components/common/Badge.tsx';
import { AirtelUpiQrCard } from '../../components/deposit/AirtelUpiQrCard.tsx';
import { formatINR, formatUSD, formatDualCurrency, USD_EXCHANGE_RATE } from '../../lib/currency.ts';
import {
  ArrowDownCircle,
  QrCode,
  Upload,
  Clock,
  ShieldCheck,
  AlertCircle,
  CheckCircle2,
  FileText,
  Info,
} from 'lucide-react';

interface DepositPageProps {
  onNavigate?: (path: string) => void;
}

export const DepositPage: React.FC<DepositPageProps> = ({ onNavigate }) => {
  const qrCardRef = useRef<HTMLDivElement>(null);
  const [config, setConfig] = useState<PaymentConfig>({
    qrImagePath: '/merchant-qr.png',
    upiId: '',
    displayUpiId: 'Verified Merchant QR',
    paymentInstructions:
      '1. Enter the amount you wish to deposit (Minimum ₹1,000).\n2. Scan the Official QR code using any UPI app (PhonePe, GPay, Paytm, FamPay, Navi).\n3. Pay directly on your scanner.\n4. Copy the 12-digit UPI UTR / Reference ID from your payment receipt.\n5. Paste the UTR below and click Submit Deposit Request.',
    merchantName: 'Official Merchant',
    updatedAt: '',
  });

  const [amount, setAmount] = useState('1000');
  const [referenceNo, setReferenceNo] = useState('');
  const [proofFile, setProofFile] = useState<File | null>(null);
  const [proofUrl, setProofUrl] = useState('');
  const [isUploading, setIsUploading] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [statusMessage, setStatusMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [recentDeposits, setRecentDeposits] = useState<Deposit[]>([]);
  const [dynamicQrUrl, setDynamicQrUrl] = useState<string>('');

  useEffect(() => {
    fetchConfig();
    fetchUserDeposits();
  }, []);

  // Fetch or regenerate dynamic QR when amount changes
  useEffect(() => {
    const num = Number(amount);
    if (num > 0) {
      apiRequest<{ qrDataUrl: string }>(`/api/deposit/generate-qr?amount=${num}`).then((res) => {
        if (res.ok && res.data?.qrDataUrl) {
          setDynamicQrUrl(res.data.qrDataUrl);
        }
      });
    } else {
      // Default QR without fixed amount
      apiRequest<{ qrDataUrl: string }>(`/api/deposit/generate-qr?amount=0`).then((res) => {
        if (res.ok && res.data?.qrDataUrl) {
          setDynamicQrUrl(res.data.qrDataUrl);
        }
      });
    }
  }, [amount]);

  const fetchConfig = async () => {
    const res = await apiRequest<PaymentConfig>('/api/deposit/config');
    if (res.ok && res.data) {
      setConfig(res.data);
    }
  };

  const fetchUserDeposits = async () => {
    const res = await apiRequest<Deposit[]>('/api/deposits');
    if (res.ok && res.data) {
      setRecentDeposits(res.data);
    }
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setProofFile(file);
    setIsUploading(true);

    const formData = new FormData();
    formData.append('file', file);

    const res = await apiRequest<{ url: string }>('/api/upload', {
      method: 'POST',
      body: formData,
    });

    setIsUploading(false);
    if (res.ok && res.data?.url) {
      setProofUrl(res.data.url);
    } else {
      setStatusMessage({ type: 'error', text: res.error || 'Failed to upload proof image.' });
    }
  };

  const handleSubmitDeposit = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatusMessage(null);

    const numAmount = Number(amount);
    if (!numAmount || numAmount < 1000) {
      setStatusMessage({
        type: 'error',
        text: `Minimum deposit amount is ₹1,000 (≈ $${(1000 / USD_EXCHANGE_RATE).toFixed(2)} USD). Please enter ₹1,000 or more.`,
      });
      return;
    }

    if (!referenceNo.trim()) {
      setStatusMessage({ type: 'error', text: 'Please enter the 12-digit transaction reference / UTR number.' });
      return;
    }

    setIsSubmitting(true);
    const res = await apiRequest<{ message: string; deposit: Deposit }>('/api/deposits', {
      method: 'POST',
      body: JSON.stringify({
        amount: numAmount,
        referenceNo: referenceNo.trim(),
        proofUrl,
      }),
    });
    setIsSubmitting(false);

    if (res.ok && res.data) {
      setStatusMessage({
        type: 'success',
        text: `Deposit request of ₹${numAmount.toLocaleString('en-IN')} ($${(numAmount / USD_EXCHANGE_RATE).toFixed(2)} USD) submitted successfully! Your UTR will be verified and balance credited promptly.`,
      });
      setReferenceNo('');
      setProofFile(null);
      setProofUrl('');
      fetchUserDeposits();
    } else {
      setStatusMessage({ type: 'error', text: res.error || 'Failed to submit deposit request.' });
    }
  };

  return (
    <div className="space-y-8 max-w-7xl mx-auto">
      {/* Header with Dual Currency Badge */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              Deposit Funds
            </h1>
            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
              Airtel UPI QR
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Enter deposit amount (Min ₹1,000), tap any UPI app or scan the Airtel Payments Bank QR code, and submit your UTR.
          </p>
        </div>

        {/* Live Exchange Rate Pill */}
        <div className="px-3.5 py-2 rounded-2xl bg-slate-900/90 border border-white/[0.1] backdrop-blur-xl flex items-center gap-2 text-xs font-mono shadow-md self-start sm:self-auto">
          <span className="text-slate-400">Exchange Rate:</span>
          <span className="text-emerald-400 font-bold">1 USD = ₹{USD_EXCHANGE_RATE}</span>
        </div>
      </div>

      {statusMessage && (
        <div
          className={`p-4 rounded-2xl border flex items-start gap-3 ${
            statusMessage.type === 'success'
              ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-300'
              : 'bg-rose-950/40 border-rose-500/40 text-rose-300'
          }`}
        >
          {statusMessage.type === 'success' ? (
            <CheckCircle2 className="w-5 h-5 shrink-0 mt-0.5 text-emerald-400" />
          ) : (
            <AlertCircle className="w-5 h-5 shrink-0 mt-0.5 text-rose-400" />
          )}
          <p className="text-xs leading-relaxed">{statusMessage.text}</p>
        </div>
      )}

      {/* Step 1: Amount Selection Card (Front & Center) */}
      <div className="p-6 rounded-3xl bg-slate-900/90 border border-white/[0.1] backdrop-blur-xl shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <span className="text-xs uppercase tracking-wider font-bold text-emerald-400 block">
              Step 1: Deposit Amount (INR & USD)
            </span>
          </div>
          <div className="text-xs font-mono text-slate-400 flex items-center gap-2">
            <span className="px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/20 font-bold">
              Minimum: ₹1,000
            </span>
            <span>(≈ ${(1000 / USD_EXCHANGE_RATE).toFixed(2)} USD)</span>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-12 gap-4 items-center">
          <div className="sm:col-span-6 relative">
            <span className="absolute inset-y-0 left-0 pl-4 flex items-center text-emerald-400 font-mono font-bold text-xl pointer-events-none">
              ₹
            </span>
            <input
              type="number"
              min="1000"
              step="100"
              required
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="Enter amount (min 1000)"
              className="w-full pl-10 pr-4 py-3.5 rounded-2xl bg-slate-950 border border-white/[0.12] text-white text-xl font-mono font-bold focus:outline-none focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/30 transition-all placeholder:text-slate-600"
            />
            {/* Live Dual Currency Conversion Note under input */}
            <div className="mt-2 flex items-center justify-between text-xs px-1">
              <span className="text-slate-400">Converted Value:</span>
              <span className="font-mono font-bold text-emerald-400">
                ₹{Number(amount || 0).toLocaleString('en-IN')} ≈ {formatUSD(amount)} USD
              </span>
            </div>
          </div>

          {/* Quick Amount Preset Chips (Starts from 1000) */}
          <div className="sm:col-span-6 flex flex-wrap gap-2">
            {[1000, 2000, 5000, 10000, 25000].map((quickAmt) => (
              <button
                key={quickAmt}
                type="button"
                onClick={() => setAmount(String(quickAmt))}
                className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all flex flex-col items-start ${
                  amount === String(quickAmt)
                    ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/20 scale-105'
                    : 'bg-slate-950 hover:bg-slate-800 text-slate-300 border border-white/[0.08]'
                }`}
              >
                <span>₹{quickAmt.toLocaleString('en-IN')}</span>
                <span className={`text-[10px] font-mono ${amount === String(quickAmt) ? 'text-slate-900 font-medium' : 'text-slate-500'}`}>
                  ≈ {formatUSD(quickAmt)}
                </span>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Main 2-Column Grid: Left QR Card, Right UTR Confirmation Form */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column (5 cols): The Exact Airtel Payments Bank QR Code Card */}
        <div ref={qrCardRef} className="lg:col-span-5 space-y-4">
          <div className="flex items-center justify-between px-1">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Step 2: Scan QR to Pay
            </span>
            <span className="text-xs font-semibold text-emerald-400 font-mono">
              Amount: ₹{Number(amount || 0).toLocaleString('en-IN')} ({formatUSD(amount)})
            </span>
          </div>

          <AirtelUpiQrCard
            amount={amount}
            merchantName={config.merchantName || 'Official Merchant'}
            qrDataUrl={(config.useStaticQr && config.staticQrUrl) ? config.staticQrUrl : (dynamicQrUrl || config.qrImagePath || '/merchant-qr.png')}
          />
        </div>

        {/* Right Column (7 cols): Step 3 UTR Reference Confirmation */}
        <div className="lg:col-span-7 space-y-6">
          <div className="p-6 sm:p-7 rounded-3xl bg-slate-900/90 border border-white/[0.1] backdrop-blur-xl shadow-xl space-y-6">
            <div className="border-b border-white/[0.08] pb-4">
              <span className="text-[11px] uppercase tracking-wider font-bold text-emerald-400 block mb-1">
                Step 3: Payment Confirmation
              </span>
              <h2 className="text-lg sm:text-xl font-bold text-white">Enter Transaction UTR Number</h2>
              <p className="text-xs text-slate-400 mt-1">
                Payment karne ke baad apna 12-digit UTR / Reference ID yahan likhein.
              </p>
            </div>

            <form onSubmit={handleSubmitDeposit} className="space-y-5">
              {/* Summary of payment with Dual Currency */}
              <div className="p-4 rounded-2xl bg-slate-950 border border-white/[0.08] flex items-center justify-between">
                <div>
                  <span className="text-[11px] text-slate-400 block">Payable Amount</span>
                  <div className="flex items-baseline gap-2">
                    <span className="text-lg font-extrabold text-emerald-400 font-mono-numbers">
                      ₹{Number(amount || 0).toLocaleString('en-IN')}
                    </span>
                    <span className="text-xs font-mono text-slate-400">
                      (≈ {formatUSD(amount)} USD)
                    </span>
                  </div>
                </div>
                <div className="text-right">
                  <span className="text-[11px] text-slate-400 block">Payment Mode</span>
                  <span className="text-xs font-semibold text-emerald-400 flex items-center justify-end gap-1">
                    <QrCode className="w-3 h-3" />
                    Direct QR Scanner
                  </span>
                </div>
              </div>

              {/* Payment Reference Number */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  12-Digit UTR / Transaction Reference ID <span className="text-rose-400">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={referenceNo}
                  onChange={(e) => setReferenceNo(e.target.value)}
                  placeholder="e.g. 408129038192 or UPI99201"
                  className="w-full px-4 py-3 rounded-xl bg-slate-950 border border-white/[0.1] text-white font-mono text-sm placeholder-slate-500 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500/40"
                />
                <p className="text-[11px] text-slate-500 mt-1.5">
                  PhonePe, GPay, Paytm, FamPay ya Navi payment receipt me 12-digit UTR / Ref No. mil jayega.
                </p>
              </div>

              {/* Upload Payment Proof (optional) */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Upload Payment Screenshot (Optional)
                </label>
                <div className="relative border-2 border-dashed border-white/[0.1] hover:border-emerald-500/40 rounded-xl p-4 text-center transition-colors bg-slate-950/60">
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleFileChange}
                    className="absolute inset-0 opacity-0 cursor-pointer w-full h-full"
                  />
                  <div className="flex flex-col items-center justify-center space-y-1.5 pointer-events-none">
                    <Upload className="w-5 h-5 text-slate-400" />
                    <span className="text-xs font-semibold text-slate-300">
                      {isUploading
                        ? 'Uploading image...'
                        : proofFile
                        ? proofFile.name
                        : 'Click or drag receipt screenshot here'}
                    </span>
                    <span className="text-[10px] text-slate-500">JPG, PNG, or WebP</span>
                  </div>
                </div>

                {proofUrl && (
                  <div className="mt-2 flex items-center gap-2 text-xs text-emerald-400">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Proof attached successfully</span>
                  </div>
                )}
              </div>

              {/* Instructions summary */}
              <div className="p-4 rounded-xl bg-slate-950/60 border border-white/[0.06] text-xs text-slate-400 space-y-1.5 leading-relaxed">
                <span className="font-bold text-slate-200 flex items-center gap-1.5">
                  <Info className="w-4 h-4 text-emerald-400" />
                  <span>Instructions</span>
                </span>
                <p className="text-[11px] text-slate-400">
                  1. Minimum deposit is ₹1,000 (≈ $10.58 USD at ₹94.49/USD).
                  <br />
                  2. Launch PhonePe, GPay, Paytm, FamPay, Navi, or scan the QR above.
                  <br />
                  3. Enter the 12-digit UTR number and click Submit Request.
                </p>
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                disabled={isSubmitting || isUploading}
                className="w-full py-3.5 px-4 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-sm transition-all shadow-lg shadow-emerald-500/25 flex items-center justify-center gap-2 disabled:opacity-50 active:scale-98"
              >
                <ArrowDownCircle className="w-4 h-4" />
                <span>
                  {isSubmitting
                    ? 'Submitting Request...'
                    : `Submit Deposit (₹${Number(amount || 0).toLocaleString('en-IN')} / ${formatUSD(amount)})`}
                </span>
              </button>
            </form>
          </div>
        </div>
      </div>

      {/* Your Recent Deposit Requests Table */}
      <div className="p-6 rounded-3xl bg-slate-900/80 border border-white/[0.08] backdrop-blur-xl space-y-4">
        <h2 className="text-base font-bold text-white flex items-center gap-2">
          <Clock className="w-4 h-4 text-emerald-400" />
          <span>Your Deposit Requests & Status</span>
        </h2>

        {recentDeposits.length === 0 ? (
          <div className="p-8 text-center text-slate-500 text-xs">
            No previous deposit records found. Submit your first deposit above.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-300">
              <thead className="bg-slate-950/50 text-[10px] uppercase font-bold text-slate-400 border-b border-white/[0.06]">
                <tr>
                  <th className="py-3 px-4">Date</th>
                  <th className="py-3 px-4">Amount (INR & USD)</th>
                  <th className="py-3 px-4">UTR Reference</th>
                  <th className="py-3 px-4">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/[0.06]">
                {recentDeposits.map((dep) => (
                  <tr key={dep.id} className="hover:bg-white/[0.02]">
                    <td className="py-3 px-4 text-slate-400">
                      {new Date(dep.createdAt).toLocaleString('en-IN', {
                        day: 'numeric',
                        month: 'short',
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </td>
                    <td className="py-3 px-4">
                      <div className="font-mono font-bold text-white">
                        ₹{dep.amount.toLocaleString('en-IN')}
                      </div>
                      <div className="text-[10px] font-mono text-slate-400">
                        ≈ {formatUSD(dep.amount)} USD
                      </div>
                    </td>
                    <td className="py-3 px-4 font-mono text-emerald-400">
                      {dep.referenceNo}
                    </td>
                    <td className="py-3 px-4">
                      <Badge
                        status={
                          dep.status === 'Approved'
                            ? 'APPROVED'
                            : dep.status === 'Rejected'
                            ? 'REJECTED'
                            : 'PENDING'
                        }
                        size="sm"
                      />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};

