import React from 'react';
import { CardsPage } from './CardsPage.tsx';

interface MyCardsPageProps {
  onNavigate?: (path: string) => void;
}

export const MyCardsPage: React.FC<MyCardsPageProps> = ({ onNavigate }) => {
  return <CardsPage onNavigate={onNavigate} />;
};

export { CardsPage };
