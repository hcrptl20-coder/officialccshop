import React from 'react';
import {
  Send,
  ExternalLink,
  Zap,
  CreditCard,
  ArrowDownCircle,
  Mail,
} from 'lucide-react';

export const SupportPage: React.FC = () => {
  const supportOptions = [
    {
      id: 'telegram',
      name: 'Telegram Support',
      username: '@officialccshopp',
      url: 'https://t.me/officialccshopp',
      icon: Send,
      color: 'text-sky-400',
      bgLight: 'bg-sky-500/10',
      borderLight: 'border-sky-500/20',
      gradient: 'from-sky-500 to-blue-600',
      shadow: 'shadow-sky-500/25',
      description: 'Fastest response time for instant assistance.',
    },    {
      id: 'email',
      name: 'Email Support',
      username: 'support@officialccshop.com',
      url: 'mailto:support@officialccshop.com',
      icon: Mail,
      color: 'text-emerald-400',
      bgLight: 'bg-emerald-500/10',
      borderLight: 'border-emerald-500/20',
      gradient: 'from-emerald-500 to-teal-600',
      shadow: 'shadow-emerald-500/25',
      description: 'For business inquiries and detailed support.',
    },
  ];

  const handleOpen = (url: string) => {
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto px-2 sm:px-4 py-4">
      {/* Top Banner Notice */}
      <div className="p-4 rounded-2xl bg-gradient-to-r from-purple-500/10 via-blue-500/10 to-emerald-500/10 border border-purple-500/20 backdrop-blur-xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-purple-500/20 border border-purple-400/30 flex items-center justify-center text-purple-400 shrink-0">
            <Zap className="w-5 h-5 ml-0.5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-sm font-bold text-white">Official Support Center</h2>
              <span className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 text-[10px] font-bold border border-emerald-500/30">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                Online
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              All customer queries, verification, and assistance are handled via our official channels.
            </p>
          </div>
        </div>
      </div>

      {/* Main Support Options */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {supportOptions.map((option) => (
          <div key={option.id} className={`p-5 rounded-3xl bg-slate-900/90 border border-white/[0.09] shadow-2xl relative overflow-hidden flex flex-col items-center text-center`}>
            {/* Background ambient lighting */}
            <div className={`absolute top-0 right-0 w-32 h-32 ${option.bgLight} rounded-full blur-2xl pointer-events-none -mr-10 -mt-10`} />
            
            {/* Icon Visual */}
            <div className={`w-16 h-16 rounded-2xl bg-gradient-to-tr ${option.gradient} p-0.5 shadow-xl ${option.shadow} mb-4`}>
              <div className="w-full h-full bg-slate-950 rounded-[14px] flex items-center justify-center">
                <option.icon className={`w-7 h-7 ${option.color}`} />
              </div>
            </div>

            <span className={`text-[10px] font-bold uppercase tracking-wider ${option.color} ${option.bgLight} px-3 py-1 rounded-full border ${option.borderLight} mb-2`}>
              {option.name}
            </span>

            <h2 className="text-lg font-extrabold text-white tracking-tight mt-1">
              {option.username}
            </h2>

            <p className="text-xs text-slate-400 mt-2 leading-relaxed flex-1">
              {option.description}
            </p>

            <button
              onClick={() => handleOpen(option.url)}
              className={`mt-5 w-full py-3 px-4 rounded-xl bg-gradient-to-r ${option.gradient} text-white font-bold text-xs shadow-lg ${option.shadow} flex items-center justify-center gap-2 transition-all active:scale-95 group`}
            >
              <span>Connect Now</span>
              <ExternalLink className="w-3.5 h-3.5 opacity-75 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
            </button>
          </div>
        ))}
      </div>

      {/* Quick Assistance Features */}
      <div className="mt-8 pt-8 border-t border-white/[0.08] grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="p-4 rounded-2xl bg-slate-950/50 border border-white/[0.05] flex items-start gap-3">
          <div className="w-9 h-9 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400 shrink-0 mt-0.5">
            <ArrowDownCircle className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-xs font-bold text-white">Deposit Verification</h3>
            <p className="text-[11px] text-slate-400 mt-0.5 leading-normal">
              Submit your 12-digit UPI UTR number and payment screenshot for quick manual balance approval.
            </p>
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-slate-950/50 border border-white/[0.05] flex items-start gap-3">
          <div className="w-9 h-9 rounded-xl bg-sky-500/10 border border-sky-500/20 flex items-center justify-center text-sky-400 shrink-0 mt-0.5">
            <CreditCard className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-xs font-bold text-white">Virtual Card Support</h3>
            <p className="text-[11px] text-slate-400 mt-0.5 leading-normal">
              Assistance with instant card freeze/unfreeze, custom spending limits, and billing details.
            </p>
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-slate-950/50 border border-white/[0.05] flex items-start gap-3">
          <div className="w-9 h-9 rounded-xl bg-purple-500/10 border border-purple-500/20 flex items-center justify-center text-purple-400 shrink-0 mt-0.5">
            <Zap className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-xs font-bold text-white">Fast Response Times</h3>
            <p className="text-[11px] text-slate-400 mt-0.5 leading-normal">
              Direct one-on-one communication with no waiting queues or automated bots.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
