import React, { useEffect, useState } from 'react';
import { useAuth } from '../../context/AuthContext.tsx';
import { apiRequest } from '../../lib/api.ts';
import { CardCard, Transaction, Deposit } from '../../types/index.ts';
import { Badge } from '../../components/common/Badge.tsx';
import { VirtualCardVisual } from '../../components/cards/VirtualCardVisual.tsx';
import { formatUSD, formatINR, formatDualCurrency, USD_EXCHANGE_RATE } from '../../lib/currency.ts';
import {
  Wallet,
  ArrowDownCircle,
  ArrowUpRight,
  CreditCard,
  Clock,
  ShieldCheck,
  TrendingUp,
  RefreshCw,
  Plus,
  AlertCircle,
  ChevronRight,
  Sparkles,
} from 'lucide-react';

interface DashboardPageProps {
  onNavigate: (path: string) => void;
}

export const DashboardPage: React.FC<DashboardPageProps> = ({ onNavigate }) => {
  const { user, refreshUser } = useAuth();
  const [cards, setCards] = useState<CardCard[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [deposits, setDeposits] = useState<Deposit[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);

  const loadData = async () => {
    try {
      const [cardsRes, txnsRes, depositsRes] = await Promise.all([
        apiRequest<CardCard[]>('/api/cards'),
        apiRequest<Transaction[]>('/api/transactions'),
        apiRequest<Deposit[]>('/api/deposits'),
      ]);

      if (cardsRes.ok && cardsRes.data) setCards(cardsRes.data);
      if (txnsRes.ok && txnsRes.data) setTransactions(txnsRes.data);
      if (depositsRes.ok && depositsRes.data) setDeposits(depositsRes.data);
    } finally {
      setIsLoading(false);
      setIsRefreshing(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleRefresh = async () => {
    setIsRefreshing(true);
    await Promise.all([refreshUser(), loadData()]);
  };

  const handleToggleFreeze = async (cardId: string) => {
    const res = await apiRequest<CardCard>(`/api/cards/${cardId}/toggle-freeze`, {
      method: 'POST',
    });
    if (res.ok && res.data) {
      setCards((prev) => prev.map((c) => (c.id === cardId ? res.data! : c)));
    }
  };

  // Calculations for dashboard summary cards
  const totalApprovedDeposits = deposits
    .filter((d) => d.status === 'Approved')
    .reduce((sum, d) => sum + d.amount, 0);

  const pendingDepositsCount = deposits.filter((d) => d.status === 'Pending').length;

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* Header Bar with Welcome & Refresh */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            Terminal Dashboard
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Welcome back, <span className="text-white font-semibold">{user?.name}</span>. Here is your sandbox financial summary.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleRefresh}
            disabled={isRefreshing}
            className="px-3 py-2 rounded-xl text-xs font-semibold bg-slate-900 hover:bg-slate-800 text-slate-300 border border-white/[0.08] transition-all flex items-center gap-1.5 shadow-sm active:scale-95"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin text-emerald-400' : ''}`} />
            <span>{isRefreshing ? 'Updating...' : 'Sync Data'}</span>
          </button>

          <button
            onClick={() => onNavigate('/deposit')}
            className="px-4 py-2 rounded-xl text-xs font-bold bg-emerald-500 hover:bg-emerald-400 text-slate-950 transition-all shadow-md shadow-emerald-500/20 flex items-center gap-1.5 active:scale-95"
          >
            <ArrowDownCircle className="w-4 h-4" />
            <span>Deposit Funds</span>
          </button>
        </div>
      </div>

      {/* 4 Dashboard Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* 1. Available Balance */}
        <div className="p-5 rounded-2xl bg-slate-900/80 border border-emerald-500/20 backdrop-blur-xl shadow-xl relative overflow-hidden group">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400">Available Balance</span>
            <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
              <Wallet className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl sm:text-3xl font-extrabold text-white font-mono-numbers">
              ₹{user?.balance?.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) || '0.00'}
            </div>
            <div className="text-xs font-mono font-bold text-emerald-400 mt-1">
              ≈ ${((user?.balance || 0) / USD_EXCHANGE_RATE).toFixed(2)} USD
              <span className="text-[10px] text-slate-400 font-sans ml-1.5 font-normal">
                (1 USD = ₹{USD_EXCHANGE_RATE})
              </span>
            </div>
            <div className="mt-2 flex items-center gap-1.5 text-[11px] text-emerald-400 font-semibold">
              <TrendingUp className="w-3.5 h-3.5" />
              <span>100% Sandbox Liquid</span>
            </div>
          </div>
        </div>

        {/* 2. Total Deposits */}
        <div className="p-5 rounded-2xl bg-slate-900/80 border border-white/[0.08] backdrop-blur-xl shadow-xl">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400">Total Deposits</span>
            <div className="p-2 rounded-xl bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
              <ArrowDownCircle className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl sm:text-3xl font-extrabold text-white font-mono-numbers">
              ₹{totalApprovedDeposits.toLocaleString('en-IN')}
            </div>
            <div className="text-xs font-mono text-cyan-400 mt-1">
              ≈ {formatUSD(totalApprovedDeposits)} USD
            </div>
            <div className="mt-2 flex items-center gap-1.5 text-[11px] text-slate-400">
              {pendingDepositsCount > 0 ? (
                <span className="text-amber-400 font-semibold">
                  {pendingDepositsCount} pending review
                </span>
              ) : (
                <span>All settlements verified</span>
              )}
            </div>
          </div>
        </div>

        {/* 3. Total Transactions */}
        <div className="p-5 rounded-2xl bg-slate-900/80 border border-white/[0.08] backdrop-blur-xl shadow-xl">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400">Total Transactions</span>
            <div className="p-2 rounded-xl bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
              <Clock className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <div className="text-2xl sm:text-3xl font-extrabold text-white font-mono-numbers">
              {transactions.length}
            </div>
            <div className="mt-2 flex items-center gap-1 text-[11px] text-slate-400">
              <span>All recorded ledger events</span>
            </div>
          </div>
        </div>

        {/* 4. Account Status */}
        <div className="p-5 rounded-2xl bg-slate-900/80 border border-white/[0.08] backdrop-blur-xl shadow-xl">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400">Account Status</span>
            <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
              <ShieldCheck className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3">
            <div className="flex items-center gap-2">
              <span className="text-lg sm:text-xl font-bold text-white capitalize">
                {user?.status || 'Active'}
              </span>
              <Badge status={user?.status === 'active' ? 'ACTIVE' : 'SUSPENDED'} size="sm" />
            </div>
            <div className="mt-2 flex items-center gap-1.5 text-[11px] text-slate-400">
              <span>Active Account</span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Row: Virtual Card Feature & Quick Deposit banner */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Primary Virtual Card */}
        <div className="lg:col-span-2 rounded-2xl bg-slate-900/80 border border-white/[0.08] p-6 backdrop-blur-xl space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                <CreditCard className="w-4 h-4 text-emerald-400" />
                <span>Primary Virtual Premium Card</span>
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Clearly labeled test instrument. Never displays real financial credentials.
              </p>
            </div>

            <button
              onClick={() => onNavigate('/cards')}
              className="text-xs font-semibold text-emerald-400 hover:text-emerald-300 flex items-center gap-1"
            >
              <span>Manage Cards ({cards.length})</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {cards.length > 0 ? (
            <div className="pt-2 flex flex-col md:flex-row items-center gap-6">
              <div className="w-full md:w-auto shrink-0 flex justify-center">
                <VirtualCardVisual
                  card={cards[0]}
                  onToggleFreeze={handleToggleFreeze}
                  onViewDetails={() => onNavigate('/cards')}
                />
              </div>

              <div className="flex-1 space-y-3 w-full">
                <div className="p-3.5 rounded-xl bg-slate-950/80 border border-white/[0.06] space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-400">Spending Limit</span>
                    <span className="font-mono text-white font-semibold">
                      ₹{cards[0].spendingLimit.toLocaleString()} <span className="text-[11px] text-slate-500 font-normal">(${formatUSD(cards[0].spendingLimit)})</span>
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-400">Spent This Month</span>
                    <span className="font-mono text-emerald-400 font-semibold">
                      ₹{cards[0].spentAmount.toLocaleString()} <span className="text-[11px] text-emerald-400/70 font-normal">(${formatUSD(cards[0].spentAmount)})</span>
                    </span>
                  </div>
                  <div className="w-full bg-slate-800 rounded-full h-1.5 mt-2 overflow-hidden">
                    <div
                      className="bg-emerald-500 h-1.5 rounded-full"
                      style={{
                        width: `${Math.min(100, (cards[0].spentAmount / cards[0].spendingLimit) * 100)}%`,
                      }}
                    />
                  </div>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-950/80 border border-white/[0.06] space-y-1 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400">Authorization Mode</span>
                    <span className="text-emerald-400 font-semibold">Instant Mock Token</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400">Cardholder</span>
                    <span className="text-white font-mono uppercase">{cards[0].cardholderName}</span>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="text-center py-8 text-slate-400">
              <CreditCard className="w-8 h-8 text-slate-600 mx-auto mb-2" />
              <p className="text-xs">No active card cards found.</p>
              <button
                onClick={() => onNavigate('/cards')}
                className="relative mt-3 px-4 py-2 rounded-xl font-bold text-xs transition-all group border border-white/10 overflow-hidden"
              >
                <div className="absolute inset-0 bg-gradient-to-r from-pink-600 via-purple-600 to-cyan-600 opacity-80 group-hover:opacity-100 transition-opacity"></div>
                <span className="relative flex items-center justify-center gap-1.5 text-white drop-shadow-md">
                  <Sparkles className="w-3.5 h-3.5 text-pink-200" />
                  Browse 1000+ Premium Cards
                </span>
              </button>
            </div>
          )}
        </div>

        {/* Right Col: Quick Actions & Compliance note */}
        <div className="space-y-4">
          <div className="rounded-2xl bg-gradient-to-br from-slate-900 to-emerald-950/30 border border-emerald-500/20 p-5 backdrop-blur-xl space-y-3">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <ArrowDownCircle className="w-4 h-4 text-emerald-400" />
              <span>Instant Deposit Workflow</span>
            </h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              Deposit via operator UPI QR code. Submit your UTR/Reference to trigger admin review and ledger crediting.
            </p>
            <button
              onClick={() => onNavigate('/deposit')}
              className="w-full py-2.5 px-4 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-bold transition-all shadow-md shadow-emerald-500/20 flex items-center justify-center gap-2"
            >
              <span>Go to Scan & Pay</span>
              <ArrowUpRight className="w-4 h-4" />
            </button>
          </div>

          <div className="rounded-2xl bg-slate-900/80 border border-white/[0.08] p-5 backdrop-blur-xl space-y-3">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-slate-300" />
              <span>Security & Sandbox Rules</span>
            </h3>
            <ul className="text-xs text-slate-400 space-y-2">
              <li className="flex items-start gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 mt-1.5 shrink-0" />
                <span>Zero real card numbers or CVV collection</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 mt-1.5 shrink-0" />
                <span>Legitimate manual deposit verification flow</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 mt-1.5 shrink-0" />
                <span>Bcrypt encrypted session security</span>
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* Recent Transactions Table */}
      <div className="rounded-2xl bg-slate-900/80 border border-white/[0.08] backdrop-blur-xl p-6 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              <Clock className="w-4 h-4 text-emerald-400" />
              <span>Recent Transactions</span>
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Live settlement audits and simulated virtual card authorizations
            </p>
          </div>

          <button
            onClick={() => onNavigate('/transactions')}
            className="text-xs font-semibold text-emerald-400 hover:text-emerald-300 flex items-center gap-1 self-start sm:self-auto"
          >
            <span>View All Transactions</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Responsive Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-white/[0.06] text-slate-400 font-semibold uppercase tracking-wider text-[10px]">
                <th className="py-3 px-3">Transaction ID</th>
                <th className="py-3 px-3">Type</th>
                <th className="py-3 px-3">Amount</th>
                <th className="py-3 px-3">Status</th>
                <th className="py-3 px-3">Reference</th>
                <th className="py-3 px-3 text-right">Date</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/[0.04]">
              {transactions.slice(0, 6).map((txn) => (
                <tr key={txn.id} className="hover:bg-slate-800/40 transition-colors">
                  <td className="py-3.5 px-3 font-mono text-slate-300 font-medium">
                    {txn.id}
                  </td>
                  <td className="py-3.5 px-3 text-white font-medium">
                    {txn.type}
                  </td>
                  <td className="py-3.5 px-3 font-mono font-bold">
                    <div
                      className={
                        txn.amount > 0 ? 'text-emerald-400' : 'text-slate-300'
                      }
                    >
                      {txn.amount > 0 ? `+₹${txn.amount.toLocaleString()}` : `-₹${Math.abs(txn.amount).toLocaleString()}`}
                    </div>
                    <div className="text-[10px] font-mono text-slate-500 font-normal">
                      {txn.amount > 0 ? `+$${(txn.amount / USD_EXCHANGE_RATE).toFixed(2)}` : `-$${(Math.abs(txn.amount) / USD_EXCHANGE_RATE).toFixed(2)}`}
                    </div>
                  </td>
                  <td className="py-3.5 px-3">
                    <Badge status={txn.status} size="sm" />
                  </td>
                  <td className="py-3.5 px-3 font-mono text-slate-400">
                    {txn.reference}
                  </td>
                  <td className="py-3.5 px-3 text-right text-slate-400 whitespace-nowrap">
                    {new Date(txn.date).toLocaleDateString()} {new Date(txn.date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </td>
                </tr>
              ))}

              {transactions.length === 0 && (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-slate-500">
                    No transactions recorded yet. Submit a deposit to test the workflow.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
