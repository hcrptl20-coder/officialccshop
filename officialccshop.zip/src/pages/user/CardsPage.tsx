import React, { useEffect, useState, useMemo } from 'react';
import { useAuth } from '../../context/AuthContext.tsx';
import { apiRequest } from '../../lib/api.ts';
import { CardCard } from '../../types/index.ts';
import { AVAILABLE_MARKET_CARDS, CardMarketCard } from '../../data/demoCards.ts';
import { PlasticSharkCardVisual } from '../../components/cards/PlasticSharkCardVisual.tsx';
import { CardDetailModal } from '../../components/cards/CardDetailModal.tsx';
import { CartDrawer } from '../../components/cards/CartDrawer.tsx';
import { VirtualCardVisual } from '../../components/cards/VirtualCardVisual.tsx';
import {
  CreditCard,
  Search,
  Filter,
  ShoppingCart,
  Plus,
  ShieldCheck,
  Wallet,
  ArrowRight,
  CheckCircle2,
  Sparkles,
  SlidersHorizontal,
  RefreshCw,
  Crown,
  Zap,
  Star,
  Check,
} from 'lucide-react';

interface CardsPageProps {
  onNavigate?: (path: string) => void;
}

export const CardsPage: React.FC<CardsPageProps> = ({ onNavigate }) => {
  const { user, refreshUser } = useAuth();

  // Navigation helper
  const navigateTo = (path: string) => {
    if (onNavigate) {
      onNavigate(path);
    } else {
      window.location.hash = path;
    }
  };

  // Purchased cards from backend
  const [purchasedCards, setPurchasedCards] = useState<CardCard[]>([]);
  const [isLoadingPurchased, setIsLoadingPurchased] = useState(true);
  const [isActionLoading, setIsActionLoading] = useState(false);

  // Active view tab: 'all' (100 market cards) or 'my' (purchased/active cards) or 'visa' (promo visa cards)
  const [activeTab, setActiveTab] = useState<'all' | 'my' | 'visa'>('all');

  // Search & Filter states
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedProvider, setSelectedProvider] = useState<string>('all');
  const [selectedCountry, setSelectedCountry] = useState<string>('all');
  const [selectedType, setSelectedType] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'default' | 'price-asc' | 'price-desc' | 'limit-desc'>('default');

  // Interactive Card Detail Modal
  const [selectedMarketCard, setSelectedMarketCard] = useState<CardMarketCard | null>(null);
  const [isDetailModalOpen, setIsDetailModalOpen] = useState(false);

  // Cart state
  const [cartItems, setCartItems] = useState<CardMarketCard[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);

  // Success toast
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Fetch user's purchased/created cards
  const fetchPurchasedCards = async () => {
    try {
      const res = await apiRequest<CardCard[]>('/api/cards');
      if (res.ok && res.data) {
        setPurchasedCards(res.data);
      }
    } finally {
      setIsLoadingPurchased(false);
    }
  };

  useEffect(() => {
    fetchPurchasedCards();
  }, []);

  // Pinned VIP Card reference
  const vipCard = useMemo(
    () => AVAILABLE_MARKET_CARDS.find((c) => c.isVip) || AVAILABLE_MARKET_CARDS[0],
    []
  );

  // Filtered & Sorted Market Cards
  const filteredMarketCards = useMemo(() => {
    return AVAILABLE_MARKET_CARDS.filter((card) => {
      // Search
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchesCardId = card.cardCode.toLowerCase().includes(q);
        const matchesProvider = card.provider.toLowerCase().includes(q);
        const matchesCountry = card.country.toLowerCase().includes(q);
        const matchesState = card.state.toLowerCase().includes(q);
        const matchesName = card.name.toLowerCase().includes(q);
        const matchesBank = card.bank.toLowerCase().includes(q);
        const matchesExtras = card.extras.toLowerCase().includes(q);
        const matchesLast4 = card.last4.includes(q);
        if (
          !matchesCardId &&
          !matchesProvider &&
          !matchesCountry &&
          !matchesState &&
          !matchesName &&
          !matchesBank &&
          !matchesExtras &&
          !matchesLast4
        ) {
          return false;
        }
      }

      // Provider filter
      if (selectedProvider !== 'all' && card.provider.toLowerCase() !== selectedProvider.toLowerCase()) {
        return false;
      }

      // Country filter
      if (selectedCountry !== 'all' && card.country.toUpperCase() !== selectedCountry.toUpperCase()) {
        return false;
      }

      // Type filter
      if (selectedType !== 'all' && card.cardType.toLowerCase() !== selectedType.toLowerCase()) {
        return false;
      }

      // Exclude promo visa cards from standard market cards view
      if (card.isPromoVisa) return false;

      return true;
    }).sort((a, b) => {
      // Pin VIP card at the very top on default sort
      if (sortBy === 'default') {
        if (a.isVip) return -1;
        if (b.isVip) return 1;
        return 0;
      }
      if (sortBy === 'price-asc') return a.priceUsd - b.priceUsd;
      if (sortBy === 'price-desc') return b.priceUsd - a.priceUsd;
      if (sortBy === 'limit-desc') return b.limitUsd - a.limitUsd;
      return 0; // default index order
    });
  }, [searchQuery, selectedProvider, selectedCountry, selectedType, sortBy]);

  // Visa Promo Cards
  const visaPromoCards = useMemo(() => {
    return AVAILABLE_MARKET_CARDS.filter((card) => card.isPromoVisa).sort((a, b) => a.priceUsd - b.priceUsd);
  }, []);

  // Standard Market Cards Count (excluding promo)
  const allMarketCardsCount = useMemo(() => AVAILABLE_MARKET_CARDS.filter(c => !c.isPromoVisa).length, []);

  // Handle Add To Cart
  const handleAddToCart = (card: CardMarketCard) => {
    if (cartItems.some((item) => item.id === card.id)) {
      setCartItems((prev) => prev.filter((item) => item.id !== card.id));
    } else {
      setCartItems((prev) => [...prev, card]);
      setToastMessage(`Added ${card.cardCode} to your cart`);
      setTimeout(() => setToastMessage(null), 2500);
    }
  };

  // Handle Card Click (Opens modal in screenshot style)
  const handleCardClick = (card: CardMarketCard) => {
    setSelectedMarketCard(card);
    setIsDetailModalOpen(true);
  };

  // Handle Buy Now (Opens detail modal with purchase flow)
  const handleBuyNow = (card: CardMarketCard) => {
    setSelectedMarketCard(card);
    setIsDetailModalOpen(true);
  };

  // Purchase Success Callback
  const handlePurchaseSuccess = (purchasedCard: CardCard | CardCard[], newBalance: number) => {
    if (Array.isArray(purchasedCard)) {
      setPurchasedCards((prev) => [...purchasedCard, ...prev]);
      setToastMessage(`Successfully purchased ${purchasedCard.length} card(s)!`);
    } else {
      setPurchasedCards((prev) => [purchasedCard, ...prev]);
      setToastMessage(`Successfully purchased card card ${purchasedCard.cardCode || ''}!`);
    }
    refreshUser();
    setTimeout(() => setToastMessage(null), 3500);
  };

  // Toggle freeze for user's active cards
  const handleToggleFreeze = async (cardId: string) => {
    setIsActionLoading(true);
    const res = await apiRequest<CardCard>(`/api/cards/${cardId}/toggle-freeze`, {
      method: 'POST',
    });
    setIsActionLoading(false);
    if (res.ok && res.data) {
      setPurchasedCards((prev) => prev.map((c) => (c.id === cardId ? res.data! : c)));
    }
  };

  // Check if a card card is already purchased by current user
  const isCardPurchased = (cardCode: string) => {
    return purchasedCards.some((c) => c.cardCode === cardCode || c.id === `crd-${cardCode}`);
  };

  const getPurchasedCardData = (cardCode: string) => {
    return purchasedCards.find((c) => c.cardCode === cardCode || c.id === `crd-${cardCode}`) || null;
  };

  return (
    <div className="space-y-8 max-w-7xl mx-auto pb-16">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-20 right-4 sm:right-8 z-50 p-4 rounded-2xl bg-[#161726] border border-emerald-500/30 text-white shadow-2xl flex items-center gap-3 animate-fadeIn">
          <div className="p-2 rounded-xl bg-emerald-500/20 text-emerald-400">
            <CheckCircle2 className="w-5 h-5" />
          </div>
          <span className="text-sm font-semibold">{toastMessage}</span>
        </div>
      )}

      {/* Page Header */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <div className="flex flex-col sm:flex-row sm:items-end gap-5">
            <div className="relative group cursor-default">
              <div className="absolute -inset-2 bg-gradient-to-r from-cyan-600 via-fuchsia-600 to-pink-600 rounded-2xl blur-xl opacity-70 group-hover:opacity-100 transition duration-1000 animate-pulse"></div>
              <h1 className="relative text-5xl sm:text-6xl font-black uppercase tracking-tighter text-transparent bg-clip-text bg-gradient-to-r from-cyan-300 via-fuchsia-300 to-pink-300 drop-shadow-[0_0_20px_rgba(236,72,153,0.9)] flex items-center">
                CARDS
              </h1>
            </div>
            
            <div className="relative group cursor-default mb-2">
              <div className="absolute -inset-0.5 bg-gradient-to-r from-pink-600 via-purple-600 to-cyan-600 rounded-full blur opacity-90 group-hover:opacity-100 transition duration-1000 group-hover:duration-200 animate-pulse"></div>
              <span className="relative px-4 py-1.5 rounded-full text-sm font-black uppercase bg-slate-950 flex items-center gap-2 text-transparent bg-clip-text bg-gradient-to-r from-pink-400 via-fuchsia-400 to-cyan-400 border border-white/20 shadow-[inset_0_0_15px_rgba(255,255,255,0.1)]">
                <Sparkles className="w-4 h-4 text-fuchsia-400" />
                1000+ Virtual Premium Cards
              </span>
            </div>
          </div>
          <p className="text-sm text-slate-400 mt-4 max-w-2xl leading-relaxed relative inline-block">
            <span className="absolute -inset-1 bg-gradient-to-r from-cyan-600 via-purple-600 to-pink-600 blur opacity-40 rounded-lg animate-pulse"></span>
            <span className="relative inline-block bg-gradient-to-r from-cyan-300 via-purple-300 to-pink-300 bg-clip-text text-transparent font-black animate-gradient-x text-lg sm:text-xl tracking-widest drop-shadow-[0_0_10px_rgba(192,132,252,0.8)] uppercase">
              ✦ All Premium and Virtual Cards ✦
            </span>
          </p>
        </div>

        <div className="flex items-center gap-3">
          {/* Cart Button */}
          <button
            type="button"
            onClick={() => setIsCartOpen(true)}
            className="relative px-4 py-2.5 rounded-2xl bg-slate-900/80 hover:bg-slate-850 border border-white/[0.1] text-white text-xs font-bold flex items-center gap-2 transition-all active:scale-95 shadow-md"
          >
            <ShoppingCart className="w-4 h-4 text-cyan-400" />
            <span>Cart</span>
            {cartItems.length > 0 && (
              <span className="w-5 h-5 rounded-full bg-cyan-500 text-slate-950 text-[11px] font-extrabold flex items-center justify-center">
                {cartItems.length}
              </span>
            )}
          </button>

          {/* Deposit Button */}
          <button
            type="button"
            onClick={() => navigateTo('/deposit')}
            className="px-4 py-2.5 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 text-xs font-bold transition-all shadow-md shadow-emerald-500/20 flex items-center gap-2 active:scale-95"
          >
            <Wallet className="w-4 h-4" />
            <span>Deposit Funds (Min ₹1,000)</span>
          </button>
        </div>
      </div>

      {/* Available Balance & Exchange Rate Bar */}
      <div className="p-4 sm:p-5 rounded-3xl bg-[#161726]/80 border border-white/[0.08] backdrop-blur-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <div className="w-11 h-11 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0">
            <Wallet className="w-5 h-5" />
          </div>
          <div>
            <span className="text-xs text-slate-400 block font-medium">Your Account Balance</span>
            <div className="flex items-baseline gap-2 mt-0.5">
              <span className="font-mono font-extrabold text-xl sm:text-2xl text-white">
                ₹{(user?.balance ?? 0).toLocaleString('en-IN', { minimumFractionDigits: 2 })} INR
              </span>
              <span className="font-mono text-xs sm:text-sm text-slate-400">
                ($ {((user?.balance ?? 0) / 94.49).toFixed(2)} USD)
              </span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2 text-xs">
          <div className="px-3 py-1.5 rounded-xl bg-white/[0.04] border border-white/[0.06] text-slate-300">
            Exchange Rate: <span className="text-emerald-400 font-mono font-bold">$1 USD = ₹94.49 INR</span>
          </div>
          <div className="px-3 py-1.5 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 font-semibold">
            Min Deposit: ₹1,000
          </div>
        </div>
      </div>

      {/* Tabs Navigation */}
      <div className="flex items-center justify-between border-b border-white/[0.08] pb-1">
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setActiveTab('all')}
            className={`px-4 py-2.5 rounded-2xl text-xs sm:text-sm font-bold transition-all flex items-center gap-2 ${
              activeTab === 'all'
                ? 'bg-cyan-500/15 text-cyan-300 border border-cyan-500/30 shadow-sm'
                : 'text-slate-400 hover:text-white hover:bg-white/[0.04]'
            }`}
          >
            <span>All Premium Cards</span>
            <span className="px-2 py-0.5 rounded-full text-[10px] bg-white/[0.08] text-slate-300">
              {allMarketCardsCount}
            </span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('visa')}
            className={`px-4 py-2.5 rounded-2xl text-xs sm:text-sm font-bold transition-all flex items-center gap-2 ${
              activeTab === 'visa'
                ? 'bg-amber-500/15 text-amber-300 border border-amber-500/30 shadow-sm'
                : 'text-slate-400 hover:text-white hover:bg-white/[0.04]'
            }`}
          >
            <span>Visa Cards</span>
            <span className="px-2 py-0.5 rounded-full text-[10px] bg-white/[0.08] text-slate-300">
              {visaPromoCards.length}
            </span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('my')}
            className={`px-4 py-2.5 rounded-2xl text-xs sm:text-sm font-bold transition-all flex items-center gap-2 ${
              activeTab === 'my'
                ? 'bg-cyan-500/15 text-cyan-300 border border-cyan-500/30 shadow-sm'
                : 'text-slate-400 hover:text-white hover:bg-white/[0.04]'
            }`}
          >
            <span>My Purchased Cards</span>
            <span className="px-2 py-0.5 rounded-full text-[10px] bg-white/[0.08] text-slate-300">
              {purchasedCards.length}
            </span>
          </button>
        </div>
      </div>

      {/* Main Tab Content */}
      {activeTab === 'all' ? (
        <div className="space-y-6">
          {/* Top Premium VIP Mastercard Showcase */}
          {vipCard && (
            <div
              id="vip-card-spotlight"
              className="relative rounded-[32px] overflow-hidden p-6 sm:p-8 border-2 border-amber-400/60 shadow-[0_0_45px_rgba(245,158,11,0.22)] group transition-all duration-300"
              style={{
                background:
                  'radial-gradient(ellipse at top right, rgba(245, 158, 11, 0.15) 0%, rgba(26, 27, 46, 0.98) 55%, rgba(15, 16, 28, 1) 100%)',
              }}
            >
              {/* Subtle ambient light effect */}
              <div className="absolute -top-24 -right-24 w-72 h-72 rounded-full bg-amber-500/15 blur-3xl pointer-events-none" />
              <div className="absolute -bottom-24 -left-24 w-72 h-72 rounded-full bg-yellow-500/10 blur-3xl pointer-events-none" />

              <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
                {/* Left Side Info */}
                <div className="space-y-4 max-w-2xl">
                  {/* VIP Badges Row */}
                  <div className="flex flex-wrap items-center gap-2">
                    <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-gradient-to-r from-amber-500/30 via-yellow-500/30 to-amber-500/30 border border-amber-400/60 text-amber-300 text-xs font-black tracking-wider uppercase shadow-md shadow-amber-500/10">
                      <Crown className="w-4 h-4 text-amber-400 fill-amber-400 animate-bounce" />
                      <span>PINNED TOP TIER • VIP MASTERCARD</span>
                    </div>

                    <span className="px-2.5 py-0.5 rounded-full bg-amber-400/10 border border-amber-400/30 text-amber-300 text-[11px] font-bold font-mono">
                      {vipCard.cardCode}
                    </span>

                    <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-[11px] font-bold">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                      <span>VIP Instant Sandbox</span>
                    </span>
                  </div>

                  {/* Card Title & Headline */}
                  <div>
                    <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight flex items-center gap-2">
                      <span>{vipCard.name}</span>
                      <span className="text-amber-400">★</span>
                    </h2>
                    <p className="text-xs sm:text-sm text-slate-300 mt-1.5 leading-relaxed">
                      High-priority virtual credit card for luxury testing and seamless payment checkout. Zero decline guarantee with pre-configured high spending power and instant sandbox credential activation.
                    </p>
                  </div>

                  {/* Feature Spec Badges */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1 text-xs">
                    <div className="p-2.5 rounded-2xl bg-white/[0.04] border border-white/[0.08]">
                      <span className="text-[10px] text-slate-400 uppercase tracking-wider block font-semibold">Spending Limit</span>
                      <span className="font-mono font-black text-amber-300 text-sm mt-0.5 block">${vipCard.limitUsd.toLocaleString()} USD</span>
                    </div>
                    <div className="p-2.5 rounded-2xl bg-white/[0.04] border border-white/[0.08]">
                      <span className="text-[10px] text-slate-400 uppercase tracking-wider block font-semibold">Issuer Bank</span>
                      <span className="font-semibold text-white truncate text-xs mt-0.5 block">{vipCard.bank}</span>
                    </div>
                    <div className="p-2.5 rounded-2xl bg-white/[0.04] border border-white/[0.08]">
                      <span className="text-[10px] text-slate-400 uppercase tracking-wider block font-semibold">Card Number</span>
                      <span className="font-mono font-bold text-slate-200 text-xs mt-0.5 block">{vipCard.last4}</span>
                    </div>
                    <div className="p-2.5 rounded-2xl bg-white/[0.04] border border-white/[0.08]">
                      <span className="text-[10px] text-slate-400 uppercase tracking-wider block font-semibold">Status</span>
                      <span className="font-bold text-amber-400 text-xs mt-0.5 block">0% Decline Rate</span>
                    </div>
                  </div>
                </div>

                {/* Right Side Pricing & Action CTA Box */}
                <div className="lg:w-72 shrink-0 p-5 rounded-3xl bg-slate-950/70 border border-amber-400/40 shadow-xl space-y-4 text-center lg:text-left flex flex-col justify-between">
                  <div>
                    <span className="text-[11px] font-bold text-amber-400/90 uppercase tracking-wider block">
                      Exclusive VIP Price
                    </span>
                    <div className="flex items-baseline justify-center lg:justify-start gap-1.5 mt-1">
                      <span className="font-mono font-extrabold text-3xl sm:text-4xl text-amber-400 drop-shadow-[0_0_15px_rgba(245,158,11,0.4)]">
                        ${vipCard.priceUsd.toFixed(2)}
                      </span>
                      <span className="text-xs font-mono text-slate-400">USD</span>
                    </div>
                    <div className="mt-1">
                      <span className="inline-block px-2.5 py-1 rounded-xl bg-amber-500/15 border border-amber-400/30 text-amber-300 font-mono font-bold text-xs">
                        ₹{vipCard.priceInr.toLocaleString('en-IN', { minimumFractionDigits: 2 })} INR
                      </span>
                    </div>
                  </div>

                  {/* Buttons */}
                  <div className="space-y-2 pt-1">
                    <button
                      type="button"
                      onClick={() => handleBuyNow(vipCard)}
                      className="w-full py-3 px-4 rounded-2xl bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 hover:from-amber-300 hover:to-yellow-300 text-slate-950 font-black text-xs sm:text-sm transition-all shadow-lg shadow-amber-500/30 flex items-center justify-center gap-2 active:scale-95"
                    >
                      <Crown className="w-4 h-4 fill-slate-950 text-slate-950" />
                      <span>Buy VIP Card ($30.00)</span>
                    </button>

                    <div className="grid grid-cols-2 gap-2">
                      <button
                        type="button"
                        onClick={() => handleAddToCart(vipCard)}
                        className={`py-2 px-2 rounded-xl border text-[11px] font-bold transition-all flex items-center justify-center gap-1 active:scale-95 ${
                          cartItems.some((c) => c.id === vipCard.id)
                            ? 'bg-emerald-500/20 border-emerald-500/40 text-emerald-300'
                            : 'bg-white/[0.06] hover:bg-white/[0.1] border-white/[0.1] text-white'
                        }`}
                      >
                        {cartItems.some((c) => c.id === vipCard.id) ? (
                          <>
                            <Check className="w-3.5 h-3.5 text-emerald-400" />
                            <span>In Cart</span>
                          </>
                        ) : (
                          <>
                            <ShoppingCart className="w-3.5 h-3.5 text-amber-400" />
                            <span>Add Cart</span>
                          </>
                        )}
                      </button>

                      <button
                        type="button"
                        onClick={() => handleCardClick(vipCard)}
                        className="py-2 px-2 rounded-xl bg-white/[0.06] hover:bg-white/[0.1] border border-white/[0.1] text-slate-300 hover:text-white text-[11px] font-bold transition-all active:scale-95"
                      >
                        View Details
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Search and Filters Toolbar */}
          <div className="p-4 rounded-3xl bg-[#161726]/70 border border-white/[0.08] backdrop-blur-xl space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
              {/* Search Bar */}
              <div className="relative sm:col-span-2">
                <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Search by Card ID (e.g. CRD-0001), Provider, Country, Bank, Last 4..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 rounded-2xl bg-slate-900/90 border border-white/[0.1] text-xs sm:text-sm text-white placeholder:text-slate-500 focus:outline-none focus:border-cyan-400 transition"
                />
                {searchQuery && (
                  <button
                    type="button"
                    onClick={() => setSearchQuery('')}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-white"
                  >
                    Clear
                  </button>
                )}
              </div>

              {/* Provider Filter */}
              <div>
                <select
                  value={selectedProvider}
                  onChange={(e) => setSelectedProvider(e.target.value)}
                  className="w-full px-3 py-2.5 rounded-2xl bg-slate-900/90 border border-white/[0.1] text-xs text-white focus:outline-none focus:border-cyan-400"
                >
                  <option value="all">All Providers (VISA, MasterCard, Amex)</option>
                  <option value="VISA">VISA</option>
                  <option value="MasterCard">MasterCard</option>
                  <option value="Amex">American Express (Amex)</option>
                </select>
              </div>

              {/* Country Filter */}
              <div>
                <select
                  value={selectedCountry}
                  onChange={(e) => setSelectedCountry(e.target.value)}
                  className="w-full px-3 py-2.5 rounded-2xl bg-slate-900/90 border border-white/[0.1] text-xs text-white focus:outline-none focus:border-cyan-400"
                >
                  <option value="all">All Countries</option>
                  <option value="US">United States (US)</option>
                  <option value="UK">United Kingdom (UK)</option>
                  <option value="AU">Australia (AU)</option>
                  <option value="CA">Canada (CA)</option>
                  <option value="JP">Japan (JP)</option>
                </select>
              </div>
            </div>

            {/* Sub-Filters: Type, Sorting, Result Count */}
            <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-white/[0.05] text-xs">
              <div className="flex flex-wrap items-center gap-1.5">
                <span className="text-slate-500 mr-1 font-medium">Type:</span>
                {['all', 'Debit', 'Credit', 'Prepaid'].map((t) => (
                  <button
                    key={t}
                    type="button"
                    onClick={() => setSelectedType(t)}
                    className={`px-3 py-1 rounded-xl text-xs font-semibold transition ${
                      selectedType === t
                        ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30'
                        : 'bg-white/[0.03] text-slate-400 hover:text-white'
                    }`}
                  >
                    {t === 'all' ? 'All Types' : t}
                  </button>
                ))}
              </div>

              <div className="flex items-center gap-3">
                <div className="flex items-center gap-1.5">
                  <span className="text-slate-500 font-medium">Sort:</span>
                  <select
                    value={sortBy}
                    onChange={(e) => setSortBy(e.target.value as any)}
                    className="px-2.5 py-1 rounded-xl bg-slate-900 border border-white/[0.1] text-xs text-white focus:outline-none"
                  >
                    <option value="default">Default (ID 1-100)</option>
                    <option value="price-asc">Price: Low to High</option>
                    <option value="price-desc">Price: High to Low</option>
                    <option value="limit-desc">Limit: High to Low</option>
                  </select>
                </div>

                <span className="text-slate-400 font-medium">
                  Showing {filteredMarketCards.length} of {allMarketCardsCount}
                </span>
              </div>
            </div>
          </div>

          {/* Cards Grid using the exact photo-matched style */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-7">
            {filteredMarketCards.map((card, idx) => (
              <PlasticSharkCardVisual
                key={card.id}
                card={card}
                onClick={handleCardClick}
                onBuyNow={handleBuyNow}
                onAddToCart={handleAddToCart}
                isInCart={cartItems.some((item) => item.id === card.id)}
                isPurchased={isCardPurchased(card.cardCode)}
                variantIndex={idx}
              />
            ))}
          </div>

          {filteredMarketCards.length === 0 && (
            <div className="p-12 text-center rounded-3xl bg-[#161726]/60 border border-white/[0.08] space-y-3">
              <CreditCard className="w-12 h-12 text-slate-600 mx-auto stroke-[1.5]" />
              <h3 className="text-base font-bold text-white">No Premium Cards Matched Your Filter</h3>
              <p className="text-xs text-slate-400 max-w-sm mx-auto">
                Try clearing your search query or selecting "All Providers" and "All Countries".
              </p>
              <button
                type="button"
                onClick={() => {
                  setSearchQuery('');
                  setSelectedProvider('all');
                  setSelectedCountry('all');
                  setSelectedType('all');
                }}
                className="mt-2 px-4 py-2 rounded-xl bg-slate-800 text-cyan-400 text-xs font-bold"
              >
                Reset Filters
              </button>
            </div>
          )}
        </div>
      ) : activeTab === 'visa' ? (
        <div className="space-y-6">
          <div className="p-4 rounded-3xl bg-[#161726]/70 border border-white/[0.08] backdrop-blur-xl flex items-center justify-between">
            <div>
              <h3 className="text-base font-bold text-amber-400">Visa Promo Cards ($5 - $10)</h3>
              <p className="text-xs text-slate-400">
                Exclusive Visa promo cards available for a limited time.
              </p>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-7">
            {visaPromoCards.map((card, idx) => (
              <PlasticSharkCardVisual
                key={card.id}
                card={card}
                onClick={handleCardClick}
                onBuyNow={handleBuyNow}
                onAddToCart={handleAddToCart}
                isInCart={cartItems.some((item) => item.id === card.id)}
                isPurchased={isCardPurchased(card.cardCode)}
                variantIndex={idx}
              />
            ))}
          </div>
        </div>
      ) : (
        /* My Purchased Cards Tab */
        <div className="space-y-6">
          <div className="p-4 rounded-3xl bg-slate-900/60 border border-white/[0.08] flex items-center justify-between">
            <div>
              <h3 className="text-base font-bold text-white">My Active Premium Cards</h3>
              <p className="text-xs text-slate-400">
                You have {purchasedCards.length} virtual card cards unlocked with instant spending limits.
              </p>
            </div>

            <button
              type="button"
              onClick={() => setActiveTab('all')}
              className="relative group px-4 py-2 rounded-xl bg-slate-900 border border-white/10 text-xs font-bold transition-all overflow-hidden"
            >
              <div className="absolute inset-0 bg-gradient-to-r from-pink-600/20 via-purple-600/20 to-cyan-600/20 opacity-0 group-hover:opacity-100 transition-opacity"></div>
              <span className="relative text-transparent bg-clip-text bg-gradient-to-r from-pink-400 via-purple-400 to-cyan-400">
                Browse 1000+ Premium Cards
              </span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {purchasedCards.map((card) => (
              <div
                key={card.id}
                className="p-5 rounded-3xl bg-[#161726]/90 border border-white/[0.08] space-y-4 hover:border-cyan-500/30 transition-all shadow-xl"
              >
                <div className="flex justify-center">
                  <VirtualCardVisual
                    card={card}
                    onToggleFreeze={handleToggleFreeze}
                    onViewDetails={() => {
                      // Find matched market card if available
                      const matchedMarket = AVAILABLE_MARKET_CARDS.find((m) => m.cardCode === card.cardCode);
                      if (matchedMarket) {
                        setSelectedMarketCard(matchedMarket);
                        setIsDetailModalOpen(true);
                      }
                    }}
                    isActionLoading={isActionLoading}
                  />
                </div>

                <div className="pt-3 border-t border-white/[0.06] space-y-2 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400">Card Limit</span>
                    <span className="font-mono font-bold text-white">
                      ₹{card.spendingLimit.toLocaleString()} (≈ ${(card.spendingLimit / 94.49).toFixed(2)})
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-slate-400">Status</span>
                    <span
                      className={`font-semibold ${
                        card.status === 'ACTIVE' ? 'text-emerald-400' : 'text-amber-400'
                      }`}
                    >
                      {card.status}
                    </span>
                  </div>
                  {card.country && (
                    <div className="flex items-center justify-between text-[11px] text-slate-400">
                      <span>Country: {card.country}</span>
                      <span>Bank: {card.bank || 'Auto Bank'}</span>
                    </div>
                  )}
                </div>
              </div>
            ))}

            {purchasedCards.length === 0 && !isLoadingPurchased && (
              <div className="col-span-full py-16 text-center rounded-3xl bg-[#161726]/40 border border-white/[0.06] space-y-3">
                <CreditCard className="w-12 h-12 text-slate-600 mx-auto stroke-[1.5]" />
                <h3 className="text-base font-bold text-white">No Cards Purchased Yet</h3>
                <p className="text-xs text-slate-400 max-w-sm mx-auto">
                  Explore the 100 card cards catalog and purchase any card using your account balance.
                </p>
                <button
                  type="button"
                  onClick={() => setActiveTab('all')}
                  className="mt-3 px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 font-bold text-xs"
                >
                  View Premium Cards Catalog
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Interactive Card Detail Modal matching the photo design */}
      <CardDetailModal
        card={selectedMarketCard}
        isOpen={isDetailModalOpen}
        onClose={() => setIsDetailModalOpen(false)}
        currentUser={user}
        onPurchaseSuccess={handlePurchaseSuccess}
        onNavigateToDeposit={(amount) => navigateTo('/deposit')}
        isAlreadyPurchased={selectedMarketCard ? isCardPurchased(selectedMarketCard.cardCode) : false}
        purchasedCardData={selectedMarketCard ? getPurchasedCardData(selectedMarketCard.cardCode) : null}
      />

      {/* Cart Drawer for multiple card checkout */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cartItems={cartItems}
        onRemoveItem={(cardId) => setCartItems((prev) => prev.filter((c) => c.id !== cardId))}
        onClearCart={() => setCartItems([])}
        currentUser={user}
        onPurchaseSuccess={handlePurchaseSuccess}
        onNavigateToDeposit={(amount) => navigateTo('/deposit')}
      />
    </div>
  );
};
