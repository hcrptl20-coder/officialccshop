import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext.tsx';
import { BrandCardLogo } from '../../components/common/BrandCardLogo.tsx';
import { GoogleLogin } from '@react-oauth/google';
import {
  Lock,
  Mail,
  Eye,
  EyeOff,
  ArrowRight,
  Shield,
  Loader2,
  PlusCircle,
} from 'lucide-react';

interface LoginPageProps {
  onNavigate: (path: string) => void;
  onSuccess?: () => void;
}

export const LoginPage: React.FC<LoginPageProps> = ({ onNavigate, onSuccess }) => {
  const { login, googleLogin } = useAuth();
  
  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);
  
  const [loading, setLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const handleManualSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setLoading(true);
    
    const res = await login(identifier, password, rememberMe);
    
    setLoading(false);
    if (res.success) {
      if (onSuccess) onSuccess();
      else onNavigate('/cards');
    } else {
      setErrorMessage(res.error || 'Invalid credentials. Please verify your details.');
    }
  };

  const handleGoogleSuccess = async (credentialResponse: any) => {
    if (credentialResponse.credential) {
      setLoading(true);
      const res = await googleLogin(credentialResponse.credential);
      setLoading(false);
      if (res.success) {
        if (onSuccess) onSuccess();
        else onNavigate('/cards');
      } else {
        setErrorMessage(res.error || 'Google login failed.');
      }
    }
  };

  return (
    <div className="min-h-[calc(100vh-4rem)] flex items-center justify-center p-4 sm:p-6 lg:p-8">
      <div className="w-full max-w-md">
        <div className="text-center mb-6">
          <div className="inline-flex justify-center mb-3">
            <BrandCardLogo size="xl" />
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            Sign In
          </h1>
          <p className="text-sm text-slate-400 mt-1.5">
            Log in to manage your cards and transactions
          </p>
        </div>

        <div className="rounded-2xl bg-slate-900/85 border border-white/[0.08] shadow-2xl backdrop-blur-2xl p-5 sm:p-7">
          {errorMessage && (
            <div className="mb-4 p-3 rounded-xl bg-rose-950/40 border border-rose-500/40 text-rose-300 text-xs font-medium flex items-center gap-2">
              <Lock className="w-4 h-4 text-rose-400 shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* Google Auth Button */}
          <div className="mb-6 flex justify-center">
             <GoogleLogin
                onSuccess={handleGoogleSuccess}
                onError={() => {
                  setErrorMessage('Google Sign-In failed.');
                }}
                theme="filled_black"
                shape="rectangular"
                text="continue_with"
                size="large"
             />
          </div>

          <div className="flex items-center gap-3 mb-6">
            <div className="flex-1 h-px bg-white/[0.08]"></div>
            <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider">or sign in with email</span>
            <div className="flex-1 h-px bg-white/[0.08]"></div>
          </div>

          <form onSubmit={handleManualSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Email or Username
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-500">
                  <Mail className="w-4 h-4" />
                </div>
                <input
                  type="text"
                  required
                  value={identifier}
                  onChange={(e) => setIdentifier(e.target.value)}
                  placeholder="name@example.com"
                  className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-slate-950/60 border border-white/[0.08] text-white placeholder-slate-500 text-sm focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500"
                />
              </div>
            </div>
            
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Password
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-500">
                  <Lock className="w-4 h-4" />
                </div>
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••••••"
                  className="w-full pl-10 pr-10 py-2.5 rounded-xl bg-slate-950/60 border border-white/[0.08] text-white placeholder-slate-500 text-sm focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-slate-400 hover:text-slate-200"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>
            
            <div className="flex items-center justify-between pt-1">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={rememberMe}
                  onChange={(e) => setRememberMe(e.target.checked)}
                  className="w-4 h-4 rounded border-slate-700 bg-slate-950 text-emerald-500 focus:ring-emerald-500/40"
                />
                <span className="text-xs text-slate-400 select-none">Remember Me</span>
              </label>
              <button
                type="button"
                onClick={() => onNavigate('/forgot-password')}
                className="text-xs font-semibold text-emerald-400 hover:text-emerald-300 transition-colors"
              >
                Forgot Password?
              </button>
            </div>
            
            <button
              type="submit"
              disabled={loading}
              className="w-full mt-2 py-3 px-4 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-sm transition-all shadow-lg shadow-emerald-500/25 flex items-center justify-center gap-2 disabled:opacity-50"
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Authenticating...</span>
                </>
              ) : (
                <>
                  <span>Sign In</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
            
            <div className="pt-4 mt-4 border-t border-white/[0.06] text-center">
              <button
                type="button"
                onClick={() => onNavigate('/register')}
                className="w-full py-2.5 px-3 rounded-xl bg-slate-950/40 hover:bg-slate-800/60 border border-white/[0.06] text-slate-300 hover:text-white text-xs font-medium transition-colors flex items-center justify-center gap-2"
              >
                <PlusCircle className="w-3.5 h-3.5" />
                <span>Create New Account</span>
              </button>
            </div>
          </form>
        </div>
        
        <p className="text-center text-[11px] text-slate-500 mt-6 flex items-center justify-center gap-1.5">
          <Shield className="w-3.5 h-3.5 text-slate-500" />
          <span>Secure AES-256 Bit Encryption • OAuth 2.0</span>
        </p>
      </div>
    </div>
  );
};
