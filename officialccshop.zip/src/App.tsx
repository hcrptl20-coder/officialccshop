import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext.tsx';
import { Navbar } from './components/layout/Navbar.tsx';
import { Sidebar } from './components/layout/Sidebar.tsx';
import { AdminSidebar } from './components/layout/AdminSidebar.tsx';

// Pages
import { LoginPage } from './pages/auth/LoginPage.tsx';
import { RegisterPage } from './pages/auth/RegisterPage.tsx';
import { ForgotPasswordPage } from './pages/auth/ForgotPasswordPage.tsx';
import { DashboardPage } from './pages/user/DashboardPage.tsx';
import { MyCardsPage } from './pages/user/MyCardsPage.tsx';
import { DepositPage } from './pages/user/DepositPage.tsx';
import { TransactionsPage } from './pages/user/TransactionsPage.tsx';
import { SupportPage } from './pages/user/SupportPage.tsx';
import { NotificationsPage } from './pages/user/NotificationsPage.tsx';

// Admin Pages
import { AdminSettingsPage } from "./pages/admin/AdminSettingsPage.tsx";
import { AdminDepositsPage } from './pages/admin/AdminDepositsPage.tsx';
import { BrandCardLogo } from './components/common/BrandCardLogo.tsx';
import { AdminAuthGate } from './components/admin/AdminAuthGate.tsx';

import { Sparkles, Shield, UserCheck, ArrowRight } from 'lucide-react';

const AppContent: React.FC = () => {
  const { user, isLoading, cardLogin, oneClickLogin, refreshUser } = useAuth();
  const [currentPath, setCurrentPath] = useState<string>(() => {
    const p = window.location.pathname;
    return p === '/' || p === '/login' || p === '/dashboard'
      ? '/cards'
      : p;
  });
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);

  // Sync route with browser history
  useEffect(() => {
    const handlePopState = () => {
      const p = window.location.pathname || '/cards';
      setCurrentPath(p === '/' || p === '/login' || p === '/dashboard' ? '/cards' : p);
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  

  const navigate = (path: string) => {
    window.history.pushState({}, '', path);
    setCurrentPath(path);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Loading state (quick subtle render)
  if (isLoading && !user) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center text-white">
        <BrandCardLogo size="xl" animate className="mb-4" />
        <p className="text-xs font-mono uppercase tracking-widest text-slate-400">
          Loading Cards Shop...
        </p>
      </div>
    );
  }

  const isAdminView = currentPath.startsWith('/admin');

  const renderCurrentPage = () => {
    if (!user) {
      // Unauthenticated Views
      if (currentPath === '/register') return <RegisterPage onNavigate={navigate} />;
      if (currentPath === '/forgot-password' || currentPath.startsWith('/forgot-password')) {
        const urlParams = new URLSearchParams(window.location.search);
        return <ForgotPasswordPage onNavigate={navigate} token={urlParams.get('token') || ''} />;
      }
      if (currentPath === '/cards' || currentPath === '/') {
        return <MyCardsPage onNavigate={navigate} />;
      }
      // Require auth for everything else
      return <LoginPage onNavigate={navigate} />;
    }

    // Authenticated Admin View
    if (isAdminView) {
      const isAuthorizedAdmin = typeof window !== 'undefined' && sessionStorage.getItem('zenith_admin_session_v2') === 'true';
      if (!isAuthorizedAdmin) {
        return <AdminAuthGate onAccessGranted={() => navigate('/admin')} onCancel={() => navigate('/cards')} onRefreshUser={refreshUser} />;
      }
      if (currentPath === '/admin/settings') return <AdminSettingsPage />;
      if (currentPath === '/admin/vouchers') return <AdminDepositsPage filterMode="vouchers" />;
      return <AdminDepositsPage filterMode="transactions" />;
    }

    // Authenticated User Views
    switch (currentPath) {
      case '/dashboard': return <DashboardPage onNavigate={navigate} />;
      case '/deposit': return <DepositPage onNavigate={navigate} />;
      case '/transactions': return <TransactionsPage />;
      case '/support': return <SupportPage />;
      case '/notifications': return <NotificationsPage />;
      case '/cards': default: return <MyCardsPage onNavigate={navigate} />;
    }
  };

  // If unauthenticated and on a full-page auth route, don't wrap in layout
  // Allow public views (like /cards) to render inside the main layout
  if (!user && (currentPath === '/register' || currentPath === '/login' || currentPath.startsWith('/forgot-password'))) {
    return renderCurrentPage();
  }

  return (
    <div className="min-h-screen bg-[#07090e] text-slate-100 flex flex-col selection:bg-emerald-500/30 selection:text-emerald-300">
      <Navbar currentPath={currentPath} onNavigate={navigate} onToggleSidebar={() => setIsMobileSidebarOpen(true)} />
      <div className="flex-1 flex max-w-7xl w-full mx-auto">
        {isAdminView ? (
          <AdminSidebar currentPath={currentPath} onNavigate={navigate} isOpen={isMobileSidebarOpen} onClose={() => setIsMobileSidebarOpen(false)} />
        ) : (
          <Sidebar currentPath={currentPath} onNavigate={navigate} isOpen={isMobileSidebarOpen} onClose={() => setIsMobileSidebarOpen(false)} />
        )}
        <main className="flex-1 p-4 sm:p-6 lg:p-8 min-w-0 overflow-x-hidden">
          {renderCurrentPage()}
        </main>
      </div>


    </div>
  );
};

import { GoogleOAuthProvider } from '@react-oauth/google';

export default function App() {
  const [clientId, setClientId] = useState<string>('');
  const [isReady, setIsReady] = useState(false);

  useEffect(() => {
    fetch('/api/auth/client-id')
      .then(res => res.json())
      .then(data => {
        if (data.clientId) setClientId(data.clientId);
      })
      .catch(console.error)
      .finally(() => setIsReady(true));
  }, []);

  if (!isReady && !clientId) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center text-white">
        <p className="text-xs font-mono uppercase tracking-widest text-slate-400">
          Initializing Auth...
        </p>
      </div>
    );
  }

  if (!clientId) {
    return (
      <AuthProvider>
        <AppContent />
      </AuthProvider>
    );
  }

  return (
    <GoogleOAuthProvider clientId={clientId}>
      <AuthProvider>
        <AppContent />
      </AuthProvider>
    </GoogleOAuthProvider>
  );
}