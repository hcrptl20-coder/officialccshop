export type UserRole = 'user' | 'admin';
export type AccountStatus = 'active' | 'suspended';

export interface User {
  id: string;
  name: string;
  username: string;
  email: string;
  role: UserRole;
  status: AccountStatus;
  balance: number;
  avatarUrl?: string;
  createdAt: string;
  updatedAt: string;
  preferences?: {
    emailNotifications: boolean;
    depositAlerts: boolean;
    securityAlerts: boolean;
  };
}

export interface CardCard {
  cardId?: string;
  id: string;
  userId: string;
  cardholderName: string;
  maskedNumber: string;
  expiryMonth: string;
  expiryYear: string;
  cardType: string;
  status: 'ACTIVE' | 'FROZEN';
  spendingLimit: number;
  spentAmount: number;
  colorTheme: 'emerald' | 'cyan' | 'purple' | 'amber';
  isCard: boolean;
  createdAt: string;
  cardCode?: string;
  provider?: string;
  country?: string;
  state?: string;
  address?: string;
  zip?: string;
  extras?: string;
  bank?: string;
  priceUsd?: number;
  priceInr?: number;
  last4?: string;
  cvv?: string;
}

export type DepositStatus = 'Pending' | 'Approved' | 'Rejected';

export interface Deposit {
  cardId?: string;
  id: string;
  userId: string;
  username?: string;
  userName?: string;
  userEmail?: string;
  amount: number;
  paymentMethod: string;
  upiId: string;
  referenceNo: string;
  proofUrl?: string;
  status: DepositStatus;
  adminNotes?: string;
  createdAt: string;
  reviewedAt?: string;
  reviewedBy?: string;
  cardCode?: string;
  cardName?: string;
  cardProvider?: string;
  cardPriceUsd?: number;
  cardBin?: string;
  purpose?: string;
}

export type TransactionType = 'Deposit' | 'Virtual Card Payment' | 'Refund' | 'Fee' | 'Transfer';
export type TransactionStatus = 'Pending' | 'Approved' | 'Rejected' | 'Completed';

export interface Transaction {
  id: string;
  userId: string;
  username?: string;
  type: TransactionType;
  amount: number;
  status: TransactionStatus;
  paymentMethod: string;
  reference: string;
  description: string;
  date: string;
}

export type TicketStatus = 'Open' | 'Pending' | 'In Progress' | 'Resolved';

export interface TicketReply {
  id: string;
  ticketId: string;
  userId: string;
  senderName: string;
  isAdmin: boolean;
  senderRole?: 'user' | 'admin';
  message: string;
  createdAt: string;
}

export interface SupportTicket {
  id: string;
  ticketId: string;
  userId: string;
  userName?: string;
  userEmail?: string;
  subject: string;
  message: string;
  category?: string;
  priority?: 'Low' | 'Medium' | 'High';
  status: TicketStatus;
  createdAt: string;
  updatedAt: string;
  replies: TicketReply[];
}

export type NotificationType =
  | 'deposit'
  | 'card'
  | 'support'
  | 'security'
  | 'system'
  | 'deposit_approved'
  | 'deposit_rejected'
  | 'card_frozen'
  | 'password_changed'
  | 'security_alert';

export interface NotificationItem {
  id: string;
  userId: string;
  title: string;
  message: string;
  type: NotificationType;
  isRead: boolean;
  read?: boolean;
  link?: string;
  createdAt: string;
}

export interface PaymentConfig {
  useStaticQr?: boolean;
  staticQrUrl?: string;
  qrImagePath: string;
  upiId: string;
  displayUpiId?: string;
  paymentInstructions: string;
  merchantName: string;
  updatedAt: string;
}

export interface AdminStats {
  totalUsers: number;
  pendingDeposits: number;
  pendingDepositsCount?: number;
  approvedDeposits: number;
  rejectedDeposits: number;
  totalTransactions: number;
  totalVolume: number;
  totalApprovedVolume?: number;
  totalCards?: number;
}

