import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import { User } from '../types/index.ts';
import { apiRequest } from '../lib/api.ts';

interface AuthContextType {
  user: User | null;
  isLoading: boolean;
  unreadCount: number;
  googleLogin: (credential: string) => Promise<{ success: boolean; error?: string; user?: User }>;
  login: (identifier: string, password: string, rememberMe?: boolean) => Promise<{ success: boolean; error?: string }>;
  register: (payload: {
    name: string;
    username: string;
    email: string;
    password: string;
    confirmPassword: string;
    agreeTerms: boolean;
  }) => Promise<{ success: boolean; error?: string }>;
  cardLogin: (role: 'user' | 'admin') => Promise<{ success: boolean; error?: string }>;
  oneClickLogin: (params: { email?: string; userId?: string }) => Promise<{ success: boolean; error?: string }>;
  adminLogin: (email: string, password: string) => Promise<{ success: boolean; error?: string; user?: User }>;
  logout: () => Promise<void>;
  logoutAll: () => Promise<void>;
  refreshUser: () => Promise<void>;
  decrementUnread: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [unreadCount, setUnreadCount] = useState(0);

  const refreshUser = useCallback(async () => {
    try {
      const res = await apiRequest<{ user: User | null; unreadNotifications: number }>('/api/auth/me');
      if (res.ok && res.data?.user) {
        setUser(res.data.user);
        setUnreadCount(res.data.unreadNotifications || 0);
      } else {
        // Guest Auto-Login
        const auto = await apiRequest<{ user: any; token: string }>('/api/auth/guest-login', {
          method: 'POST',
        });
        if (auto.ok && auto.data?.user) {
          if (typeof window !== 'undefined' && auto.data.token) {
            localStorage.setItem('zenith_auth_token', auto.data.token);
          }
          setUser(auto.data.user);
        } else {
          setUser(null);
        }
      }
    } catch (error) {
      console.error('Auth refresh failed:', error);
      setUser(null);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    refreshUser();
  }, [refreshUser]);

  const googleLogin = async (credential: string) => {
    setIsLoading(true);
    const res = await apiRequest<{ user: User; message: string; token: string }>('/api/auth/google', {
      method: 'POST',
      body: JSON.stringify({ credential }),
    });
    setIsLoading(false);
    if (res.ok && res.data?.user) {
      if (typeof window !== 'undefined' && res.data.token) {
        localStorage.setItem('zenith_auth_token', res.data.token);
      }
      setUser(res.data.user);
      return { success: true, user: res.data.user };
    }
    return { success: false, error: res.error || 'Google login failed' };
  };

  const login = async (identifier: string, password: string, rememberMe: boolean = false) => {
    const res = await apiRequest<{ user: User; message: string; token?: string }>('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ identifier, password, rememberMe }),
    });

    if (res.ok && res.data?.user) {
      if (typeof window !== 'undefined' && res.data.token) {
        localStorage.setItem('zenith_auth_token', res.data.token);
      }
      setUser(res.data.user);
      await refreshUser();
      return { success: true };
    }
    return { success: false, error: res.error || 'Login failed' };
  };

  const register = async (payload: {
    name: string;
    username: string;
    email: string;
    password: string;
    confirmPassword: string;
    agreeTerms: boolean;
  }) => {
    const res = await apiRequest<{ user: User; message: string; token?: string }>('/api/auth/register', {
      method: 'POST',
      body: JSON.stringify(payload),
    });

    if (res.ok && res.data?.user) {
      if (typeof window !== 'undefined' && res.data.token) {
        localStorage.setItem('zenith_auth_token', res.data.token);
      }
      setUser(res.data.user);
      await refreshUser();
      return { success: true };
    }
    return { success: false, error: res.error || 'Registration failed' };
  };

  const cardLogin = async (role: 'user' | 'admin') => {
    const res = await apiRequest<{ user: User; message: string }>('/api/auth/demo-login', {
      method: 'POST',
      body: JSON.stringify({ role }),
    });

    if (res.ok && res.data?.user) {
      setUser(res.data.user);
      await refreshUser();
      return { success: true };
    }
    return { success: false, error: res.error || 'Card login failed' };
  };

  const oneClickLogin = async (params: { email?: string; userId?: string }) => {
    const res = await apiRequest<{ user: User; message: string }>('/api/auth/one-click-login', {
      method: 'POST',
      body: JSON.stringify(params),
    });

    if (res.ok && res.data?.user) {
      setUser(res.data.user);
      await refreshUser();
      return { success: true };
    }
    return { success: false, error: res.error || 'One-click sign in failed' };
  };

  const adminLogin = async (email: string, password: string) => {
    const res = await apiRequest<{ user: User; message: string; token: string }>('/api/auth/admin-login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    });

    if (res.ok && res.data?.user) {
      if (typeof window !== 'undefined') {
        if (res.data.token) {
          localStorage.setItem('zenith_auth_token', res.data.token);
        }
        sessionStorage.setItem('zenith_admin_session_v2', 'true');
      }
      setUser(res.data.user);
      return { success: true, user: res.data.user };
    }
    return { success: false, error: res.error || 'Admin verification failed' };
  };

  const logout = async () => {
    try {
      await apiRequest('/api/auth/logout', { method: 'POST' });
    } catch {
      // ignore
    }
    if (typeof window !== 'undefined') {
      localStorage.removeItem('zenith_auth_token');
      sessionStorage.removeItem('zenith_admin_session_v2');
    }
    setUser(null);
    setUnreadCount(0);
  };

  const logoutAll = async () => {
    try {
      await apiRequest('/api/auth/logout-all', { method: 'POST' });
    } catch {
      // ignore
    }
    if (typeof window !== 'undefined') {
      localStorage.removeItem('zenith_auth_token');
      sessionStorage.removeItem('zenith_admin_session_v2');
    }
    setUser(null);
    setUnreadCount(0);
  };

  const decrementUnread = () => {
    setUnreadCount((prev) => Math.max(0, prev - 1));
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        isLoading,
        unreadCount,
        googleLogin,
        login,
        register,
        cardLogin,
        oneClickLogin,
        adminLogin,
        logout,
        logoutAll,
        refreshUser,
        decrementUnread,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
