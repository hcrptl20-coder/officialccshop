import React, { useState } from 'react';
import { Shield, Lock, Mail, KeyRound, AlertCircle, ArrowRight, Eye, EyeOff, Store } from 'lucide-react';
import { useAuth } from '../../context/AuthContext.tsx';

interface AdminAuthGateProps {
  onAccessGranted: () => void;
  onCancel: () => void;
  onRefreshUser?: () => Promise<void>;
}

export const AdminAuthGate: React.FC<AdminAuthGateProps> = ({
  onAccessGranted,
  onCancel,
  onRefreshUser,
}) => {
  const { adminLogin } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    const cleanEmail = email.trim().toLowerCase();
    const cleanPass = password.trim();

    const isAuthorized =
      (cleanEmail === 'emailhcrptl2.0@gmail.com' ||
        cleanEmail === 'hcrptl2.0@gmail.com' ||
        cleanEmail === 'hcrptl@gmail.com' ||
        cleanEmail.includes('hcrptl2.0')) &&
      cleanPass === '0800';

    if (!isAuthorized) {
      setErrorMessage(
        'Access Denied: Invalid credentials.'
      );
      return;
    }

    setIsLoading(true);

    try {
      const res = await adminLogin(cleanEmail, cleanPass);

      if (res.success) {
        if (onRefreshUser) {
          try {
            await onRefreshUser();
          } catch {
            // non-blocking
          }
        }
        onAccessGranted();
      } else {
        setErrorMessage(res.error || 'Admin verification failed. Please try again.');
      }
    } catch {
      setErrorMessage('Network error during admin verification. Please retry.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div
      id="admin-auth-gate-container"
      className="min-h-[80vh] flex items-center justify-center px-4 py-12"
    >
      <div
        id="admin-auth-gate-card"
        className="w-full max-w-md p-6 sm:p-8 rounded-3xl bg-slate-900/90 border border-purple-500/30 backdrop-blur-2xl shadow-2xl relative overflow-hidden"
      >
        {/* Top Glow Accent */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-48 h-1 bg-gradient-to-r from-transparent via-purple-500 to-transparent" />
        <div className="absolute -top-20 -left-20 w-40 h-40 bg-purple-600/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-20 -right-20 w-40 h-40 bg-emerald-600/10 rounded-full blur-3xl pointer-events-none" />

        {/* Header Icon */}
        <div className="text-center space-y-3">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-purple-900/80 to-slate-900 border border-purple-500/40 text-purple-300 flex items-center justify-center mx-auto shadow-lg shadow-purple-950/50 relative group">
            <Shield className="w-8 h-8 text-purple-400" />
            <div className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-amber-500/20 border border-amber-500/50 flex items-center justify-center text-amber-400">
              <Lock className="w-2.5 h-2.5" />
            </div>
          </div>

          <div>
            <span className="px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider bg-purple-500/10 text-purple-300 border border-purple-500/20">
              Restricted Area
            </span>
            <h1 className="text-xl sm:text-2xl font-black text-white mt-2 tracking-tight">
              Admin Portal
            </h1>
            <p className="text-xs text-slate-400 mt-1 max-w-xs mx-auto leading-relaxed">
              Enter your credentials to continue.
            </p>
          </div>
        </div>

        {/* Error Notification */}
        {errorMessage && (
          <div
            id="admin-auth-error-alert"
            className="mt-5 p-3.5 rounded-2xl bg-rose-950/40 border border-rose-500/30 text-rose-300 text-xs flex items-start gap-2.5 animate-fadeIn"
          >
            <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
            <span className="leading-relaxed">{errorMessage}</span>
          </div>
        )}

        {/* Login Form */}
        <form onSubmit={handleSubmit} className="mt-6 space-y-4">
          {/* Email Field */}
          <div>
            <label htmlFor="admin-email-input" className="block text-xs font-semibold text-slate-300 mb-1.5">
              Email
            </label>
            <div className="relative">
              <Mail className="w-4 h-4 text-slate-500 absolute inset-y-0 left-3.5 my-auto pointer-events-none" />
              <input
                id="admin-email-input"
                name="admin_email"
                type="email"
                autoComplete="off"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Email"
                className="w-full pl-10 pr-4 py-3 rounded-2xl bg-slate-950/80 border border-white/[0.08] text-white text-sm font-mono placeholder-slate-500 focus:outline-none focus:border-purple-500/60 focus:ring-1 focus:ring-purple-500/40 transition-all"
              />
            </div>
          </div>

          {/* Password Field */}
          <div>
            <label htmlFor="admin-password-input" className="block text-xs font-semibold text-slate-300 mb-1.5">
              Password
            </label>
            <div className="relative">
              <KeyRound className="w-4 h-4 text-slate-500 absolute inset-y-0 left-3.5 my-auto pointer-events-none" />
              <input
                id="admin-password-input"
                name="admin_password"
                type={showPassword ? 'text' : 'password'}
                autoComplete="new-password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Password"
                className="w-full pl-10 pr-11 py-3 rounded-2xl bg-slate-950/80 border border-white/[0.08] text-white text-sm font-mono placeholder-slate-500 focus:outline-none focus:border-purple-500/60 focus:ring-1 focus:ring-purple-500/40 transition-all"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute inset-y-0 right-3 flex items-center text-slate-500 hover:text-slate-300 transition-colors"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {/* Submit Button */}
          <button
            id="admin-auth-submit-btn"
            type="submit"
            disabled={isLoading}
            className="w-full py-3.5 px-4 rounded-2xl bg-gradient-to-r from-purple-600 via-indigo-600 to-purple-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold text-sm shadow-lg shadow-purple-600/30 transition-all flex items-center justify-center gap-2 active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isLoading ? (
              <>
                <span className="w-4 h-4 border-2 border-white/20 border-t-white rounded-full animate-spin" />
                <span>Verifying Admin Credentials...</span>
              </>
            ) : (
              <>
                <span>Unlock Admin Portal</span>
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>
        </form>

        {/* Cancel / Return to user shop */}
        <div className="mt-5 pt-4 border-t border-white/[0.06] text-center">
          <button
            type="button"
            onClick={onCancel}
            className="text-xs text-slate-400 hover:text-slate-200 flex items-center justify-center gap-1.5 mx-auto transition-colors"
          >
            <Store className="w-3.5 h-3.5 text-slate-400" />
            <span>Return to User Shop / Dashboard</span>
          </button>
        </div>
      </div>
    </div>
  );
};
