import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext.tsx';
import { BrandCardLogo } from '../common/BrandCardLogo.tsx';
import {
  Sparkles,
  Bell,
  User as UserIcon,
  LogOut,
  Shield,
  Menu,
  X,
  CreditCard,
  ArrowDownCircle,
  Clock,
  HelpCircle,
  LayoutDashboard,
  CheckCircle2,
  AlertTriangle,
} from 'lucide-react';

interface NavbarProps {
  currentPath: string;
  onNavigate: (path: string) => void;
  onToggleSidebar?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ currentPath, onNavigate, onToggleSidebar }) => {
  const { user, logout, unreadCount, cardLogin, oneClickLogin } = useAuth();
  const [showNotificationsMenu, setShowNotificationsMenu] = useState(false);

  const navItems: Array<{ label: string; path: string; icon: any; isExternal?: boolean }> = [
    { label: 'Cards', path: '/cards', icon: CreditCard },
    { label: 'Dashboard', path: '/dashboard', icon: LayoutDashboard },
    { label: 'Deposit', path: '/deposit', icon: ArrowDownCircle },
    { label: 'Transactions', path: '/transactions', icon: Clock },
    { label: 'Support Center', path: '/support', icon: HelpCircle },
  ];

  return (
    <header className="sticky top-0 z-40 w-full border-b border-white/[0.07] bg-slate-950/80 backdrop-blur-xl">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
        {/* Left: Brand Logo & Mobile Toggle */}
        <div className="flex items-center gap-3">
          <button
            onClick={onToggleSidebar}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800/60 lg:hidden"
            aria-label="Toggle Navigation"
          >
            <Menu className="w-5 h-5" />
          </button>

          <div
            onClick={() => onNavigate(user?.role === 'admin' && currentPath.startsWith('/admin') ? '/admin' : '/cards')}
            className="flex items-center gap-2.5 cursor-pointer group"
          >
            <BrandCardLogo size="md" />
            <div>
              <div className="flex items-center gap-2 relative group cursor-pointer">
                <div className="absolute -inset-2 bg-gradient-to-r from-cyan-600 via-fuchsia-600 to-pink-600 rounded-lg blur-md opacity-40 group-hover:opacity-100 transition duration-1000 animate-pulse hidden sm:block"></div>
                <span className="relative text-xl font-black tracking-widest uppercase drop-shadow-md flex items-center">
                  <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-300 to-cyan-500">OFFICIAL</span>
                  <span className="text-transparent bg-clip-text bg-gradient-to-r from-fuchsia-300 via-pink-400 to-pink-600 drop-shadow-[0_0_12px_rgba(236,72,153,0.9)] mx-0.5">CC</span>
                  <span className="text-transparent bg-clip-text bg-gradient-to-r from-pink-400 to-rose-400">SHOP</span>
                </span>
                <span className="relative px-2 py-0.5 rounded text-[9px] font-black tracking-widest uppercase bg-slate-950 text-fuchsia-400 border border-fuchsia-500/30 shadow-[inset_0_0_8px_rgba(236,72,153,0.3)] hidden sm:flex items-center gap-1">
                  <Sparkles className="w-2.5 h-2.5 text-pink-400" />
                  PREMIUM
                </span>
              </div>
              <p className="text-[9px] font-semibold tracking-[0.2em] text-slate-400 hidden sm:block uppercase mt-0.5">
                Virtual Cards & Settlement
              </p>
            </div>
          </div>
        </div>

        {/* Center: Desktop Top Navigation Links */}
        <nav className="hidden md:flex items-center gap-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = !item.isExternal && currentPath === item.path;
            return (
              <button
                key={item.path}
                onClick={() => {
                  if (item.isExternal) {
                    window.open(item.path, '_blank', 'noopener,noreferrer');
                  } else {
                    onNavigate(item.path);
                  }
                }}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                  isActive
                    ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 shadow-sm'
                    : 'text-slate-300 hover:text-white hover:bg-slate-800/50'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{item.label}</span>
              </button>
            );
          })}

          {user?.role === 'admin' && (
            <button
              onClick={() => onNavigate('/admin')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                currentPath.startsWith('/admin')
                  ? 'bg-purple-500/10 text-purple-400 border border-purple-500/20 shadow-sm'
                  : 'text-purple-300 hover:text-purple-200 hover:bg-purple-900/30'
              }`}
            >
              <Shield className="w-3.5 h-3.5 text-purple-400" />
              <span>Admin Panel</span>
            </button>
          )}
        </nav>

        {/* Right: Balance Snapshot, Notifications, Role Switcher & User Menu */}
        <div className="flex items-center gap-3">
          {!user ? (
            <button
              onClick={() => onNavigate('/login')}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 text-xs font-bold transition-all active:scale-95 shadow-md shadow-cyan-500/20"
            >
              Sign In
            </button>
          ) : (
            <>

          

          {/* Header Balance Badge with Dual Currency */}
          <div
            onClick={() => onNavigate('/dashboard')}
            className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-900/90 border border-white/[0.08] cursor-pointer hover:border-emerald-500/40 transition-colors"
            title="Available Balance (INR and USD at 94.49/USD)"
          >
            <span className="text-[10px] uppercase font-bold text-slate-400">Balance:</span>
            <span className="font-mono font-bold text-xs text-white">
              ₹{user?.balance?.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) || '0.00'}
            </span>
            <span className="text-[10px] font-mono font-semibold text-emerald-400 bg-emerald-500/10 px-1.5 py-0.5 rounded border border-emerald-500/20">
              ≈ ${((user?.balance || 0) / 94.49).toFixed(2)} USD
            </span>
          </div>

          {/* Notifications Button */}
          <div className="relative">
            <button
              onClick={() => onNavigate('/notifications')}
              className="relative p-2 rounded-xl bg-slate-900/80 hover:bg-slate-800 text-slate-300 hover:text-white border border-white/[0.08] transition-colors"
              title="Notifications"
            >
              <Bell className="w-4 h-4" />
              {unreadCount > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-emerald-500 text-[10px] font-extrabold text-slate-950 flex items-center justify-center animate-pulse">
                  {unreadCount > 9 ? '9+' : unreadCount}
                </span>
              )}
            </button>
          </div>

          {/* Admin shortcut if admin */}
          {user?.role === 'admin' && (
            <button
              onClick={() => onNavigate('/admin')}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-purple-900/30 hover:bg-purple-900/50 text-purple-300 border border-purple-500/30 text-xs font-semibold transition-colors"
              title="Admin Panel"
            >
              <Shield className="w-3.5 h-3.5 text-purple-400" />
              <span className="hidden sm:inline">Admin</span>
            </button>
          )}

          {/* Direct Sign Out Action - Profile & user info menu completely removed */}
          <button
            onClick={() => logout()}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-900/80 hover:bg-rose-500/10 text-slate-300 hover:text-rose-400 border border-white/[0.08] hover:border-rose-500/30 text-xs font-semibold transition-all active:scale-95"
            title="Sign Out"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Sign Out</span>
          </button>
        </>
        )}</div>
      </div>
    </header>
  );
};
