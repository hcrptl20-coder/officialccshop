import React from 'react';
import { useAuth } from '../../context/AuthContext.tsx';
import {
  LayoutDashboard,
  CreditCard,
  ArrowDownCircle,
  Clock,
  HelpCircle,
  Bell,
  Shield,
  Plus,
  ArrowUpRight,
  LogOut,
  Send,
} from 'lucide-react';

interface SidebarProps {
  currentPath: string;
  onNavigate: (path: string) => void;
  isOpen?: boolean;
  onClose?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentPath,
  onNavigate,
  isOpen = false,
  onClose,
}) => {
  const { user, logout } = useAuth();

  const links: Array<{ label: string; path: string; icon: any; isExternal?: boolean }> = [
    { label: 'Cards', path: '/cards', icon: CreditCard },
    { label: 'Dashboard', path: '/dashboard', icon: LayoutDashboard },
    { label: 'Deposit', path: '/deposit', icon: ArrowDownCircle },
    { label: 'Transactions', path: '/transactions', icon: Clock },
    { label: 'Support Center', path: '/support', icon: Send },
    { label: 'Notifications', path: '/notifications', icon: Bell },
  ];

  const handleNav = (target: string | { path: string; isExternal?: boolean }) => {
    const item = typeof target === 'string' ? { path: target } : target;
    if (item.isExternal) {
      window.open(item.path, '_blank', 'noopener,noreferrer');
    } else {
      onNavigate(item.path);
    }
    if (onClose) onClose();
  };

  const content = (
    <aside className="w-64 h-full flex flex-col justify-between p-4 bg-slate-950 border-r border-white/[0.07]">
      <div className="space-y-6">
        {/* Balance Card in Sidebar */}
        <div className="p-4 rounded-2xl bg-gradient-to-br from-slate-900 via-slate-900 to-emerald-950/40 border border-emerald-500/20 shadow-lg">
          <span className="text-[11px] uppercase tracking-wider text-slate-400 font-semibold block">
            Available Balance
          </span>
          <div className="mt-1 flex flex-col">
            <span className="text-2xl font-extrabold text-white font-mono-numbers">
              ₹{user?.balance?.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) || '0.00'}
            </span>
            <span className="text-xs font-mono font-semibold text-emerald-400 mt-0.5">
              ≈ ${((user?.balance || 0) / 94.49).toFixed(2)} USD
              <span className="text-[10px] text-slate-500 font-sans ml-1">(₹94.49/$1)</span>
            </span>
          </div>
          <p className="text-[10px] text-emerald-400 font-medium mt-1 flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
            Verified Sandbox Balance
          </p>

          <button
            onClick={() => handleNav('/deposit')}
            className="mt-3 w-full py-2 px-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-bold transition-all shadow-md shadow-emerald-500/20 flex items-center justify-center gap-1.5 active:scale-98"
          >
            <ArrowDownCircle className="w-3.5 h-3.5" />
            <span>Deposit via QR</span>
          </button>
        </div>

        {/* Navigation List */}
        <div className="space-y-1">
          <span className="px-3 text-[10px] font-bold uppercase tracking-wider text-slate-300 block mb-2">
            Main Menu
          </span>
          {links.map((item) => {
            const Icon = item.icon;
            const isActive = !item.isExternal && currentPath === item.path;
            return (
              <button
                key={item.path}
                onClick={() => handleNav(item)}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-semibold transition-all ${
                  isActive
                    ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 shadow-sm'
                    : 'text-slate-400 hover:text-white hover:bg-slate-900/60'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Icon className={`w-4 h-4 ${isActive ? 'text-emerald-400' : 'text-slate-400'}`} />
                  <span>{item.label}</span>
                </div>
                {item.isExternal && (
                  <ArrowUpRight className="w-3.5 h-3.5 text-slate-500" />
                )}
              </button>
            );
          })}
        </div>

        {/* Admin Portal entry */}
        <div className="pt-2 border-t border-white/[0.06] space-y-1">
          <span className="px-3 text-[10px] font-bold uppercase tracking-wider text-purple-400 block mb-2 flex items-center justify-between">
            <span>Management</span>
            {user?.role === 'admin' ? (
              <span className="text-[9px] px-1.5 py-0.5 rounded bg-purple-500/20 text-purple-300 font-mono">ACTIVE</span>
            ) : (
              <span className="text-[9px] px-1.5 py-0.5 rounded bg-slate-800 text-slate-400 font-mono">RESTRICTED</span>
            )}
          </span>
          <button
            onClick={() => handleNav({ path: '/admin' })}
            className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-semibold transition-all ${
              currentPath.startsWith('/admin')
                ? 'bg-purple-500/10 text-purple-400 border border-purple-500/20 shadow-sm'
                : 'text-purple-300 hover:text-purple-200 hover:bg-purple-950/30'
            }`}
          >
            <div className="flex items-center gap-3">
              <Shield className="w-4 h-4 text-purple-400" />
              <span>Admin Portal</span>
            </div>
            <span className="text-[10px] text-purple-400/60 font-mono">Restricted</span>
          </button>
        </div>
      </div>

      {/* Footer: Direct Sign Out (User info completely removed) */}
      <div className="pt-4 border-t border-white/[0.06]">
        <button
          onClick={() => logout()}
          className="w-full py-2.5 px-3 rounded-xl bg-slate-900 hover:bg-rose-950/30 text-slate-400 hover:text-rose-400 text-xs font-semibold border border-white/[0.05] hover:border-rose-500/20 transition-all flex items-center justify-center gap-2 active:scale-95"
        >
          <LogOut className="w-3.5 h-3.5" />
          <span>Sign Out</span>
        </button>
      </div>
    </aside>
  );

  return (
    <>
      {/* Desktop Persistent Sidebar */}
      <div className="hidden lg:block shrink-0">{content}</div>

      {/* Mobile Drawer */}
      {isOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="fixed inset-0 bg-black/70 backdrop-blur-sm" onClick={onClose} />
          <div className="fixed inset-y-0 left-0 max-w-xs w-full shadow-2xl z-10 animate-in slide-in-from-left duration-200">
            {content}
          </div>
        </div>
      )}
    </>
  );
};
