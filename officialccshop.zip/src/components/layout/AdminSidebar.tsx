import React from 'react';
import { useAuth } from '../../context/AuthContext.tsx';
import {
  LayoutDashboard,
  Users,
  CreditCard,
  ArrowDownCircle,
  Clock,
  HelpCircle,
  Settings,
  Bell,
  ArrowLeft,
  ShieldAlert,
  LogOut,
} from 'lucide-react';

interface AdminSidebarProps {
  currentPath: string;
  onNavigate: (path: string) => void;
  isOpen?: boolean;
  onClose?: () => void;
}

export const AdminSidebar: React.FC<AdminSidebarProps> = ({
  currentPath,
  onNavigate,
  isOpen = false,
  onClose,
}) => {
  const { logout } = useAuth();

  const links = [
    { label: 'UPI & Transactions', path: '/admin/deposits', icon: ArrowDownCircle },
    { label: 'Gift Vouchers', path: '/admin/vouchers', icon: CreditCard },
    { label: 'Settings', path: '/admin/settings', icon: Settings },
  ];

  const handleNav = (path: string) => {
    onNavigate(path);
    if (onClose) onClose();
  };

  const handleAdminSignOut = () => {
    sessionStorage.removeItem('zenith_admin_session_v2');
    window.location.href = '/admin'; // Force reload to trigger AuthGate
  };

  const content = (
    <aside className="w-64 h-full flex flex-col justify-between p-4 bg-slate-950 border-r border-purple-500/20 shadow-xl">
      <div className="space-y-6">
        {/* Admin Header Badge */}
        <div className="p-3.5 rounded-2xl bg-purple-950/30 border border-purple-500/30">
          <div className="flex items-center gap-2 text-purple-400">
            <ShieldAlert className="w-4 h-4" />
            <span className="text-xs font-bold uppercase tracking-wider">Operator Workspace</span>
          </div>
          <p className="text-[11px] text-purple-300/70 mt-1">
            Settlement audits, user compliance & card controls
          </p>
        </div>

        {/* Navigation List */}
        <div className="space-y-1">
          <span className="px-3 text-[10px] font-bold uppercase tracking-wider text-slate-300 block mb-2">
            Operations
          </span>
          {links.map((item) => {
            const Icon = item.icon;
            const isActive = currentPath === item.path;
            return (
              <button
                key={item.path}
                onClick={() => handleNav(item.path)}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-semibold transition-all ${
                  isActive
                    ? 'bg-purple-500/15 text-purple-300 border border-purple-500/30 shadow-sm'
                    : 'text-slate-400 hover:text-white hover:bg-slate-900/60'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-purple-400' : 'text-slate-400'}`} />
                <span>{item.label}</span>
              </button>
            );
          })}
        </div>

        {/* Return to user portal */}
        <div className="pt-2 border-t border-white/[0.06]">
          <button
            onClick={() => handleNav('/dashboard')}
            className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-semibold text-emerald-400 hover:bg-emerald-950/30 border border-emerald-500/20 transition-all"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Switch to User View</span>
          </button>
        </div>
      </div>

      {/* Footer */}
      <div className="pt-4 border-t border-white/[0.06] space-y-2">
        <button
          onClick={handleAdminSignOut}
          className="w-full py-2 px-3 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-rose-400 text-xs font-medium border border-white/[0.05] transition-colors flex items-center justify-center gap-2"
        >
          <LogOut className="w-3.5 h-3.5" />
          <span>Admin Sign Out</span>
        </button>
      </div>
    </aside>
  );

  return (
    <>
      <div className="hidden lg:block shrink-0">{content}</div>
      {isOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="fixed inset-0 bg-black/70 backdrop-blur-sm" onClick={onClose} />
          <div className="fixed inset-y-0 left-0 max-w-xs w-full shadow-2xl z-10 animate-in slide-in-from-left duration-200">
            {content}
          </div>
        </div>
      )}
    </>
  );
};
