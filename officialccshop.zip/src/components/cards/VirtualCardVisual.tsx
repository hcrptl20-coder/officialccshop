import React, { useState } from 'react';
import { CardCard } from '../../types/index.ts';
import { BrandCardLogo } from '../common/BrandCardLogo.tsx';
import { ShieldCheck, Snowflake, Lock, Copy, Check, Eye, EyeOff, Sparkles, Wifi } from 'lucide-react';

interface VirtualCardVisualProps {
  card: CardCard;
  onToggleFreeze?: (cardId: string) => void;
  onViewDetails?: (card: CardCard) => void;
  isActionLoading?: boolean;
}

export const VirtualCardVisual: React.FC<VirtualCardVisualProps> = ({
  card,
  onToggleFreeze,
  onViewDetails,
  isActionLoading = false,
}) => {
  const [copied, setCopied] = useState(false);
  const [showCardPinNotice, setShowCardPinNotice] = useState(false);

  const isFrozen = card.status === 'FROZEN';

  // Card themes
  const themeClasses = {
    emerald: 'from-emerald-950/90 via-slate-900/90 to-teal-950/90 border-emerald-500/20 shadow-emerald-950/30',
    cyan: 'from-cyan-950/90 via-slate-900/90 to-blue-950/90 border-cyan-500/20 shadow-cyan-950/30',
    purple: 'from-purple-950/90 via-slate-900/90 to-indigo-950/90 border-purple-500/20 shadow-purple-950/30',
    amber: 'from-amber-950/90 via-slate-900/90 to-orange-950/90 border-amber-500/20 shadow-amber-950/30',
  }[card.colorTheme || 'emerald'];

  const handleCopy = (e: React.MouseEvent) => {
    e.stopPropagation();
    navigator.clipboard.writeText(card.maskedNumber);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="flex flex-col gap-4">
      {/* Physical-style card visualizer */}
      <div
        className={`relative w-full aspect-[1.586/1] max-w-[420px] rounded-2xl p-6 bg-gradient-to-br ${themeClasses} border shadow-2xl backdrop-blur-xl overflow-hidden flex flex-col justify-between transition-all duration-300 ${
          isFrozen ? 'grayscale-[60%] opacity-80' : 'hover:scale-[1.01]'
        }`}
      >
        {/* Subtle holographic diagonal stripe & VERIFIED WATERMARK */}
        <div className="absolute inset-0 pointer-events-none opacity-10 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-white via-transparent to-transparent" />
        
        {/* Subtle Watermark Across Center */}
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none select-none overflow-hidden">
          <span className="text-white/[0.04] text-5xl font-black tracking-widest uppercase rotate-[-25deg] whitespace-nowrap">
            PREMIUM CARD • VERIFIED
          </span>
        </div>

        {/* Top bar of card */}
        <div className="relative z-10 flex items-start justify-between">
          <div className="flex items-center gap-2">
            <BrandCardLogo size="sm" />
            <div>
              <span className="relative text-sm font-black tracking-tighter text-transparent bg-clip-text bg-gradient-to-r from-cyan-300 via-fuchsia-300 to-pink-300 block drop-shadow-[0_0_5px_rgba(236,72,153,0.8)]">
                Official<span className="text-white drop-shadow-[0_0_8px_rgba(255,255,255,0.8)] mx-0.5">CC</span>Shop
              </span>
              <span className="text-[10px] text-emerald-400 font-semibold tracking-wide block uppercase">
                {card.cardType}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <Wifi className="w-4 h-4 text-slate-400 rotate-90" />
            {isFrozen ? (
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold tracking-wider bg-rose-500/20 text-rose-300 border border-rose-500/40 flex items-center gap-1">
                <Snowflake className="w-3 h-3" /> FROZEN
              </span>
            ) : (
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold tracking-wider bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 flex items-center gap-1">
                <ShieldCheck className="w-3 h-3" /> ACTIVE — VERIFIED
              </span>
            )}
          </div>
        </div>

        {/* EMV Chip & Contactless */}
        <div className="relative z-10 my-auto flex items-center justify-between">
          <div className="w-12 h-9 rounded-md bg-gradient-to-tr from-amber-200 via-amber-300 to-amber-100 border border-amber-400/60 shadow-inner flex flex-col justify-around p-1 opacity-90">
            <div className="w-full h-px bg-amber-600/40" />
            <div className="w-2/3 h-px bg-amber-600/40" />
            <div className="w-full h-px bg-amber-600/40" />
          </div>
          
          <div className="text-right">
            <span className="text-[10px] uppercase font-bold tracking-wider text-slate-400 block">Status</span>
            <span className="text-xs font-mono font-bold text-slate-200">
              {isFrozen ? 'RESTRICTED' : 'UNLOCKED'}
            </span>
          </div>
        </div>

        {/* Card Number & Details */}
        <div className="relative z-10 space-y-3">
          <div className="flex items-center justify-between">
            <span className="font-mono-numbers text-lg sm:text-xl font-bold tracking-[0.2em] text-slate-100 drop-shadow-sm">
              {card.maskedNumber}
            </span>
            <button
              onClick={handleCopy}
              title="Copy Masked Card Number"
              className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white transition-colors"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            </button>
          </div>

          <div className="flex items-end justify-between text-xs">
            <div>
              <span className="text-[9px] uppercase tracking-wider text-slate-400 block">Cardholder</span>
              <span className="font-semibold text-slate-200 tracking-wider uppercase font-mono">
                {card.cardholderName || 'VALUED USER'}
              </span>
            </div>

            <div className="text-right">
              <span className="text-[9px] uppercase tracking-wider text-slate-400 block">Expires</span>
              <span className="font-mono font-semibold text-slate-200">
                {card.expiryMonth}/{card.expiryYear}
              </span>
            </div>

            <div className="text-right">
              <span className="text-[9px] uppercase tracking-wider text-slate-400 block">Network</span>
              <span className="font-extrabold text-sm text-slate-200 tracking-wider">
                ZENITH
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Action Controls for this Card */}
      <div className="flex flex-wrap items-center gap-2">
        {onViewDetails && (
          <button
            onClick={() => onViewDetails(card)}
            className="flex-1 min-w-[120px] px-3 py-2 rounded-xl text-xs font-semibold bg-slate-800/80 hover:bg-slate-700/80 border border-slate-700/60 text-slate-200 flex items-center justify-center gap-1.5 transition-all shadow-sm active:scale-95"
          >
            <Eye className="w-3.5 h-3.5 text-slate-400" />
            <span>View Card</span>
          </button>
        )}

        {onToggleFreeze && (
          <button
            onClick={() => onToggleFreeze(card.id)}
            disabled={isActionLoading}
            className={`flex-1 min-w-[120px] px-3 py-2 rounded-xl text-xs font-semibold border transition-all shadow-sm active:scale-95 flex items-center justify-center gap-1.5 ${
              isFrozen
                ? 'bg-emerald-950/40 hover:bg-emerald-900/50 border-emerald-500/40 text-emerald-300'
                : 'bg-rose-950/30 hover:bg-rose-900/40 border-rose-500/40 text-rose-300'
            }`}
          >
            <Snowflake className="w-3.5 h-3.5" />
            <span>{isFrozen ? 'Unfreeze Card' : 'Freeze Card'}</span>
          </button>
        )}
      </div>

      {/* Explicit Security & Compliance Notice */}
      <div className="p-2.5 rounded-xl bg-slate-900/40 border border-slate-800/60 text-[11px] text-slate-400 flex items-center gap-2">
        <Lock className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
        <span>
          <strong>Strict Sandbox Protection:</strong> CVV, PIN, and sensitive card data are never stored or exposed.
        </span>
      </div>
    </div>
  );
};
