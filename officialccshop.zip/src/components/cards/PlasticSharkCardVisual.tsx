import React from 'react';
import { CardMarketCard } from '../../data/demoCards.ts';
import { ShoppingCart, Zap, Check, ShieldCheck, Crown, Sparkles } from 'lucide-react';

interface PlasticSharkCardVisualProps {
  card: CardMarketCard;
  onBuyNow?: (card: CardMarketCard) => void;
  onAddToCart?: (card: CardMarketCard) => void;
  onClick?: (card: CardMarketCard) => void;
  isInCart?: boolean;
  isPurchased?: boolean;
  variantIndex?: number;
}

export const PlasticSharkCardVisual: React.FC<PlasticSharkCardVisualProps> = ({
  card,
  onBuyNow,
  onAddToCart,
  onClick,
  isInCart = false,
  isPurchased = false,
  variantIndex = 0,
}) => {
  // Provider badge color style matching the uploaded photo (PlasticShark UI)
  const getBadgeStyle = () => {
    if (card.isVip) {
      return {
        gradient: 'bg-gradient-to-tr from-amber-400 via-yellow-400 to-amber-600 shadow-amber-500/40 text-slate-950',
        letter: '👑',
        btnGradient: 'bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 hover:from-amber-300 hover:to-yellow-300 text-slate-950 font-black shadow-amber-500/40',
      };
    }
    const p = card.provider?.toLowerCase() || '';
    if (p.includes('visa')) {
      if (variantIndex % 2 === 0) {
        return {
          gradient: 'bg-gradient-to-tr from-fuchsia-600 via-purple-600 to-indigo-500',
          letter: 'V',
          btnGradient: 'bg-gradient-to-r from-purple-600 via-fuchsia-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 shadow-purple-600/30',
        };
      } else {
        return {
          gradient: 'bg-gradient-to-tr from-amber-500 via-orange-500 to-cyan-500',
          letter: 'V',
          btnGradient: 'bg-gradient-to-r from-orange-500 via-amber-500 to-yellow-500 hover:from-orange-400 hover:to-amber-400 shadow-orange-500/30',
        };
      }
    } else if (p.includes('master')) {
      return {
        gradient: 'bg-gradient-to-tr from-amber-600 via-orange-600 to-rose-600',
        letter: 'M',
        btnGradient: 'bg-gradient-to-r from-amber-500 via-orange-500 to-rose-500 hover:from-amber-400 hover:to-orange-400 shadow-orange-500/30',
      };
    } else {
      // Amex
      return {
        gradient: 'bg-gradient-to-tr from-cyan-600 via-blue-600 to-purple-600',
        letter: 'A',
        btnGradient: 'bg-gradient-to-r from-cyan-500 via-blue-600 to-indigo-600 hover:from-cyan-400 hover:to-blue-500 shadow-cyan-500/30',
      };
    }
  };

  const badge = getBadgeStyle();

  return (
    <div
      id={`card-${card.cardCode}`}
      onClick={() => onClick && onClick(card)}
      className={`group relative rounded-[28px] p-6 sm:p-7 shadow-2xl backdrop-blur-xl transition-all duration-300 hover:-translate-y-1 cursor-pointer flex flex-col justify-between overflow-hidden ${
        card.isVip
          ? 'bg-[#18192a] border-2 border-amber-400/60 shadow-[0_0_35px_rgba(245,158,11,0.25)] hover:border-amber-300 hover:shadow-[0_0_45px_rgba(245,158,11,0.35)] ring-1 ring-amber-400/30'
          : 'bg-[#161726]/95 border border-white/[0.08] hover:border-cyan-500/40 hover:shadow-cyan-500/10'
      }`}
      style={{
        background: card.isVip
          ? 'radial-gradient(ellipse at top right, rgba(245, 158, 11, 0.12) 0%, rgba(26, 27, 46, 0.98) 60%, rgba(16, 17, 30, 1) 100%)'
          : 'linear-gradient(180deg, rgba(24, 25, 43, 0.96) 0%, rgba(17, 18, 31, 0.98) 100%)',
      }}
    >
      {/* Background subtle radial glow */}
      <div
        className={`absolute top-0 right-0 w-48 h-48 rounded-full blur-2xl pointer-events-none ${
          card.isVip
            ? 'bg-gradient-to-bl from-amber-500/20 via-yellow-500/10 to-transparent'
            : 'bg-gradient-to-bl from-purple-500/10 via-cyan-500/5 to-transparent'
        }`}
      />

      {/* VIP Special Crown Ribbon */}
      {card.isVip && (
        <div className="flex items-center justify-between pb-3 mb-3 border-b border-amber-500/20 relative z-10">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-gradient-to-r from-amber-500/20 via-yellow-500/20 to-amber-500/20 border border-amber-400/40 text-amber-300 text-[11px] font-black tracking-wider uppercase shadow-sm">
            <Crown className="w-3.5 h-3.5 text-amber-400 fill-amber-400 animate-bounce" />
            <span>Mastercard VIP • World Elite</span>
          </div>
          <span className="flex items-center gap-1 text-[10px] font-bold text-amber-400/90 uppercase tracking-widest font-mono">
            <Sparkles className="w-3 h-3 text-amber-400" />
            <span>Top Tier $30</span>
          </span>
        </div>
      )}

      {/* Top Header Row */}
      <div className="flex items-center justify-between gap-3 relative z-10">
        <div className="flex items-center gap-3.5">
          {/* Squircle letter badge matching screenshot */}
          <div
            className={`w-12 h-12 sm:w-13 sm:h-13 rounded-2xl ${badge.gradient} flex items-center justify-center shadow-lg font-extrabold text-xl sm:text-2xl shrink-0 border border-white/20`}
          >
            {badge.letter}
          </div>

          <div>
            <span
              className={`text-[11px] font-bold uppercase tracking-wider block ${
                card.isVip ? 'text-amber-400' : 'text-slate-400'
              }`}
            >
              {card.provider} {card.cardType.toUpperCase()}
            </span>
            <span className="font-mono font-extrabold text-base sm:text-lg text-white tracking-wide block">
              {card.last4}
            </span>
          </div>
        </div>

        {/* In Stock Badge matching screenshot */}
        <div
          className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold shrink-0 ${
            card.isVip
              ? 'bg-amber-500/15 border border-amber-400/40 text-amber-300 font-bold'
              : 'bg-emerald-500/10 border border-emerald-500/20 text-emerald-400'
          }`}
        >
          <span
            className={`w-1.5 h-1.5 rounded-full ${
              card.isVip ? 'bg-amber-400' : 'bg-emerald-400'
            } animate-pulse`}
          />
          <span>{isPurchased ? 'Purchased' : card.isVip ? 'VIP Instant' : 'In Stock'}</span>
        </div>
      </div>

      {/* Specifications Rows */}
      <div className="mt-5 pt-4 border-t border-white/[0.06] space-y-2.5 text-xs sm:text-sm relative z-10">
        <div className="flex items-center justify-between">
          <span className="text-slate-400 font-medium">Limit</span>
          <span
            className={`font-mono font-bold tracking-wide ${
              card.isVip ? 'text-amber-300 text-sm font-black' : 'text-white'
            }`}
          >
            ${card.limitUsd.toLocaleString()}
          </span>
        </div>

        <div className="flex items-center justify-between">
          <span className="text-slate-400 font-medium">Valid Until</span>
          <span className="font-mono font-bold text-white tracking-wide">
            {card.expiry}
          </span>
        </div>

        <div className="flex items-center justify-between text-xs">
          <span className="text-slate-400">Country / State</span>
          <span className="text-slate-200 font-semibold">
            {card.country} ({card.state})
          </span>
        </div>

        <div className="flex items-center justify-between text-[11px] text-slate-400">
          <span className="truncate max-w-[180px]">{card.bank}</span>
          <span
            className={`px-2 py-0.5 rounded font-medium ${
              card.isVip
                ? 'bg-amber-500/10 text-amber-300 border border-amber-500/20'
                : 'bg-white/[0.04] text-slate-300'
            }`}
          >
            {card.extras}
          </span>
        </div>
      </div>

      {/* Large Price Display matching screenshot */}
      <div className="mt-6 mb-5 relative z-10">
        <div
          className={`font-mono font-extrabold text-3xl sm:text-4xl tracking-tight flex items-baseline gap-1 ${
            card.isVip
              ? 'text-amber-400 drop-shadow-[0_0_15px_rgba(245,158,11,0.35)]'
              : 'text-cyan-400'
          }`}
        >
          <span>${card.priceUsd.toFixed(2)}</span>
          {card.isVip && (
            <span className="text-xs font-sans font-bold uppercase text-amber-400/80 px-2 py-0.5 rounded-md bg-amber-400/10 border border-amber-400/20 ml-2">
              VIP Deal
            </span>
          )}
        </div>
        <div className="flex items-center justify-between mt-1 text-xs">
          <span className="text-slate-400 font-medium">USDT / USD per card</span>
          <span
            className={`font-mono font-bold px-2 py-0.5 rounded border ${
              card.isVip
                ? 'text-amber-300 bg-amber-500/15 border-amber-400/40 shadow-sm'
                : 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20'
            }`}
          >
            ₹{card.priceInr.toLocaleString('en-IN', { minimumFractionDigits: 2 })} INR
          </span>
        </div>
      </div>

      {/* Bottom Action Buttons Row matching screenshot */}
      <div className="grid grid-cols-2 gap-3 relative z-10 pt-1" onClick={(e) => e.stopPropagation()}>
        <button
          type="button"
          onClick={() => onAddToCart && onAddToCart(card)}
          disabled={isPurchased}
          className={`py-3 px-3 rounded-2xl border font-semibold text-xs sm:text-sm transition-all duration-200 flex items-center justify-center gap-1.5 active:scale-95 ${
            isInCart
              ? 'bg-emerald-500/20 border-emerald-500/40 text-emerald-300'
              : card.isVip
              ? 'bg-slate-900/90 hover:bg-slate-850 border-amber-500/30 text-amber-200 hover:border-amber-400/50'
              : 'bg-slate-800/80 hover:bg-slate-700/80 border-white/[0.1] text-white hover:border-white/[0.2]'
          } ${isPurchased ? 'opacity-50 cursor-not-allowed' : ''}`}
        >
          {isInCart ? (
            <>
              <Check className="w-4 h-4 text-emerald-400" />
              <span>In Cart</span>
            </>
          ) : (
            <>
              <ShoppingCart className={`w-4 h-4 ${card.isVip ? 'text-amber-400' : 'text-slate-400'}`} />
              <span>Add to Cart</span>
            </>
          )}
        </button>

        <button
          type="button"
          onClick={() => onBuyNow && onBuyNow(card)}
          className={`py-3 px-4 rounded-2xl ${badge.btnGradient} text-white font-bold text-xs sm:text-sm transition-all duration-200 flex items-center justify-center gap-1.5 shadow-lg active:scale-95 ${
            isPurchased ? 'bg-slate-700 hover:bg-slate-700 cursor-default' : ''
          }`}
        >
          {isPurchased ? (
            <>
              <ShieldCheck className="w-4 h-4" />
              <span>View Card</span>
            </>
          ) : (
            <>
              {card.isVip ? (
                <Crown className="w-4 h-4 fill-slate-950 text-slate-950" />
              ) : (
                <Zap className="w-4 h-4 fill-current" />
              )}
              <span>{card.isVip ? 'Buy VIP Card' : 'Buy Now'}</span>
            </>
          )}
        </button>
      </div>
    </div>
  );
};
