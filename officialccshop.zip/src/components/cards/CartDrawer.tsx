import React, { useState } from 'react';
import { CardMarketCard } from '../../data/demoCards.ts';
import { User, CardCard } from '../../types/index.ts';
import { apiRequest } from '../../lib/api.ts';
import {
  X,
  Trash2,
  ShoppingCart,
  Wallet,
  ArrowRight,
  Zap,
  AlertCircle,
  CheckCircle2,
} from 'lucide-react';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CardMarketCard[];
  onRemoveItem: (cardId: string) => void;
  onClearCart: () => void;
  currentUser: User | null;
  onPurchaseSuccess: (purchasedCards: CardCard[], newBalance: number) => void;
  onNavigateToDeposit: (amount?: number) => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  cartItems,
  onRemoveItem,
  onClearCart,
  currentUser,
  onPurchaseSuccess,
  onNavigateToDeposit,
}) => {
  const [isProcessing, setIsProcessing] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  const totalUsd = cartItems.reduce((sum, item) => sum + item.priceUsd, 0);
  const totalInr = cartItems.reduce((sum, item) => sum + item.priceInr, 0);
  const userBalance = currentUser?.balance ?? 0;
  const hasEnoughBalance = userBalance >= totalInr;

  const handleCheckout = async () => {
    if (cartItems.length === 0) return;
    if (!hasEnoughBalance) {
      setErrorMsg(
        `Insufficient balance! Total is ₹${totalInr.toFixed(2)}, but your balance is ₹${userBalance.toFixed(2)}. Minimum deposit is ₹1,000.`
      );
      return;
    }

    setIsProcessing(true);
    setErrorMsg(null);

    const purchasedCards: CardCard[] = [];
    let updatedBalance = userBalance;

    for (const card of cartItems) {
      const res = await apiRequest<{ success: boolean; card: CardCard; newBalance: number }>(
        '/api/cards/purchase',
        {
          method: 'POST',
          body: JSON.stringify({ card }),
        }
      );
      if (res.ok && res.data && res.data.success) {
        purchasedCards.push(res.data.card);
        updatedBalance = res.data.newBalance;
      }
    }

    setIsProcessing(false);

    if (purchasedCards.length > 0) {
      onPurchaseSuccess(purchasedCards, updatedBalance);
      onClearCart();
      onClose();
    } else {
      setErrorMsg('Failed to process card order. Please try again.');
    }
  };

  return (
    <div
      id="cart-drawer-backdrop"
      className="fixed inset-0 z-50 flex justify-end bg-slate-950/80 backdrop-blur-sm animate-fadeIn"
      onClick={onClose}
    >
      <div
        id="cart-drawer-panel"
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-md bg-[#131422] border-l border-white/[0.1] h-full flex flex-col justify-between p-6 overflow-y-auto text-white"
        style={{
          background: 'linear-gradient(180deg, #18192c 0%, #10111e 100%)',
        }}
      >
        <div>
          {/* Header */}
          <div className="flex items-center justify-between pb-4 border-b border-white/[0.08]">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-purple-500/10 text-purple-400 border border-purple-500/20">
                <ShoppingCart className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-lg text-white">Your Cart</h3>
                <span className="text-xs text-slate-400">{cartItems.length} card cards selected</span>
              </div>
            </div>

            <button
              type="button"
              onClick={onClose}
              className="p-2 rounded-xl bg-white/[0.06] hover:bg-white/[0.1] text-slate-400 hover:text-white transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Cart Items List */}
          <div className="mt-5 space-y-3">
            {cartItems.length === 0 ? (
              <div className="py-12 text-center text-slate-400 space-y-3">
                <ShoppingCart className="w-12 h-12 mx-auto text-slate-600 stroke-[1.5]" />
                <p className="text-sm font-medium">Your cart is empty</p>
                <p className="text-xs text-slate-500 max-w-xs mx-auto">
                  Browse the cards catalog and click "Add to Cart" or "Buy Now" on any card card.
                </p>
              </div>
            ) : (
              cartItems.map((item) => (
                <div
                  key={item.id}
                  className={`p-3.5 rounded-2xl border flex items-center justify-between gap-3 transition ${
                    item.isVip
                      ? 'bg-amber-500/10 border-amber-400/30 hover:border-amber-400/50'
                      : 'bg-white/[0.04] border border-white/[0.06] hover:border-white/[0.12]'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div
                      className={`w-10 h-10 rounded-xl flex items-center justify-center font-extrabold text-base ${
                        item.isVip
                          ? 'bg-gradient-to-tr from-amber-400 to-yellow-500 text-slate-950 shadow-md shadow-amber-500/20'
                          : 'bg-gradient-to-tr from-purple-600 to-indigo-600 text-white'
                      }`}
                    >
                      {item.isVip ? '👑' : item.provider?.charAt(0) || 'C'}
                    </div>
                    <div>
                      <div className="flex items-center gap-1.5">
                        <span
                          className={`font-bold text-xs ${
                            item.isVip ? 'text-amber-300' : 'text-white'
                          }`}
                        >
                          {item.provider}
                        </span>
                        {item.isVip && (
                          <span className="text-[9px] font-black uppercase px-1.5 py-0.5 rounded bg-amber-400/20 text-amber-300 border border-amber-400/30">
                            VIP
                          </span>
                        )}
                        <span className="font-mono text-[10px] text-slate-400">({item.last4})</span>
                      </div>
                      <span className="text-[11px] text-slate-400 block font-mono">
                        {item.cardCode} • {item.country}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <div className="text-right">
                      <span
                        className={`font-mono font-bold text-xs block ${
                          item.isVip ? 'text-amber-400' : 'text-cyan-400'
                        }`}
                      >
                        ${item.priceUsd.toFixed(2)}
                      </span>
                      <span className="font-mono text-[10px] text-emerald-400 block">
                        ₹{item.priceInr.toFixed(0)}
                      </span>
                    </div>

                    <button
                      type="button"
                      onClick={() => onRemoveItem(item.id)}
                      className="p-1.5 rounded-lg text-slate-500 hover:text-rose-400 hover:bg-rose-500/10 transition"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Footer with totals and action */}
        {cartItems.length > 0 && (
          <div className="pt-4 border-t border-white/[0.08] space-y-4">
            {/* Balance status */}
            <div className="p-3.5 rounded-2xl bg-white/[0.03] border border-white/[0.06] flex items-center justify-between text-xs">
              <div className="flex items-center gap-2">
                <Wallet className="w-4 h-4 text-cyan-400" />
                <span className="text-slate-400">Available Balance:</span>
              </div>
              <span className="font-mono font-bold text-white">
                ₹{userBalance.toFixed(2)} (${(userBalance / 94.49).toFixed(2)})
              </span>
            </div>

            {/* Total */}
            <div className="flex items-center justify-between text-sm">
              <span className="text-slate-300 font-medium">Order Total:</span>
              <div className="text-right">
                <span className="font-mono font-extrabold text-xl text-cyan-400 block">
                  ${totalUsd.toFixed(2)} USD
                </span>
                <span className="font-mono font-bold text-xs text-emerald-400 block">
                  ≈ ₹{totalInr.toFixed(2)} INR
                </span>
              </div>
            </div>

            {/* Insufficient balance message */}
            {!hasEnoughBalance && (
              <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-200 text-xs space-y-2">
                <div className="flex items-center gap-1.5 font-bold text-amber-300">
                  <AlertCircle className="w-4 h-4" />
                  <span>Insufficient Balance</span>
                </div>
                <p className="text-slate-300 text-[11px] leading-relaxed">
                  You need ₹{(totalInr - userBalance).toFixed(2)} more. Minimum deposit is ₹1,000 via Airtel UPI / QR.
                </p>
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onNavigateToDeposit(1000);
                  }}
                  className="w-full py-2 px-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs flex items-center justify-center gap-1.5 transition"
                >
                  <span>Deposit ₹1,000 Now</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            )}

            {errorMsg && (
              <div className="p-2.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs">
                {errorMsg}
              </div>
            )}

            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={onClearCart}
                className="py-3 px-3 rounded-2xl bg-slate-800/80 hover:bg-slate-700 text-slate-300 font-semibold text-xs transition"
              >
                Clear Cart
              </button>

              <button
                type="button"
                onClick={handleCheckout}
                disabled={!hasEnoughBalance || isProcessing}
                className={`py-3 px-4 rounded-2xl bg-gradient-to-r from-purple-600 via-fuchsia-600 to-pink-600 text-white font-bold text-xs transition-all shadow-lg flex items-center justify-center gap-1.5 active:scale-95 ${
                  !hasEnoughBalance || isProcessing ? 'opacity-50 cursor-not-allowed' : ''
                }`}
              >
                {isProcessing ? (
                  <span>Processing...</span>
                ) : (
                  <>
                    <Zap className="w-4 h-4 fill-current" />
                    <span>Buy Now</span>
                  </>
                )}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
