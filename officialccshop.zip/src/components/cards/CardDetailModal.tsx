import React, { useState, useEffect } from 'react';
import { CardMarketCard } from '../../data/demoCards.ts';
import { User, CardCard } from '../../types/index.ts';
import { apiRequest } from '../../lib/api.ts';
import { LoginPage } from '../../pages/auth/LoginPage.tsx';
import {
  X,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  Copy,
  Check,
  ArrowRight,
  Sparkles,
  Lock,
  Wallet,
  Zap,
  QrCode,
  Upload,
  Image as ImageIcon,
  CheckCircle,
  Crown,
  Download,
  Smartphone,
  Gift,
  ShoppingBag,
} from 'lucide-react';

interface CardDetailModalProps {
  card: CardMarketCard | null;
  isOpen: boolean;
  onClose: () => void;
  currentUser: User | null;
  onPurchaseSuccess: (purchasedCard: CardCard, newBalance: number) => void;
  onNavigateToDeposit: (amount?: number) => void;
  isAlreadyPurchased?: boolean;
  purchasedCardData?: CardCard | null;
}

export const CardDetailModal: React.FC<CardDetailModalProps> = ({
  card,
  isOpen,
  onClose,
  currentUser,
  onPurchaseSuccess,
  onNavigateToDeposit,
  isAlreadyPurchased = false,
  purchasedCardData = null,
}) => {
  const [isPurchasing, setIsPurchasing] = useState(false);
  const [purchaseError, setPurchaseError] = useState<string | null>(null);
  const [copiedField, setCopiedField] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'details' | 'credentials'>('details');

  // Direct UPI Payment & UTR submission states
  const [payMode, setPayMode] = useState<'wallet' | 'upi' | 'amazon' | 'flipkart'>('upi');
  const [utrNumber, setUtrNumber] = useState('');
  const [voucherCode, setVoucherCode] = useState('');
  const [voucherPin, setVoucherPin] = useState('');
  const [proofUrl, setProofUrl] = useState('');
  const [isUploadingProof, setIsUploadingProof] = useState(false);
  const [isSubmittingUtr, setIsSubmittingUtr] = useState(false);
  const [orderSubmittedSuccess, setOrderSubmittedSuccess] = useState<string | null>(null);
  const [qrCodeUrl, setQrCodeUrl] = useState<string | null>(null);
  const [requireAuth, setRequireAuth] = useState(false);

  useEffect(() => {
    if (isOpen && card) {
      // Fetch dynamic QR for card price
      apiRequest<{ qrDataUrl: string }>(`/api/deposit/generate-qr?amount=${card.priceInr}`).then((res) => {
        if (res.ok && res.data?.qrDataUrl) {
          setQrCodeUrl(res.data.qrDataUrl);
        }
      });
    }
  }, [isOpen, card?.priceInr]);

  if (!isOpen || !card) return null;

  const userBalance = currentUser?.balance ?? 0;
  const hasEnoughBalance = userBalance >= card.priceInr;

  const handleCopy = (text: string, fieldKey: string) => {
    navigator.clipboard.writeText(text);
    setCopiedField(fieldKey);
    setTimeout(() => setCopiedField(null), 2000);
  };

  const handleDownloadQr = () => {
    if (!qrCodeUrl || !card) return;
    const a = document.createElement('a');
    a.href = qrCodeUrl;
    a.download = `OfficialCCShop-QR-${card.cardCode}.png`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploadingProof(true);
    setPurchaseError(null);

    const formData = new FormData();
    formData.append('file', file);

    const res = await apiRequest<{ url: string }>('/api/upload', {
      method: 'POST',
      body: formData,
    });

    setIsUploadingProof(false);
    if (res.ok && res.data?.url) {
      setProofUrl(res.data.url);
    } else {
      setPurchaseError(res.error || 'Failed to upload screenshot image.');
    }
  };

  const handleSubmitUtrOrder = async (e?: React.FormEvent, skipAuthCheck: boolean = false) => {
    if (e) e.preventDefault();
    setPurchaseError(null);

    const cleanUtr = utrNumber.trim();
    if (!cleanUtr || cleanUtr.length < 6) {
      setPurchaseError('Please enter a valid 12-digit UTR reference number from your UPI app.');
      return;
    }



    setIsSubmittingUtr(true);

    const res = await apiRequest<{ message: string; deposit: any }>('/api/deposits', {
      method: 'POST',
      body: JSON.stringify({
        amount: card.priceInr,
        referenceNo: cleanUtr,
        proofUrl: proofUrl,
        cardId: card.id,
        cardName: card.name,
        cardProvider: card.provider,
        cardPriceUsd: card.priceUsd,
        purpose: `Card Purchase: ${card.name}`,
      }),
    });

    setIsSubmittingUtr(false);

    if (res.ok) {
      setOrderSubmittedSuccess(
        `Your card purchase for ${card.name} with UTR ${cleanUtr} has been submitted! Admin will verify your payment screenshot and activate your card.`
      );
    } else {
      setPurchaseError(res.error || 'Failed to submit card order. Please try again.');
    }
  };

  const handleSubmitVoucherOrder = async (e: React.FormEvent | undefined, provider: 'Amazon' | 'Flipkart', skipAuthCheck: boolean = false) => {
    if (e) e.preventDefault();
    setPurchaseError(null);

    const cleanVoucher = voucherCode.trim();
    if (!cleanVoucher || cleanVoucher.length < 8) {
      setPurchaseError(`Please enter a valid ${provider} gift voucher code.`);
      return;
    }

    const cleanPin = voucherPin.trim();
    if (provider === 'Flipkart' && (!cleanPin || cleanPin.length < 4)) {
      setPurchaseError(`Please enter a valid Flipkart gift voucher PIN.`);
      return;
    }



    setIsSubmittingUtr(true); // Using same loading state

    let finalReference = cleanVoucher;
    if (provider === 'Flipkart') {
      finalReference = `${cleanVoucher} (PIN: ${cleanPin})`;
    }

    const res = await apiRequest<{ message: string; deposit: any }>('/api/deposits', {
      method: 'POST',
      body: JSON.stringify({
        amount: card!.priceInr,
        referenceNo: finalReference,
        cardId: card!.id,
        cardName: card!.name,
        cardProvider: card!.provider,
        cardPriceUsd: card!.priceUsd,
        purpose: `${provider} Gift Voucher for Card: ${card!.name}`,
      }),
    });

    setIsSubmittingUtr(false);

    if (res.ok) {
      setOrderSubmittedSuccess(
        `Your ${provider} gift voucher has been submitted! Please wait 30 mins for gift voucher checking and card activation.`
      );
    } else {
      setPurchaseError(res.error || `Failed to submit ${provider} voucher. Please try again.`);
    }
  };

  const handleConfirmPurchase = async () => {
    if (!hasEnoughBalance) {
      setPurchaseError(
        `Insufficient balance! You have ₹${userBalance.toFixed(2)}, but this card costs ₹${card.priceInr.toFixed(2)}.`
      );
      return;
    }

    setIsPurchasing(true);
    setPurchaseError(null);

    const res = await apiRequest<{ success: boolean; card: CardCard; newBalance: number }>(
      '/api/cards/purchase',
      {
        method: 'POST',
        body: JSON.stringify({ card }),
      }
    );

    setIsPurchasing(false);

    if (res.ok && res.data && res.data.success) {
      onPurchaseSuccess(res.data.card, res.data.newBalance);
      setActiveTab('credentials');
    } else {
      setPurchaseError(res.error || 'Failed to complete card purchase. Please check your balance.');
    }
  };

  // Badge gradient based on provider
  const getBadgeStyle = () => {
    if (card.isVip) {
      return {
        gradient: 'bg-gradient-to-tr from-amber-400 via-yellow-400 to-amber-600 shadow-amber-500/40 text-slate-950',
        letter: '👑',
        btnGradient: 'bg-gradient-to-r from-amber-400 via-yellow-400 to-amber-500 hover:from-amber-300 hover:to-yellow-300 text-slate-950 font-black shadow-amber-500/40',
      };
    }
    const p = card.provider?.toLowerCase() || '';
    if (p.includes('visa')) {
      return {
        gradient: 'bg-gradient-to-tr from-fuchsia-600 via-purple-600 to-indigo-500',
        letter: 'V',
        btnGradient: 'bg-gradient-to-r from-purple-600 via-fuchsia-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 shadow-purple-600/30',
      };
    } else if (p.includes('master')) {
      return {
        gradient: 'bg-gradient-to-tr from-amber-600 via-orange-600 to-rose-600',
        letter: 'M',
        btnGradient: 'bg-gradient-to-r from-amber-500 via-orange-500 to-rose-500 hover:from-amber-400 hover:to-orange-400 shadow-orange-500/30',
      };
    } else {
      return {
        gradient: 'bg-gradient-to-tr from-cyan-600 via-blue-600 to-purple-600',
        letter: 'A',
        btnGradient: 'bg-gradient-to-r from-cyan-500 via-blue-600 to-indigo-600 hover:from-cyan-400 hover:to-blue-500 shadow-cyan-500/30',
      };
    }
  };

  const badge = getBadgeStyle();
  const cardData = purchasedCardData;

  return (
    <div
      id="card-detail-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-md overflow-y-auto animate-fadeIn"
      onClick={onClose}
    >
      {requireAuth ? (
        <div
          onClick={(e) => e.stopPropagation()}
          className="relative bg-slate-950 border border-white/[0.08] w-full max-w-md rounded-3xl shadow-2xl shadow-purple-900/10 overflow-hidden"
        >
          <button
            onClick={() => setRequireAuth(false)}
            className="absolute top-4 right-4 z-10 p-2 rounded-full bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
          <LoginPage 
            onNavigate={() => {}} 
            onSuccess={() => {
              setRequireAuth(false);
              if (payMode === 'amazon') handleSubmitVoucherOrder(undefined, 'Amazon', true);
              else if (payMode === 'flipkart') handleSubmitVoucherOrder(undefined, 'Flipkart', true);
              else handleSubmitUtrOrder(undefined, true);
            }} 
          />
        </div>
      ) : (
      <div
        id="card-detail-modal-container"
        onClick={(e) => e.stopPropagation()}
        className={`w-full max-w-2xl rounded-3xl bg-[#131422] p-5 sm:p-7 relative overflow-hidden my-6 text-white space-y-6 shadow-2xl ${
          card.isVip
            ? 'border-2 border-amber-400/60 shadow-[0_0_50px_rgba(245,158,11,0.25)]'
            : 'border border-white/[0.12]'
        }`}
        style={{
          background: card.isVip
            ? 'radial-gradient(ellipse at top, rgba(245, 158, 11, 0.12) 0%, rgba(24, 25, 44, 0.98) 50%, rgba(14, 15, 26, 1) 100%)'
            : 'linear-gradient(180deg, #18192c 0%, #10111e 100%)',
        }}
      >
        {/* Top subtle glow banner */}
        <div
          className={`absolute top-0 left-1/4 right-1/4 h-1 blur-sm ${
            card.isVip
              ? 'bg-gradient-to-r from-transparent via-amber-400/80 to-transparent'
              : 'bg-gradient-to-r from-transparent via-cyan-400/50 to-transparent'
          }`}
        />

        {/* Modal Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div
              className={`w-11 h-11 rounded-2xl ${badge.gradient} flex items-center justify-center font-extrabold text-xl border border-white/20 shadow-lg`}
            >
              {badge.letter}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3
                  className={`text-lg sm:text-xl font-bold tracking-tight ${
                    card.isVip ? 'text-amber-300' : 'text-white'
                  }`}
                >
                  {card.provider} {card.cardType}
                </h3>
                <span
                  className={`font-mono text-xs font-bold px-2 py-0.5 rounded ${
                    card.isVip
                      ? 'bg-amber-400/20 text-amber-300 border border-amber-400/30'
                      : 'bg-white/[0.06] text-slate-300'
                  }`}
                >
                  {card.cardCode}
                </span>
                {card.isVip && (
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-amber-500/20 border border-amber-400/40 text-amber-300 text-[10px] font-black uppercase tracking-wider">
                    <Crown className="w-3 h-3 text-amber-400 fill-amber-400" />
                    <span>VIP ELITE</span>
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-400">
                {card.name} • {card.bank}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-xl bg-white/[0.06] hover:bg-white/[0.1] text-slate-400 hover:text-white transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Visual Card Showcase matching screenshot format */}
        <div className="p-5 sm:p-6 rounded-3xl bg-[#1a1b2f]/90 border border-white/[0.08] shadow-inner relative overflow-hidden">
          <div className="absolute top-0 right-0 w-40 h-40 bg-cyan-500/10 rounded-full blur-2xl pointer-events-none" />

          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <div
                className={`w-10 h-10 rounded-xl ${badge.gradient} flex items-center justify-center font-extrabold text-lg text-white`}
              >
                {badge.letter}
              </div>
              <div>
                <div className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">
                  {card.provider} CLASSIC
                </div>
                <div className="font-mono font-bold text-sm sm:text-base text-white tracking-wider">
                  {card.last4}
                </div>
              </div>
            </div>

            <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-semibold">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              <span>{isAlreadyPurchased ? 'Purchased & Active' : 'In Stock'}</span>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3 text-xs py-3 border-y border-white/[0.06]">
            <div>
              <span className="text-slate-400 block text-[11px]">Limit</span>
              <span className="font-mono font-bold text-white text-sm sm:text-base">${card.limitUsd}</span>
            </div>
            <div>
              <span className="text-slate-400 block text-[11px]">Valid Until</span>
              <span className="font-mono font-bold text-white text-sm sm:text-base">{card.expiry}</span>
            </div>
          </div>

          {/* Large Price Showcase */}
          <div className="mt-4 flex flex-col sm:flex-row sm:items-baseline justify-between gap-2">
            <div>
              <div className="font-mono font-extrabold text-3xl sm:text-4xl text-cyan-400">
                ${card.priceUsd.toFixed(2)}
              </div>
              <div className="text-xs text-slate-400">USDT / USD per card</div>
            </div>

            <div className="text-left sm:text-right">
              <span className="font-mono font-bold text-lg text-emerald-400 bg-emerald-500/10 px-3 py-1 rounded-xl border border-emerald-500/20 inline-block">
                ₹{card.priceInr.toLocaleString('en-IN', { minimumFractionDigits: 2 })} INR
              </span>
              <div className="text-[11px] text-slate-400 mt-0.5">Dual-Rate: 1 USD = ₹94.49</div>
            </div>
          </div>
        </div>

        {/* Complete Information Specifications Table */}
        <div className="space-y-3">
          <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-cyan-400" />
            <span>Card Specifications & Billing Profile</span>
          </h4>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 text-xs">
            <div className="p-3 rounded-2xl bg-white/[0.03] border border-white/[0.05]">
              <span className="text-slate-500 block text-[10px] uppercase font-bold">BIN / Card ID</span>
              <span className="font-mono font-bold text-white text-xs">{card.cardCode}</span>
            </div>
            <div className="p-3 rounded-2xl bg-white/[0.03] border border-white/[0.05]">
              <span className="text-slate-500 block text-[10px] uppercase font-bold">Card Provider</span>
              <span className="font-bold text-white text-xs">{card.provider} ({card.cardType})</span>
            </div>
            <div className="p-3 rounded-2xl bg-white/[0.03] border border-white/[0.05]">
              <span className="text-slate-500 block text-[10px] uppercase font-bold">Valid Expiry</span>
              <span className="font-mono font-bold text-white text-xs">{card.expiry}</span>
            </div>
            <div className="p-3 rounded-2xl bg-white/[0.03] border border-white/[0.05]">
              <span className="text-slate-500 block text-[10px] uppercase font-bold">Country & State</span>
              <span className="font-semibold text-white text-xs">{card.country} • {card.state}</span>
            </div>
            <div className="p-3 rounded-2xl bg-white/[0.03] border border-white/[0.05]">
              <span className="text-slate-500 block text-[10px] uppercase font-bold">Billing ZIP</span>
              <span className="font-mono font-semibold text-white text-xs">{card.zip}</span>
            </div>
            <div className="p-3 rounded-2xl bg-white/[0.03] border border-white/[0.05]">
              <span className="text-slate-500 block text-[10px] uppercase font-bold">Features / Extras</span>
              <span className="font-semibold text-cyan-300 text-xs">{card.extras}</span>
            </div>
            <div className="p-3 rounded-2xl bg-white/[0.03] border border-white/[0.05] sm:col-span-2">
              <span className="text-slate-500 block text-[10px] uppercase font-bold">Issuing Bank</span>
              <span className="font-semibold text-slate-200 text-xs">{card.bank}</span>
            </div>
            <div className="p-3 rounded-2xl bg-white/[0.03] border border-white/[0.05]">
              <span className="text-slate-500 block text-[10px] uppercase font-bold">Cardholder</span>
              <span className="font-semibold text-slate-200 text-xs truncate block">{card.name}</span>
            </div>
            <div className="p-3 rounded-2xl bg-white/[0.03] border border-cyan-500/20 sm:col-span-3 flex items-center justify-between">
              <div>
                <span className="text-slate-500 block text-[10px] uppercase font-bold">Catalog Price (USD / INR)</span>
                <span className="font-mono font-extrabold text-cyan-400 text-sm sm:text-base">${card.priceUsd.toFixed(2)} USD</span>
              </div>
              <div className="text-right">
                <span className="font-mono font-bold text-emerald-400 text-sm sm:text-base">₹{card.priceInr.toLocaleString('en-IN', { minimumFractionDigits: 2 })} INR</span>
                <span className="text-[10px] text-slate-400 block">Dual rate: $1 = ₹94.49</span>
              </div>
            </div>
          </div>
        </div>

        {/* Unlocked Credentials View (if purchased) */}
        {isAlreadyPurchased && cardData && (
          <div className="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 space-y-3">
            <div className="flex items-center justify-between text-xs">
              <div className="flex items-center gap-2 text-emerald-400 font-bold">
                <CheckCircle2 className="w-4 h-4" />
                <span>Unlocked Card Details</span>
              </div>
              <span className="text-slate-400 text-[11px]">Click copy to grab credentials</span>
            </div>

            <div className="space-y-2 font-mono text-xs">
              <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-900/80 border border-white/[0.06]">
                <div>
                  <span className="text-[10px] text-slate-400 block font-sans">Card Number</span>
                  <span className="font-bold text-white text-sm">{cardData.maskedNumber}</span>
                </div>
                <button
                  type="button"
                  onClick={() => handleCopy(cardData.maskedNumber, 'num')}
                  className="p-1.5 rounded-lg bg-white/[0.06] hover:bg-white/[0.1] text-slate-300 transition flex items-center gap-1 text-[11px]"
                >
                  {copiedField === 'num' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedField === 'num' ? 'Copied' : 'Copy'}</span>
                </button>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-900/80 border border-white/[0.06]">
                  <div>
                    <span className="text-[10px] text-slate-400 block font-sans">Expiry</span>
                    <span className="font-bold text-white">{cardData.expiryMonth}/{cardData.expiryYear}</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => handleCopy(`${cardData.expiryMonth}/${cardData.expiryYear}`, 'exp')}
                    className="p-1 text-slate-300 hover:text-white"
                  >
                    {copiedField === 'exp' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                </div>

                <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-900/80 border border-white/[0.06]">
                  <div>
                    <span className="text-[10px] text-slate-400 block font-sans">CVV</span>
                    <span className="font-bold text-emerald-400">{cardData.cvv || '729'}</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => handleCopy(cardData.cvv || '729', 'cvv')}
                    className="p-1 text-slate-300 hover:text-white"
                  >
                    {copiedField === 'cvv' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Order Submitted Success State */}
        {orderSubmittedSuccess ? (
          <div className="pt-3 border-t border-white/[0.08] space-y-4">
            <div className="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-center space-y-2">
              <div className="w-10 h-10 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto">
                <CheckCircle className="w-6 h-6" />
              </div>
              <h4 className="text-sm font-bold text-white">Card Purchase Request Submitted!</h4>
              <p className="text-xs text-slate-300 leading-relaxed max-w-md mx-auto">
                {orderSubmittedSuccess}
              </p>
              <p className="text-[11px] text-purple-300 font-mono">
                Admin will review your 12-digit UTR and payment screenshot in the Admin Portal.
              </p>
            </div>

            <button
              type="button"
              onClick={onClose}
              className="w-full py-3 px-4 rounded-2xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-sm transition-all shadow-lg shadow-purple-600/20"
            >
              Close & View My Cards
            </button>
          </div>
        ) : !isAlreadyPurchased ? (
          /* Purchasing Selection & Forms */
          <div className="pt-3 border-t border-white/[0.08] space-y-4">
            {/* Mode Selector Tabs */}
            <div className="grid grid-cols-2 gap-1.5 p-1 rounded-2xl bg-slate-900 border border-white/[0.06]">
              <button
                type="button"
                onClick={() => setPayMode('upi')}
                className={`py-2 px-2 rounded-xl text-[10px] sm:text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
                  (payMode === 'upi' || payMode === 'amazon' || payMode === 'flipkart')
                    ? 'bg-purple-600 text-white shadow-md shadow-purple-600/20'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <QrCode className="w-3 h-3 sm:w-3.5 sm:h-3.5" />
                <span>UPI Pay</span>
              </button>

              <button
                type="button"
                onClick={() => setPayMode('wallet')}
                className={`py-2 px-2 rounded-xl text-[10px] sm:text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
                  payMode === 'wallet'
                    ? 'bg-purple-600 text-white shadow-md shadow-purple-600/20'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <Wallet className="w-3 h-3 sm:w-3.5 sm:h-3.5" />
                <span>Wallet</span>
              </button>
            </div>

            {/* Price Header Banner */}
            <div className="flex items-center justify-between p-3 rounded-2xl bg-white/[0.03] border border-white/[0.06] text-xs">
              <span className="text-slate-400">Card Price:</span>
              <div className="text-right">
                <span className="font-mono font-bold text-sm text-emerald-400">
                  ₹{card.priceInr.toLocaleString('en-IN', { minimumFractionDigits: 2 })} INR
                </span>
                <span className="text-[11px] text-slate-400 ml-1.5">
                  (${card.priceUsd.toFixed(2)} USD)
                </span>
              </div>
            </div>

            {/* MODE 1: Direct UPI QR with UTR & Screenshot */}
            {payMode === 'upi' && (
              <form onSubmit={handleSubmitUtrOrder} className="space-y-4">
                {/* QR Code & UPI Information Box */}
                <div className="p-4 rounded-2xl bg-slate-900 border border-purple-500/20 space-y-4">
                  <div className="flex flex-col sm:flex-row items-center gap-5">
                    {/* QR Preview */}
                    <div className="flex flex-col items-center gap-2">
                      <div className="w-44 h-44 sm:w-52 sm:h-52 bg-white rounded-2xl p-2 shrink-0 shadow-xl flex items-center justify-center relative group">
                        {qrCodeUrl ? (
                          <>
                            <img
                              src={qrCodeUrl}
                              alt="UPI Payment QR"
                              className="w-full h-full object-contain"
                            />
                            {/* Overlay Download Button on hover */}
                            <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity rounded-xl backdrop-blur-[2px]">
                              <button
                                type="button"
                                onClick={handleDownloadQr}
                                className="px-4 py-2 bg-purple-600 hover:bg-purple-500 text-white font-bold rounded-lg flex items-center gap-2 transition-transform hover:scale-105 active:scale-95"
                              >
                                <Download className="w-4 h-4" />
                                <span>Save QR</span>
                              </button>
                            </div>
                          </>
                        ) : (
                          <div className="w-full h-full flex flex-col items-center justify-center text-slate-400">
                            <QrCode className="w-10 h-10 animate-pulse text-purple-600" />
                            <span className="text-xs text-slate-600 font-mono mt-2">Generating QR</span>
                          </div>
                        )}
                      </div>
                      <button
                        type="button"
                        onClick={handleDownloadQr}
                        disabled={!qrCodeUrl}
                        className="text-[11px] text-purple-400 hover:text-purple-300 font-semibold flex items-center gap-1.5 transition-colors px-2 py-1"
                      >
                        <Download className="w-3.5 h-3.5" />
                        Download QR Code
                      </button>

                      <a
                        href={`upi://pay?pa=nehapatel20@fam&pn=OfficialCCShop&am=${card.priceInr}&cu=INR&tn=OfficialCCShop%20Card%20Purchase`}
                        className="w-full py-2 px-3 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-bold flex items-center justify-center gap-1.5 transition-all shadow-md shadow-emerald-950/40 active:scale-95"
                      >
                        <Zap className="w-3.5 h-3.5 text-amber-300" />
                        <span>Pay with UPI App</span>
                      </a>
                    </div>

                    {/* Instructions & UPI Copy */}
                    <div className="flex-1 space-y-3 text-center sm:text-left">
                      <span className="inline-block px-2.5 py-1 rounded-full text-[11px] font-bold uppercase bg-emerald-500/10 text-emerald-300 border border-emerald-500/20">
                        Scan & Pay Exact Amount
                      </span>
                      <p className="text-sm text-slate-300">
                        Scan with Google Pay, PhonePe, Paytm, or BHIM UPI to pay{' '}
                        <strong className="text-emerald-400 font-mono text-base">
                          ₹{card.priceInr.toFixed(2)}
                        </strong>
                        .
                      </p>

                      <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2 pt-1">
                        <div className="px-3 py-1.5 rounded-lg bg-slate-950 border border-white/[0.08] font-mono text-sm text-purple-300 font-bold">
                          nehapatel20@fam
                        </div>
                        <button
                          type="button"
                          onClick={() => handleCopy('nehapatel20@fam', 'upi')}
                          className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold flex items-center gap-1.5 transition-colors"
                        >
                          {copiedField === 'upi' ? (
                            <Check className="w-4 h-4 text-emerald-400" />
                          ) : (
                            <Copy className="w-4 h-4" />
                          )}
                          <span>Copy UPI</span>
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Additional Payment Options (Direct UPI, Amazon, Flipkart) */}
                  <div className="pt-4 border-t border-white/[0.05]">
                    <h4 className="text-[11px] font-bold text-slate-400 mb-3 uppercase tracking-wider flex items-center justify-center sm:justify-start gap-1.5">
                      <Zap className="w-3.5 h-3.5" />
                      More Payment Options
                    </h4>
                    <div className="grid grid-cols-3 gap-2 sm:gap-3">
                      {/* 1. Direct UPI */}
                      <a
                        href={`upi://pay?pa=nehapatel20@fam&pn=OfficialCCShop&am=${card.priceInr}&cu=INR&tn=OfficialCCShop%20Card%20Purchase`}
                        className="p-2 sm:p-2.5 rounded-xl bg-slate-950 border border-white/[0.08] hover:border-emerald-500/30 transition-all duration-200 hover:scale-[1.02] active:scale-95 flex flex-col items-center justify-center text-center gap-2 group cursor-pointer"
                      >
                         <div className="w-9 h-9 rounded-full bg-white border border-white/[0.05] shadow-inner flex items-center justify-center group-hover:scale-110 transition-transform overflow-hidden p-1">
                            <img src="/assets/upi.svg" alt="UPI" className="w-6 h-6 object-contain" />
                         </div>
                         <span className="font-bold text-[9px] sm:text-[10px] text-slate-300 group-hover:text-white transition-colors leading-tight">Direct UPI</span>
                      </a>

                      {/* 2. Amazon */}
                      <button
                        type="button"
                        onClick={() => setPayMode('amazon')}
                        className="p-2 sm:p-2.5 rounded-xl bg-slate-950 border border-white/[0.08] hover:border-orange-500/30 transition-all duration-200 hover:scale-[1.02] active:scale-95 flex flex-col items-center justify-center text-center gap-2 group cursor-pointer"
                      >
                         <div className="w-9 h-9 rounded-full bg-white border border-white/[0.05] shadow-inner flex items-center justify-center group-hover:scale-110 transition-transform overflow-hidden p-1">
                            <img src="/assets/amazon.svg" alt="Amazon" className="w-5 h-5 object-contain" />
                         </div>
                         <span className="font-bold text-[9px] sm:text-[10px] text-slate-300 group-hover:text-white transition-colors leading-tight">Amazon Voucher</span>
                      </button>

                      {/* 3. Flipkart */}
                      <button
                        type="button"
                        onClick={() => setPayMode('flipkart')}
                        className="p-2 sm:p-2.5 rounded-xl bg-slate-950 border border-white/[0.08] hover:border-blue-500/30 transition-all duration-200 hover:scale-[1.02] active:scale-95 flex flex-col items-center justify-center text-center gap-2 group cursor-pointer"
                      >
                         <div className="w-9 h-9 rounded-full bg-white border border-white/[0.05] shadow-inner flex items-center justify-center group-hover:scale-110 transition-transform overflow-hidden p-1">
                            <img src="/assets/flipkart.png" alt="Flipkart" className="w-5 h-5 object-contain rounded-md" />
                         </div>
                         <span className="font-bold text-[9px] sm:text-[10px] text-slate-300 group-hover:text-white transition-colors leading-tight">Flipkart Voucher</span>
                      </button>
                    </div>
                  </div>
                </div>

                {/* 12-Digit UTR Input */}
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                    12-Digit UTR Reference Number <span className="text-rose-400">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={utrNumber}
                    onChange={(e) => setUtrNumber(e.target.value.replace(/\s+/g, ''))}
                    placeholder="Enter 12-digit UTR (e.g. 402918239012)"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-white/[0.08] text-xs font-mono font-bold text-white placeholder-slate-500 focus:outline-none focus:border-purple-500/50"
                  />
                  <span className="text-[10px] text-slate-400 mt-1 block">
                    Found in payment success details of your UPI app. Admin matches this UTR with bank statement.
                  </span>
                </div>

                {/* Screenshot Upload Input */}
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                    Payment Screenshot / Receipt <span className="text-slate-400">(Recommended)</span>
                  </label>
                  <div className="flex items-center gap-3">
                    <label className="flex-1 cursor-pointer flex items-center justify-center gap-2 px-3.5 py-2.5 rounded-xl border border-dashed border-white/[0.15] hover:border-purple-500/50 bg-slate-950 hover:bg-slate-900 transition-all text-xs text-slate-400">
                      <Upload className="w-4 h-4 text-purple-400" />
                      <span>{isUploadingProof ? 'Uploading Screenshot...' : proofUrl ? 'Change Screenshot' : 'Upload Payment Screenshot'}</span>
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handleFileUpload}
                        className="hidden"
                      />
                    </label>

                    {proofUrl && (
                      <div className="relative w-12 h-10 rounded-lg overflow-hidden border border-emerald-500/40 shrink-0 bg-slate-950">
                        <img src={proofUrl} alt="Receipt thumbnail" className="w-full h-full object-cover" />
                        <span className="absolute bottom-0 right-0 p-0.5 bg-emerald-500 text-slate-950">
                          <Check className="w-2.5 h-2.5" />
                        </span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Purchase Error */}
                {purchaseError && (
                  <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 shrink-0" />
                    <span>{purchaseError}</span>
                  </div>
                )}

                {/* Submit Order Button */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                  <button
                    type="button"
                    onClick={onClose}
                    className="py-3 px-4 rounded-2xl bg-slate-800/80 hover:bg-slate-700 text-slate-300 font-semibold text-sm transition"
                  >
                    Cancel
                  </button>

                  <button
                    type="submit"
                    disabled={isSubmittingUtr || isUploadingProof}
                    className="py-3 px-6 rounded-2xl bg-gradient-to-r from-purple-600 via-fuchsia-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 text-white font-bold text-sm transition-all shadow-lg shadow-purple-600/30 flex items-center justify-center gap-2 active:scale-95 disabled:opacity-50"
                  >
                    {isSubmittingUtr ? (
                      <>
                        <span className="w-4 h-4 border-2 border-white/20 border-t-white rounded-full animate-spin" />
                        <span>Submitting Order...</span>
                      </>
                    ) : (
                      <>
                        <Zap className="w-4 h-4 fill-current" />
                        <span>Submit UTR & Buy Card</span>
                      </>
                    )}
                  </button>
                </div>
              </form>
            )}

            {/* MODES 3 & 4: Pay with Amazon / Flipkart Gift Voucher */}
            {(payMode === 'amazon' || payMode === 'flipkart') && (
              <form onSubmit={(e) => handleSubmitVoucherOrder(e, payMode === 'amazon' ? 'Amazon' : 'Flipkart')} className="space-y-4">
                <div className={`p-4 rounded-2xl bg-slate-900 border ${payMode === 'amazon' ? 'border-orange-500/20' : 'border-blue-500/20'} space-y-4`}>
                  <div className="flex items-center gap-3">
                    {payMode === 'amazon' ? (
                      <div className="w-10 h-10 rounded-xl bg-orange-500 flex items-center justify-center text-black font-black text-xl shadow-lg shadow-orange-500/20">a</div>
                    ) : (
                      <div className="w-10 h-10 rounded-xl bg-blue-500 flex items-center justify-center text-yellow-300 font-black text-xl shadow-lg shadow-blue-500/20">f</div>
                    )}
                    <div>
                      <h4 className={`font-bold ${payMode === 'amazon' ? 'text-orange-400' : 'text-blue-400'} text-sm`}>
                        {payMode === 'amazon' ? 'Amazon Gift Card' : 'Flipkart Gift Voucher'}
                      </h4>
                      <p className="text-xs text-slate-400">
                        Provide a valid voucher equivalent to ₹{card.priceInr.toFixed(2)}
                      </p>
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                      16-Digit Voucher Code <span className="text-rose-400">*</span>
                    </label>
                    <input
                      type="text"
                      required
                      value={voucherCode}
                      onChange={(e) => setVoucherCode(e.target.value.replace(/\s+/g, ''))}
                      placeholder={`Enter ${payMode === 'amazon' ? 'Amazon' : 'Flipkart'} voucher code`}
                      className={`w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-white/[0.08] text-xs font-mono font-bold text-white placeholder-slate-500 focus:outline-none ${payMode === 'amazon' ? 'focus:border-orange-500/50' : 'focus:border-blue-500/50'}`}
                    />
                  </div>

                  {payMode === 'flipkart' && (
                    <div>
                      <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                        6-Digit Voucher PIN <span className="text-rose-400">*</span>
                      </label>
                      <input
                        type="text"
                        required
                        value={voucherPin}
                        onChange={(e) => setVoucherPin(e.target.value.replace(/\s+/g, ''))}
                        placeholder="Enter 6-digit PIN"
                        className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-white/[0.08] text-xs font-mono font-bold text-white placeholder-slate-500 focus:outline-none focus:border-blue-500/50"
                      />
                    </div>
                  )}
                  
                  <span className="text-[10px] text-slate-400 block">
                    Admin will verify this code manually before issuing the card.
                  </span>
                </div>

                {/* Purchase Error */}
                {purchaseError && (
                  <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 shrink-0" />
                    <span>{purchaseError}</span>
                  </div>
                )}

                {/* Submit Order Button */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                  <button
                    type="button"
                    onClick={() => setPayMode('upi')}
                    className="py-3 px-4 rounded-2xl bg-slate-800/80 hover:bg-slate-700 text-slate-300 font-semibold text-sm transition"
                  >
                    Go Back
                  </button>

                  <button
                    type="submit"
                    disabled={isSubmittingUtr}
                    className={`py-3 px-6 rounded-2xl ${payMode === 'amazon' ? 'bg-orange-500 hover:bg-orange-400 text-black' : 'bg-blue-600 hover:bg-blue-500 text-white'} font-bold text-sm transition-all shadow-lg flex items-center justify-center gap-2 active:scale-95 disabled:opacity-50`}
                  >
                    {isSubmittingUtr ? (
                      <>
                        <span className={`w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin`} />
                        <span>Verifying...</span>
                      </>
                    ) : (
                      <>
                        <Zap className="w-4 h-4 fill-current" />
                        <span>Submit Voucher</span>
                      </>
                    )}
                  </button>
                </div>
              </form>
            )}

            {/* MODE 2: Pay with Wallet Balance */}
            {payMode === 'wallet' && (
              <div className="space-y-4">
                <div className="p-3.5 rounded-2xl bg-white/[0.03] border border-white/[0.06] text-xs flex items-center justify-between">
                  <span className="text-slate-400">Available Wallet Balance:</span>
                  <span className="font-mono font-bold text-white">
                    ₹{userBalance.toLocaleString('en-IN', { minimumFractionDigits: 2 })} INR
                  </span>
                </div>

                {!hasEnoughBalance && (
                  <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-200 text-xs space-y-2">
                    <div className="flex items-center gap-2 font-bold text-amber-300">
                      <AlertCircle className="w-4 h-4 shrink-0" />
                      <span>Insufficient Wallet Balance</span>
                    </div>
                    <p className="text-slate-300 text-xs leading-relaxed">
                      You have ₹{userBalance.toFixed(2)} in your wallet. Switch to{' '}
                      <strong className="text-purple-300">Pay via UPI & Submit UTR</strong> above
                      to pay directly with QR and submit your UTR reference, or deposit ₹1,000.
                    </p>
                    <button
                      type="button"
                      onClick={() => setPayMode('upi')}
                      className="w-full py-2 px-3 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs transition"
                    >
                      Switch to QR Payment
                    </button>
                  </div>
                )}

                {purchaseError && (
                  <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 shrink-0" />
                    <span>{purchaseError}</span>
                  </div>
                )}

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                  <button
                    type="button"
                    onClick={onClose}
                    className="py-3 px-4 rounded-2xl bg-slate-800/80 hover:bg-slate-700 text-slate-300 font-semibold text-sm transition"
                  >
                    Cancel
                  </button>

                  <button
                    type="button"
                    onClick={handleConfirmPurchase}
                    disabled={!hasEnoughBalance || isPurchasing}
                    className={`py-3 px-6 rounded-2xl ${badge.btnGradient} text-white font-bold text-sm transition-all shadow-lg flex items-center justify-center gap-2 active:scale-95 ${
                      !hasEnoughBalance || isPurchasing ? 'opacity-50 cursor-not-allowed' : ''
                    }`}
                  >
                    {isPurchasing ? (
                      <>
                        <span className="w-4 h-4 border-2 border-white/20 border-t-white rounded-full animate-spin" />
                        <span>Processing Purchase...</span>
                      </>
                    ) : (
                      <>
                        <Zap className="w-4 h-4 fill-current" />
                        <span>Confirm & Buy Card Now</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            )}
          </div>
        ) : (
          <button
            type="button"
            onClick={onClose}
            className="w-full py-3 px-4 rounded-2xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-sm transition-all mt-4"
          >
            Done
          </button>
        )}
      </div>
      )}
    </div>
  );
};
