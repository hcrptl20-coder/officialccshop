import React from 'react';
import { formatINR, formatUSD, USD_EXCHANGE_RATE } from '../../lib/currency.ts';

interface DualCurrencyProps {
  amount: number | string;
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl' | '2xl' | '3xl';
  inrClass?: string;
  usdClass?: string;
  layout?: 'horizontal' | 'vertical' | 'badge';
  showRate?: boolean;
  prefixSign?: '+' | '-' | '';
}

export const DualCurrency: React.FC<DualCurrencyProps> = ({
  amount,
  size = 'md',
  inrClass = '',
  usdClass = '',
  layout = 'horizontal',
  showRate = false,
  prefixSign = '',
}) => {
  const numAmount = Math.abs(Number(amount) || 0);
  const signStr = prefixSign ? prefixSign : Number(amount) < 0 ? '-' : '';

  const inrStr = `${signStr}${formatINR(numAmount, 2)}`;
  const usdStr = `${signStr}${formatUSD(numAmount, 2)}`;

  if (layout === 'badge') {
    return (
      <div className="inline-flex items-center gap-1.5 flex-wrap">
        <span className={`font-mono font-bold text-white ${inrClass}`}>
          {inrStr}
        </span>
        <span className="px-1.5 py-0.5 rounded-md text-[10px] font-mono font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
          ≈ {usdStr} USD
        </span>
      </div>
    );
  }

  if (layout === 'vertical') {
    return (
      <div className="flex flex-col">
        <span className={`font-mono font-bold text-white tracking-tight ${inrClass}`}>
          {inrStr}
        </span>
        <span className={`font-mono text-xs text-slate-400 mt-0.5 ${usdClass}`}>
          ≈ {usdStr} USD
          {showRate && (
            <span className="text-[10px] text-slate-500 ml-1">
              (1 USD = ₹{USD_EXCHANGE_RATE})
            </span>
          )}
        </span>
      </div>
    );
  }

  // default horizontal
  return (
    <span className="inline-flex items-baseline gap-1.5 flex-wrap font-mono">
      <span className={`font-bold text-white ${inrClass}`}>
        {inrStr}
      </span>
      <span className={`text-xs text-emerald-400/90 font-medium ${usdClass}`}>
        ({usdStr})
      </span>
    </span>
  );
};
