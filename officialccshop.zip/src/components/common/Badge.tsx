import React from 'react';

interface BadgeProps {
  status: string;
  size?: 'sm' | 'md';
}

export const Badge: React.FC<BadgeProps> = ({ status, size = 'md' }) => {
  const normalized = status.toUpperCase();

  let styles = 'bg-slate-800/80 text-slate-300 border-slate-700/60';
  let dotColor = 'bg-slate-400';

  if (normalized === 'APPROVED' || normalized === 'COMPLETED' || normalized === 'ACTIVE' || normalized === 'RESOLVED') {
    styles = 'bg-emerald-950/40 text-emerald-400 border-emerald-500/30';
    dotColor = 'bg-emerald-400';
  } else if (normalized === 'PENDING' || normalized === 'OPEN') {
    styles = 'bg-amber-950/40 text-amber-400 border-amber-500/30';
    dotColor = 'bg-amber-400 animate-pulse';
  } else if (normalized === 'REJECTED' || normalized === 'SUSPENDED' || normalized === 'FROZEN') {
    styles = 'bg-rose-950/40 text-rose-400 border-rose-500/30';
    dotColor = 'bg-rose-400';
  }

  const sizeStyles = size === 'sm' ? 'px-2 py-0.5 text-xs' : 'px-2.5 py-1 text-xs';

  return (
    <span
      className={`inline-flex items-center gap-1.5 font-medium rounded-full border backdrop-blur-md whitespace-nowrap ${sizeStyles} ${styles}`}
    >
      <span className={`w-1.5 h-1.5 rounded-full ${dotColor}`} />
      <span>{status}</span>
    </span>
  );
};
