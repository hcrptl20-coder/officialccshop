import React from 'react';

interface BrandCardLogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
  animate?: boolean;
}

export const BrandCardLogo: React.FC<BrandCardLogoProps> = ({
  size = 'md',
  className = '',
  animate = false,
}) => {
  // Dimensions for realistic card aspect ratio (approx 1.58:1)
  const dimensions = {
    sm: { width: 32, height: 21, radius: 4, chipW: 6, chipH: 4.5, font: 'text-[5px]' },
    md: { width: 40, height: 26, radius: 5, chipW: 8, chipH: 6, font: 'text-[7px]' },
    lg: { width: 56, height: 36, radius: 7, chipW: 11, chipH: 8, font: 'text-[9px]' },
    xl: { width: 72, height: 46, radius: 9, chipW: 14, chipH: 10, font: 'text-[11px]' },
  };

  const dim = dimensions[size];

  return (
    <div
      className={`relative select-none flex-shrink-0 group/cardlogo ${animate ? 'animate-pulse' : ''} ${className}`}
      style={{ width: `${dim.width}px`, height: `${dim.height}px` }}
      aria-label="OfficialCCShop Card Logo"
    >
      {/* Outer Card Shell with Gradient & Soft Glow */}
      <div
        className="w-full h-full relative overflow-hidden bg-gradient-to-br from-slate-900 via-slate-950 to-emerald-950 border border-emerald-500/40 shadow-md shadow-emerald-950/50 flex flex-col justify-between p-1 transition-transform group-hover/cardlogo:scale-105"
        style={{ borderRadius: `${dim.radius}px` }}
      >
        {/* Subtle Metallic Card Sheen */}
        <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/[0.07] to-emerald-400/[0.12] pointer-events-none" />

        {/* Card Top Row: Gold EMV Chip & Contactless Waves */}
        <div className="flex items-center justify-between relative z-10">
          {/* Gold EMV Microchip */}
          <div
            className="bg-gradient-to-br from-amber-300 via-amber-400 to-amber-600 rounded-[2px] border border-amber-300/80 shadow-[0_0_4px_rgba(245,158,11,0.5)] flex items-center justify-center"
            style={{ width: `${dim.chipW}px`, height: `${dim.chipH}px` }}
          >
            <div className="w-full h-[0.5px] bg-amber-800/40" />
          </div>

          {/* Contactless NFC Waves */}
          <svg
            className="text-emerald-400/90"
            style={{ width: `${dim.chipW}px`, height: `${dim.chipH}px` }}
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2.5"
            strokeLinecap="round"
          >
            <path d="M7 16a6 6 0 0 1 0-8" />
            <path d="M11 19a10 10 0 0 1 0-14" />
            <path d="M15 22a14 14 0 0 1 0-20" />
          </svg>
        </div>

        {/* Card Bottom Row: CC Brand & Interlocking Security Discs */}
        <div className="flex items-end justify-between relative z-10 leading-none">
          <span className={`font-mono font-black tracking-wider text-emerald-300 ${dim.font}`}>
            CC
          </span>
          <div className="flex -space-x-1 items-center">
            <div
              className="rounded-full bg-emerald-400/80"
              style={{ width: `${dim.chipH * 0.9}px`, height: `${dim.chipH * 0.9}px` }}
            />
            <div
              className="rounded-full bg-teal-300/80"
              style={{ width: `${dim.chipH * 0.9}px`, height: `${dim.chipH * 0.9}px` }}
            />
          </div>
        </div>
      </div>
    </div>
  );
};
