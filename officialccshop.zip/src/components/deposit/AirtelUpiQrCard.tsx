import React from 'react';
import { Download, ShieldCheck, QrCode, Zap } from 'lucide-react';
import { formatUSD } from '../../lib/currency.ts';

interface AirtelUpiQrCardProps {
  amount?: number | string;
  merchantName?: string;
  qrDataUrl?: string;
  onDownload?: () => void;
}

export const AirtelUpiQrCard: React.FC<AirtelUpiQrCardProps> = ({
  amount,
  merchantName = 'Official CC Shop',
  qrDataUrl,
  onDownload,
}) => {
  const numAmount = Number(amount) || 0;

  const handleDownloadQr = () => {
    if (onDownload) {
      onDownload();
      return;
    }
    if (qrDataUrl) {
      const a = document.createElement('a');
      a.href = qrDataUrl;
      a.download = `OfficialCCShop-Payment-QR${numAmount > 0 ? `-Rs${numAmount}` : ''}.png`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    }
  };

  return (
    <div className="w-full max-w-sm mx-auto rounded-3xl bg-[#0d0f12] border border-white/[0.12] p-5 shadow-2xl text-white flex flex-col items-center select-none relative overflow-hidden">
      {/* Background glow accent */}
      <div className="absolute top-0 inset-x-0 h-28 bg-gradient-to-b from-emerald-600/10 via-teal-600/5 to-transparent pointer-events-none" />

      {/* Top Bank Header */}
      <div className="relative z-10 flex flex-col items-center text-center space-y-2 w-full pt-1">
        {/* Merchant Circular Badge */}
        <div className="w-12 h-12 rounded-full flex items-center justify-center shadow-lg border-2 bg-gradient-to-br from-emerald-500 to-teal-600 border-emerald-400/40">
          <QrCode className="w-6 h-6 text-white" />
        </div>

        {/* Bank & Account info */}
        <div>
          <h3 className="text-base font-bold text-white tracking-tight">
            Official QR Scanner
          </h3>
          <p className="text-xs text-slate-400 mt-0.5 font-medium">
            Scan & Pay directly via any UPI App
          </p>
        </div>

        {/* Amount Chip if entered */}
        {numAmount > 0 && (
          <div className="px-3.5 py-1 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 text-xs font-bold font-mono-numbers animate-in fade-in flex items-center gap-1.5 flex-wrap justify-center">
            <span>Amount: ₹{numAmount.toLocaleString('en-IN')}</span>
            <span className="text-[10px] text-emerald-300/80 bg-emerald-500/20 px-1.5 py-0.5 rounded">
              ≈ {formatUSD(numAmount)} USD
            </span>
          </div>
        )}
      </div>

      {/* QR Code Container */}
      <div className="relative z-10 my-4 w-64 h-64 p-3.5 rounded-2xl bg-white shadow-2xl flex items-center justify-center">
        {qrDataUrl ? (
          <img
            src={qrDataUrl}
            alt="Official UPI QR Code"
            className="w-full h-full object-contain rounded-lg"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-slate-800 text-xs font-medium animate-pulse">
            Generating Secure QR...
          </div>
        )}
      </div>

      {/* Scan Directive */}
      <div className="relative z-10 flex items-center justify-center gap-2 mt-1 mb-3 px-4 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/25 text-center shadow-inner">
        <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
        <span className="text-xs font-semibold text-emerald-300">
          Scan QR Code on Scanner to Pay
        </span>
      </div>

      {/* Direct UPI App Trigger (Opens PhonePe / GPay / Paytm directly to nehapatel20@fam) */}
      <a
        href={`upi://pay?pa=nehapatel20@fam&pn=${encodeURIComponent(merchantName)}&am=${numAmount > 0 ? numAmount : 1000}&cu=INR&tn=OfficialCCShop%20Deposit`}
        className="relative z-10 w-full mb-2.5 py-2.5 px-4 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-xs font-bold text-white flex items-center justify-center gap-2 transition-all shadow-lg shadow-emerald-950/40 active:scale-[0.98]"
      >
        <Zap className="w-4 h-4 text-amber-300" />
        <span>Pay Directly via UPI App</span>
      </a>

      {/* Download QR Code Button (Allows mobile users to scan from gallery) */}
      <button
        type="button"
        onClick={handleDownloadQr}
        className="relative z-10 w-full mb-4 py-2.5 px-4 rounded-xl bg-slate-900 hover:bg-slate-800 border border-white/10 hover:border-emerald-500/30 text-xs font-bold text-slate-200 flex items-center justify-center gap-2 transition-all shadow-md active:scale-[0.98]"
      >
        <Download className="w-4 h-4 text-emerald-400" />
        <span>Download QR to Scan from Gallery</span>
      </button>

      {/* Bottom Footer: Supported Apps & UPI branding */}
      <div className="relative z-10 w-full border-t border-white/[0.08] pt-3 flex flex-col items-center text-center space-y-2">
        <span className="text-[11px] text-slate-400 font-medium">Supported on all UPI apps</span>

        {/* UPI Provider badges */}
        <div className="flex items-center justify-center gap-3 text-[11px] font-bold text-slate-300">
          <span className="text-[#5f259f] bg-white px-1.5 py-0.5 rounded text-[10px] font-black">
            पे PhonePe
          </span>
          <span className="text-sky-400 bg-sky-950/60 px-1.5 py-0.5 rounded border border-sky-500/20 text-[10px]">
            BHIM
          </span>
          <span className="text-white bg-slate-800 px-1.5 py-0.5 rounded border border-white/10 text-[10px]">
            GPay
          </span>
          <span className="text-cyan-400 bg-cyan-950/60 px-1.5 py-0.5 rounded border border-cyan-500/20 text-[10px]">
            Paytm
          </span>
        </div>

        <div className="flex items-center gap-1 text-[10px] text-slate-500 font-semibold uppercase tracking-wider pt-1">
          <ShieldCheck className="w-3 h-3 text-emerald-400" />
          <span>Powered by UPI (NPCI)</span>
        </div>
      </div>
    </div>
  );
};
