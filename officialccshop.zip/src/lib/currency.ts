// Central Currency Utility: INR (₹) and USD ($) Dual Currency Conversion
// Exchange rate: 1 USD = 94.49 INR as specified by user
export const USD_EXCHANGE_RATE = 94.49;

/**
 * Converts INR to USD using the fixed exchange rate (₹94.49 = $1.00 USD)
 */
export function inrToUsd(inr: number | string): number {
  const num = Number(inr);
  if (!num || isNaN(num)) return 0;
  return num / USD_EXCHANGE_RATE;
}

/**
 * Formats an amount in INR with Indian comma groupings (e.g. ₹1,000.00)
 */
export function formatINR(amount: number | string, fractionDigits: number = 2): string {
  const num = Number(amount) || 0;
  return `₹${num.toLocaleString('en-IN', {
    minimumFractionDigits: fractionDigits,
    maximumFractionDigits: fractionDigits,
  })}`;
}

/**
 * Formats an amount in USD converted from INR (e.g. $10.58)
 */
export function formatUSD(amountInINR: number | string, fractionDigits: number = 2): string {
  const usd = inrToUsd(amountInINR);
  return `$${usd.toLocaleString('en-US', {
    minimumFractionDigits: fractionDigits,
    maximumFractionDigits: fractionDigits,
  })}`;
}

/**
 * Returns formatted dual currency representation
 * Example: { inr: "₹1,000.00", usd: "$10.58", combined: "₹1,000.00 ($10.58 USD)" }
 */
export function formatDualCurrency(
  amountInINR: number | string,
  options?: { inrDecimals?: number; usdDecimals?: number; withUnit?: boolean }
): { inr: string; usd: string; combined: string } {
  const inrDecimals = options?.inrDecimals ?? 2;
  const usdDecimals = options?.usdDecimals ?? 2;
  const withUnit = options?.withUnit ?? true;

  const inrStr = formatINR(amountInINR, inrDecimals);
  const usdStr = formatUSD(amountInINR, usdDecimals);

  return {
    inr: inrStr,
    usd: usdStr,
    combined: `${inrStr} (${usdStr}${withUnit ? ' USD' : ''})`,
  };
}
