// Client API helper with automatic CSRF management and JSON handling

let cachedCsrfToken: string | null = null;

export async function fetchCsrfToken(): Promise<string> {
  if (cachedCsrfToken) return cachedCsrfToken;
  try {
    const res = await fetch('/api/csrf-token');
    if (res.ok) {
      const data = await res.json();
      cachedCsrfToken = data.csrfToken;
      return cachedCsrfToken || '';
    }
  } catch (err) {
    console.error('Failed to get CSRF token', err);
  }
  return '';
}

export async function apiRequest<T = any>(
  endpoint: string,
  options: RequestInit = {}
): Promise<{ ok: boolean; status: number; data?: T; error?: string }> {
  const headers = new Headers(options.headers || {});
  
  if (!headers.has('Content-Type') && !(options.body instanceof FormData)) {
    headers.set('Content-Type', 'application/json');
  }

  // Attach token from localStorage if available (ensures session works seamlessly in iframes)
  const token = typeof window !== 'undefined' ? localStorage.getItem('zenith_auth_token') : null;
  if (token && !headers.has('Authorization')) {
    headers.set('Authorization', `Bearer ${token}`);
  }

  // Attach CSRF token for state-mutating requests
  if (options.method && !['GET', 'HEAD', 'OPTIONS'].includes(options.method.toUpperCase())) {
    const csrf = await fetchCsrfToken();
    if (csrf) {
      headers.set('x-csrf-token', csrf);
    }
  }

  try {
    const res = await fetch(endpoint, {
      ...options,
      headers,
      credentials: 'same-origin',
    });

    const contentType = res.headers.get('content-type') || '';
    let responseData: any = null;
    if (contentType.includes('application/json')) {
      responseData = await res.json();
    } else {
      responseData = await res.text();
    }

    // If token returned in response, save it to maintain cross-view authentication
    if (responseData && typeof responseData === 'object' && responseData.token) {
      if (typeof window !== 'undefined') {
        localStorage.setItem('zenith_auth_token', responseData.token);
      }
    }

    if (!res.ok) {
      const errorMsg =
        (typeof responseData === 'object' && responseData?.error) ||
        (typeof responseData === 'string' && responseData) ||
        `Request failed with status ${res.status}`;
      return { ok: false, status: res.status, error: errorMsg };
    }

    return { ok: true, status: res.status, data: responseData };
  } catch (err: any) {
    return { ok: false, status: 0, error: err.message || 'Network error' };
  }
}
