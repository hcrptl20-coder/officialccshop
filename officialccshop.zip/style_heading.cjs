const fs = require('fs');

let content = fs.readFileSync('src/pages/user/CardsPage.tsx', 'utf8');

const target = `          <div className="flex items-center gap-3">
            <h1 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
              Cards
            </h1>
            <div className="relative group cursor-default">
              <div className="absolute -inset-0.5 bg-gradient-to-r from-pink-600 via-purple-600 to-cyan-600 rounded-full blur opacity-75 group-hover:opacity-100 transition duration-1000 group-hover:duration-200 animate-pulse"></div>
              <span className="relative px-3.5 py-1 rounded-full text-xs font-black uppercase bg-slate-950 flex items-center gap-1.5 text-transparent bg-clip-text bg-gradient-to-r from-pink-400 via-fuchsia-400 to-cyan-400 border border-white/10 shadow-[inset_0_0_10px_rgba(255,255,255,0.05)]">
                <Sparkles className="w-3.5 h-3.5 text-fuchsia-400" />
                1000+ Virtual Premium Cards
              </span>
            </div>
          </div>
          <p className="text-sm text-slate-400 mt-1 max-w-2xl leading-relaxed">
            <span className="inline-block bg-gradient-to-r from-cyan-400 via-purple-400 to-pink-400 bg-clip-text text-transparent font-extrabold animate-gradient-x text-base tracking-wide drop-shadow-sm">All Premium and Virtual Cards</span>
          </p>`;

const replacement = `          <div className="flex flex-col sm:flex-row sm:items-end gap-5">
            <div className="relative group cursor-default">
              <div className="absolute -inset-2 bg-gradient-to-r from-cyan-600 via-fuchsia-600 to-pink-600 rounded-2xl blur-xl opacity-70 group-hover:opacity-100 transition duration-1000 animate-pulse"></div>
              <h1 className="relative text-5xl sm:text-6xl font-black uppercase tracking-tighter text-transparent bg-clip-text bg-gradient-to-r from-cyan-300 via-fuchsia-300 to-pink-300 drop-shadow-[0_0_20px_rgba(236,72,153,0.9)] flex items-center">
                CARDS
              </h1>
            </div>
            
            <div className="relative group cursor-default mb-2">
              <div className="absolute -inset-0.5 bg-gradient-to-r from-pink-600 via-purple-600 to-cyan-600 rounded-full blur opacity-90 group-hover:opacity-100 transition duration-1000 group-hover:duration-200 animate-pulse"></div>
              <span className="relative px-4 py-1.5 rounded-full text-sm font-black uppercase bg-slate-950 flex items-center gap-2 text-transparent bg-clip-text bg-gradient-to-r from-pink-400 via-fuchsia-400 to-cyan-400 border border-white/20 shadow-[inset_0_0_15px_rgba(255,255,255,0.1)]">
                <Sparkles className="w-4 h-4 text-fuchsia-400" />
                1000+ Virtual Premium Cards
              </span>
            </div>
          </div>
          <p className="text-sm text-slate-400 mt-4 max-w-2xl leading-relaxed relative inline-block">
            <span className="absolute -inset-1 bg-gradient-to-r from-cyan-600 via-purple-600 to-pink-600 blur opacity-40 rounded-lg animate-pulse"></span>
            <span className="relative inline-block bg-gradient-to-r from-cyan-300 via-purple-300 to-pink-300 bg-clip-text text-transparent font-black animate-gradient-x text-lg sm:text-xl tracking-widest drop-shadow-[0_0_10px_rgba(192,132,252,0.8)] uppercase">
              ✦ All Premium and Virtual Cards ✦
            </span>
          </p>`;

content = content.replace(target, replacement);

fs.writeFileSync('src/pages/user/CardsPage.tsx', content);
