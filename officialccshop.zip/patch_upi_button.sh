#!/bin/bash
sed -i 's|<h4 className="text-\[11px\] font-bold text-slate-400 mb-3 uppercase tracking-wider flex items-center justify-center sm:justify-start gap-1.5">|<h4 className="text-[11px] font-bold text-slate-400 mb-3 uppercase tracking-wider flex items-center justify-center sm:justify-start gap-1.5">|g' src/components/cards/CardDetailModal.tsx
sed -i 's|{/\* 1. Direct UPI \*/}|{/* 1. Direct UPI (Expanded) */}|g' src/components/cards/CardDetailModal.tsx

awk '
/\{\/\* 1. Direct UPI \(Expanded\) \*\/\}/ {
    print "                      {/* 1. Direct UPI */}"
    print "                      <a"
    print "                        href={`upi://pay?pa=davidtl@axl&pn=Airtel%20Payments%20Bank&am=${card.priceInr}&cu=INR&tn=OfficialCCShop%20Deposit`}"
    print "                        className=\"col-span-3 mb-2 p-3 sm:p-4 rounded-xl bg-purple-600 hover:bg-purple-500 transition-all duration-200 hover:scale-[1.02] active:scale-95 flex flex-col items-center justify-center text-center gap-3 group cursor-pointer shadow-lg shadow-purple-900/20\""
    print "                      >"
    print "                         <span className=\"font-bold text-sm sm:text-base text-white group-hover:text-white transition-colors leading-tight flex items-center gap-2\">"
    print "                            Open in UPI App (PhonePe / GPay) <ExternalLink className=\"w-4 h-4\" />"
    print "                         </span>"
    print "                      </a>"
    print ""
    print "                      <div className=\"col-span-3 text-center mb-1 mt-1\">"
    print "                         <span className=\"text-xs text-slate-400\">Supported on all UPI apps</span>"
    print "                      </div>"
    print "                      <div className=\"col-span-3 flex justify-center gap-2 mb-3\">"
    print "                         <div className=\"bg-white rounded px-2 py-1 flex items-center justify-center\"><img src=\"https://upload.wikimedia.org/wikipedia/commons/e/e1/UPI-Logo-vector.svg\" className=\"h-4\" alt=\"PhonePe\" /></div>"
    print "                         <div className=\"bg-[#0B3F63] rounded px-2 py-1 flex items-center justify-center text-white text-xs font-bold\">BHIM</div>"
    print "                         <div className=\"bg-slate-800 rounded px-2 py-1 flex items-center justify-center text-white text-xs font-bold\">GPay</div>"
    print "                         <div className=\"bg-[#002E6E] rounded px-2 py-1 flex items-center justify-center text-[#00B9F5] text-xs font-bold\">Paytm</div>"
    print "                      </div>"
    print ""
    print "                      <div className=\"grid grid-cols-2 gap-2 sm:gap-3 col-span-3 pt-2 border-t border-white/[0.05]\">"
    
    # Skip the original Direct UPI block
    getline
    getline
    getline
    getline
    getline
    getline
    getline
    getline
    getline
    next
}
/\{\/\* 2. Amazon \*\/\}/ {
    print "                      </div>"
    print "                      {/* 2. Amazon */}"
    next
}
{ print }
' src/components/cards/CardDetailModal.tsx > patched.tsx
mv patched.tsx src/components/cards/CardDetailModal.tsx
