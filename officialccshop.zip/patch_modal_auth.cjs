const fs = require('fs');
let content = fs.readFileSync('src/components/cards/CardDetailModal.tsx', 'utf8');

const target1 = `    if (!currentUser && !skipAuthCheck) {
      setRequireAuth(true);
      return;
    }`;

content = content.replaceAll(target1, '');

fs.writeFileSync('src/components/cards/CardDetailModal.tsx', content);
