const fs = require('fs');
let content = fs.readFileSync('src/components/layout/Navbar.tsx', 'utf8');

const target = `              <div className="flex items-center gap-2">
                <span className="text-xl font-black tracking-widest uppercase drop-shadow-md flex items-center">
                  <span className="text-transparent bg-clip-text bg-gradient-to-r from-white to-slate-400">OFFICIAL</span>
                  <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-300 via-yellow-400 to-amber-600 drop-shadow-[0_0_8px_rgba(251,191,36,0.4)] mx-0.5">CC</span>
                  <span className="text-transparent bg-clip-text bg-gradient-to-r from-white to-slate-400">SHOP</span>
                </span>
                <span className="px-1.5 py-0.5 rounded text-[8px] font-black tracking-widest uppercase bg-amber-500/10 text-amber-400 border border-amber-500/20 hidden sm:inline-block">
                  PREMIUM
                </span>
              </div>`;

const replacement = `              <div className="flex items-center gap-2 relative group cursor-pointer">
                <div className="absolute -inset-2 bg-gradient-to-r from-cyan-600 via-fuchsia-600 to-pink-600 rounded-lg blur-md opacity-40 group-hover:opacity-100 transition duration-1000 animate-pulse hidden sm:block"></div>
                <span className="relative text-xl font-black tracking-widest uppercase drop-shadow-md flex items-center">
                  <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-300 to-cyan-500">OFFICIAL</span>
                  <span className="text-transparent bg-clip-text bg-gradient-to-r from-fuchsia-300 via-pink-400 to-pink-600 drop-shadow-[0_0_12px_rgba(236,72,153,0.9)] mx-0.5">CC</span>
                  <span className="text-transparent bg-clip-text bg-gradient-to-r from-pink-400 to-rose-400">SHOP</span>
                </span>
                <span className="relative px-2 py-0.5 rounded text-[9px] font-black tracking-widest uppercase bg-slate-950 text-fuchsia-400 border border-fuchsia-500/30 shadow-[inset_0_0_8px_rgba(236,72,153,0.3)] hidden sm:flex items-center gap-1">
                  <Sparkles className="w-2.5 h-2.5 text-pink-400" />
                  PREMIUM
                </span>
              </div>`;

content = content.replace(target, replacement);
fs.writeFileSync('src/components/layout/Navbar.tsx', content);
