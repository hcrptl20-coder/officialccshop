#!/bin/bash
awk '
/qrImagePath:/ {
    print $0
    print "          useStaticQr: false,"
    print "          staticQrUrl: \"\","
    next
}
{ print }
' server/db.ts > db_patched.ts
mv db_patched.ts server/db.ts
