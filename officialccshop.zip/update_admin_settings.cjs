const fs = require('fs');

const file = 'src/pages/admin/AdminSettingsPage.tsx';
let code = fs.readFileSync(file, 'utf8');

const targetUpload = `      const data = await res.json();
      if (res.ok) {
        setUseStaticQr(true);
        setConfig(prev => prev ? { ...prev, staticQrUrl: data.url, useStaticQr: true } : null);
        setMessage('QR Code uploaded and set as default!');
      } else {
        setMessage(data.error || 'Upload failed');
      }`;

const newUpload = `      const data = await res.json();
      if (res.ok) {
        setUseStaticQr(true);
        setConfig(prev => prev ? { ...prev, staticQrUrl: data.url, useStaticQr: true } : null);
        if (data.detectedUpiId) {
          setUpiId(data.detectedUpiId);
        }
        if (data.detectedMerchant) {
          setMerchantName(data.detectedMerchant);
        }
        setMessage(data.message || 'QR Code uploaded and activated!');
      } else {
        setMessage(data.error || 'Upload failed');
      }`;

if (code.includes(targetUpload)) {
  code = code.replace(targetUpload, newUpload);
  fs.writeFileSync(file, code);
  console.log("Updated AdminSettingsPage.tsx successfully!");
} else {
  console.log("Target not found in AdminSettingsPage.tsx");
}
