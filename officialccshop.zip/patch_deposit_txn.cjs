const fs = require('fs');

let content = fs.readFileSync('server/db.ts', 'utf8');

// 1. In createDeposit, change the txn type
const targetCreateTxn = `    const txn: Transaction = {
      id: \`TXN-\${deposit.id}\`,
      userId,
      username: user?.username,
      type: 'Deposit',`;
const replacementCreateTxn = `    const txn: Transaction = {
      id: \`TXN-\${deposit.id}\`,
      userId,
      username: user?.username,
      type: isCardBuy ? 'Virtual Card Payment' : 'Deposit',`;

content = content.replace(targetCreateTxn, replacementCreateTxn);

// 2. Add an admin notification when a card is purchased directly (in purchaseCard)
const targetPurchaseCardNotif = `    // Send Notification
    data.notifications.unshift({
      id: \`notif-\${Date.now()}\`,
      userId,`;
const replacementPurchaseCardNotif = `    // Notify Admins
    const admins = data.users.filter(u => u.role === 'admin');
    admins.forEach(admin => {
      data.notifications.unshift({
        id: \`notif-admin-\${Date.now()}-\${Math.random()}\`,
        userId: admin.id,
        title: \`New Card Purchase\`,
        message: \`User \${user.username} just purchased \${cardItem.name} for ₹\${priceInr.toFixed(2)}.\`,
        type: 'system',
        isRead: false,
        createdAt: new Date().toISOString(),
      });
    });

    // Send Notification
    data.notifications.unshift({
      id: \`notif-\${Date.now()}\`,
      userId,`;

content = content.replace(targetPurchaseCardNotif, replacementPurchaseCardNotif);

// 3. Add an admin notification when a deposit is made (in createDeposit)
const targetDepositNotif = `    // Notify user
    data.notifications.unshift({
      id: \`notif-\${Date.now()}\`,
      userId,`;
const replacementDepositNotif = `    // Notify Admins
    const admins = data.users.filter(u => u.role === 'admin');
    admins.forEach(admin => {
      data.notifications.unshift({
        id: \`notif-admin-\${Date.now()}-\${Math.random()}\`,
        userId: admin.id,
        title: isCardBuy ? \`New Card Purchase (Pending)\` : \`New Deposit Request\`,
        message: \`User \${user?.username} submitted a \${isCardBuy ? 'card purchase' : 'deposit'} for ₹\${amount.toFixed(2)} via \${referenceNo}.\`,
        type: 'system',
        isRead: false,
        createdAt: new Date().toISOString(),
      });
    });

    // Notify user
    data.notifications.unshift({
      id: \`notif-\${Date.now()}\`,
      userId,`;

content = content.replace(targetDepositNotif, replacementDepositNotif);

fs.writeFileSync('server/db.ts', content);
