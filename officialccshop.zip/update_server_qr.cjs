const fs = require('fs');

let serverCode = fs.readFileSync('server.ts', 'utf8');

// Check if pngjs and jsqr and jpeg-js are imported
if (!serverCode.includes("import { PNG } from 'pngjs';")) {
  serverCode = `import { PNG } from 'pngjs';\nimport jsQR from 'jsqr';\nimport jpeg from 'jpeg-js';\n` + serverCode;
}

const oldUploadHandler = `app.post("/api/settings/upload-qr", upload.single("qrImage"), (req, res) => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith("Bearer ")) return res.status(401).json({ error: "Unauthorized" });
  const token = authHeader.split(" ")[1];
  const session = db.findSession(token);
  const user = session ? db.findUserById(session.userId) : null;
  if (!user || user.role !== "admin") return res.status(403).json({ error: "Forbidden" });
  if (!req.file) return res.status(400).json({error: "no file"});
  const url = \`/uploads/\${req.file.filename}\`;
  db.updatePaymentConfig({ staticQrUrl: url, useStaticQr: true });
  res.json({ url });
});`;

const newUploadHandler = `app.post("/api/settings/upload-qr", upload.single("qrImage"), (req, res) => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith("Bearer ")) return res.status(401).json({ error: "Unauthorized" });
  const token = authHeader.split(" ")[1];
  const session = db.findSession(token);
  const user = session ? db.findUserById(session.userId) : null;
  if (!user || user.role !== "admin") return res.status(403).json({ error: "Forbidden" });
  if (!req.file) return res.status(400).json({ error: "no file" });

  const filePath = req.file.path;
  const filename = req.file.filename;
  const url = \`/uploads/\${filename}\`;

  // Synchronize to public directory so static references always work
  try {
    const publicPath = path.join(process.cwd(), 'public', 'merchant-qr.png');
    fs.copyFileSync(filePath, publicPath);
    const publicQrPath = path.join(process.cwd(), 'public', 'qr.png');
    fs.copyFileSync(filePath, publicQrPath);
  } catch (copyErr) {
    console.warn("Could not copy uploaded QR to public directory:", copyErr);
  }

  // Attempt automatic decode of QR code to extract UPI ID and merchant name
  let detectedUpiId: string | null = null;
  let detectedMerchant: string | null = null;
  let rawQrText: string | null = null;

  try {
    const fileBuf = fs.readFileSync(filePath);
    let rgbaData: Uint8ClampedArray | null = null;
    let width = 0;
    let height = 0;

    const lowerName = req.file.originalname.toLowerCase();
    if (lowerName.endsWith('.png') || req.file.mimetype.includes('png')) {
      const png = PNG.sync.read(fileBuf);
      rgbaData = new Uint8ClampedArray(png.data);
      width = png.width;
      height = png.height;
    } else if (lowerName.endsWith('.jpg') || lowerName.endsWith('.jpeg') || req.file.mimetype.includes('jpeg')) {
      const decodedJpg = jpeg.decode(fileBuf);
      rgbaData = new Uint8ClampedArray(decodedJpg.data);
      width = decodedJpg.width;
      height = decodedJpg.height;
    }

    if (rgbaData && width > 0 && height > 0) {
      const qrResult = jsQR(rgbaData, width, height);
      if (qrResult && qrResult.data) {
        rawQrText = qrResult.data;
        if (rawQrText.startsWith('upi://pay?')) {
          try {
            const urlObj = new URL(rawQrText);
            detectedUpiId = urlObj.searchParams.get('pa') || null;
            detectedMerchant = urlObj.searchParams.get('pn') ? decodeURIComponent(urlObj.searchParams.get('pn')!) : null;
          } catch {
            const paMatch = rawQrText.match(/[?&]pa=([^&]+)/);
            if (paMatch) detectedUpiId = decodeURIComponent(paMatch[1]);
            const pnMatch = rawQrText.match(/[?&]pn=([^&]+)/);
            if (pnMatch) detectedMerchant = decodeURIComponent(pnMatch[1]);
          }
        }
      }
    }
  } catch (decodeErr) {
    console.warn("Could not auto-decode QR image:", decodeErr);
  }

  const updates: any = {
    staticQrUrl: url,
    qrImagePath: url,
    useStaticQr: true,
  };

  if (detectedUpiId) {
    updates.upiId = detectedUpiId;
    updates.displayUpiId = detectedUpiId;
  }
  if (detectedMerchant) {
    updates.merchantName = detectedMerchant;
  }

  db.updatePaymentConfig(updates);
  res.json({
    url,
    detectedUpiId,
    detectedMerchant,
    rawQrText,
    message: detectedUpiId
      ? \`QR uploaded and UPI ID (\${detectedUpiId}) automatically configured!\`
      : 'QR uploaded and activated successfully!'
  });
});`;

if (serverCode.includes(oldUploadHandler)) {
  serverCode = serverCode.replace(oldUploadHandler, newUploadHandler);
  fs.writeFileSync('server.ts', serverCode);
  console.log("Updated server.ts /api/settings/upload-qr successfully!");
} else {
  console.log("Old handler not found, will search for partial match");
}
