const fs = require('fs');
let content = fs.readFileSync('src/components/cards/VirtualCardVisual.tsx', 'utf8');

const target = `              <span className="text-sm font-black tracking-tighter text-transparent bg-clip-text bg-gradient-to-r from-cyan-300 to-indigo-300 block drop-shadow-sm">
                Official<span className="text-white">CC</span>Shop
              </span>`;

const replacement = `              <span className="relative text-sm font-black tracking-tighter text-transparent bg-clip-text bg-gradient-to-r from-cyan-300 via-fuchsia-300 to-pink-300 block drop-shadow-[0_0_5px_rgba(236,72,153,0.8)]">
                Official<span className="text-white drop-shadow-[0_0_8px_rgba(255,255,255,0.8)] mx-0.5">CC</span>Shop
              </span>`;

content = content.replace(target, replacement);
fs.writeFileSync('src/components/cards/VirtualCardVisual.tsx', content);
