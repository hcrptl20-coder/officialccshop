const fs = require('fs');
let content = fs.readFileSync('src/App.tsx', 'utf8');

// Change the condition to wrap Cards page in layout even if unauthenticated
// Originally: if (!user && (currentPath === '/register' || currentPath === '/login' || currentPath.startsWith('/forgot-password') || (currentPath !== '/cards' && currentPath !== '/')))
// Let's modify it to only return full-page for login/register/forgot-password, otherwise render in layout
const target = `  if (!user && (currentPath === '/register' || currentPath === '/login' || currentPath.startsWith('/forgot-password') || (currentPath !== '/cards' && currentPath !== '/'))) {`;
const replacement = `  // Allow public views (like /cards) to render inside the main layout\n  if (!user && (currentPath === '/register' || currentPath === '/login' || currentPath.startsWith('/forgot-password'))) {`;
content = content.replace(target, replacement);

fs.writeFileSync('src/App.tsx', content);
