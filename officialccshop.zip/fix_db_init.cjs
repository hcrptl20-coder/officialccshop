const fs = require('fs');
let content = fs.readFileSync('server/db.ts', 'utf8');

// replace 'data.cardCards.push(cardCard);' with 'data.cardCards = data.cardCards || []; data.cardCards.push(cardCard);'
content = content.replace('data.cardCards.push(cardCard);', 'data.cardCards = data.cardCards || []; data.cardCards.push(cardCard);');

// Also do it for any other array that might be missing
fs.writeFileSync('server/db.ts', content);
