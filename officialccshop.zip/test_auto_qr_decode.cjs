const fs = require('fs');
const path = require('path');
const { PNG } = require('pngjs');
const jsQR = require('jsqr');
const jpeg = require('jpeg-js');

function tryDecodeQrFromFile(filePath) {
  try {
    const fileBuf = fs.readFileSync(filePath);
    let rgbaData = null;
    let width = 0;
    let height = 0;

    if (filePath.endsWith('.png')) {
      const png = PNG.sync.read(fileBuf);
      rgbaData = new Uint8ClampedArray(png.data);
      width = png.width;
      height = png.height;
    } else if (filePath.endsWith('.jpg') || filePath.endsWith('.jpeg')) {
      const jpg = jpeg.decode(fileBuf);
      rgbaData = new Uint8ClampedArray(jpg.data);
      width = jpg.width;
      height = jpg.height;
    }

    if (rgbaData && width > 0 && height > 0) {
      const code = jsQR(rgbaData, width, height);
      if (code && code.data) {
        return code.data;
      }
    }
  } catch (err) {
    console.error('QR decode error:', err);
  }
  return null;
}

console.log("Decoder ready");
