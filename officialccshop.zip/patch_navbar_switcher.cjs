const fs = require('fs');
let content = fs.readFileSync('src/components/layout/Navbar.tsx', 'utf8');

const target = `{/* Quick Account / Role Switcher for instant 1-tap switching */}`;
const startIndex = content.indexOf(target);

if (startIndex !== -1) {
  // Find the end of the div containing the switcher
  const endTarget = `</button>\n          </div>`;
  const endIndex = content.indexOf(endTarget, startIndex) + endTarget.length;
  
  if (endIndex !== -1) {
    content = content.substring(0, startIndex) + content.substring(endIndex);
    fs.writeFileSync('src/components/layout/Navbar.tsx', content);
  }
}
