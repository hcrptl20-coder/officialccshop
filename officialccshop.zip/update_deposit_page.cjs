const fs = require('fs');

const file = 'src/pages/user/DepositPage.tsx';
let code = fs.readFileSync(file, 'utf8');

const target = "qrDataUrl={dynamicQrUrl || config.qrImagePath || '/merchant-qr.png'}";
const replacement = "qrDataUrl={(config.useStaticQr && config.staticQrUrl) ? config.staticQrUrl : (dynamicQrUrl || config.qrImagePath || '/merchant-qr.png')}";

if (code.includes(target)) {
  code = code.replace(target, replacement);
  fs.writeFileSync(file, code);
  console.log("Updated DepositPage.tsx QR data URL binding successfully!");
} else {
  console.log("Target not found in DepositPage.tsx");
}
