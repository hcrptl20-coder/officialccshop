const fs = require('fs');

const file = 'src/components/deposit/AirtelUpiQrCard.tsx';
let code = fs.readFileSync(file, 'utf8');

// Replace cleanMerchant with dynamic merchantName
code = code.replace(
  "const cleanMerchant = 'Airtel Payments Bank';",
  "const cleanMerchant = merchantName ? merchantName.replace(/[^a-zA-Z0-9 ]/g, ' ').trim() : 'Official CC Shop';"
);

// Replace the hardcoded PhonePe badge with a conditional check (only if not static QR and is explicitly airtel/phonepe)
const phonePeBadge = `{/* PhonePe Center Badge matching uploaded screenshot */}
        <div className="absolute inset-0 m-auto w-11 h-11 rounded-full bg-[#5f259f] border-[2.5px] border-white flex items-center justify-center shadow-md pointer-events-none">
          <span className="text-white font-bold text-base leading-none select-none font-sans">
            पे
          </span>
        </div>`;

const conditionalPhonePeBadge = `{/* PhonePe Center Badge (only for generated QR, not for custom uploaded QR) */}
        {!qrDataUrl?.includes('/uploads/') && !qrDataUrl?.includes('static') && merchantName?.toLowerCase().includes('airtel') && (
          <div className="absolute inset-0 m-auto w-11 h-11 rounded-full bg-[#5f259f] border-[2.5px] border-white flex items-center justify-center shadow-md pointer-events-none">
            <span className="text-white font-bold text-base leading-none select-none font-sans">
              पे
            </span>
          </div>
        )}`;

if (code.includes(phonePeBadge)) {
  code = code.replace(phonePeBadge, conditionalPhonePeBadge);
  console.log("Replaced phonepe badge with conditional check");
} else {
  console.log("Phonepe badge exact string not found, checking with regex");
  code = code.replace(
    /\{\/\* PhonePe Center Badge matching uploaded screenshot \*\/\}[\s\S]*?<\/div>\s*<\/div>/,
    `${conditionalPhonePeBadge}\n      </div>`
  );
}

// Check header badge
const airtelHeaderBadge = `<div className="w-12 h-12 rounded-full bg-[#d6001c] flex items-center justify-center shadow-lg border-2 border-white/20">
          <span className="text-white font-black text-xl tracking-tighter">₹</span>
        </div>`;

const newHeaderBadge = `<div className={\`w-12 h-12 rounded-full flex items-center justify-center shadow-lg border-2 \${
          merchantName?.toLowerCase().includes('airtel')
            ? 'bg-[#d6001c] border-white/20'
            : 'bg-gradient-to-br from-emerald-500 to-teal-600 border-emerald-400/40'
        }\`}>
          <span className="text-white font-black text-xl tracking-tighter">₹</span>
        </div>`;

if (code.includes(airtelHeaderBadge)) {
  code = code.replace(airtelHeaderBadge, newHeaderBadge);
  console.log("Replaced header badge");
}

fs.writeFileSync(file, code);
console.log("Updated AirtelUpiQrCard.tsx successfully!");
