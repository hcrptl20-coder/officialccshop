#!/bin/bash
awk '
/\{\/\* 1. Direct UPI \*\/\}/ {
    print "                      {/* 1. Direct UPI */}"
    print "                      <a"
    print "                        href={`upi://pay?pa=davidtl@axl&pn=Airtel%20Payments%20Bank&am=${card.priceInr}&cu=INR&tn=OfficialCCShop%20Deposit`}"
    print "                        className=\"p-2 sm:p-2.5 rounded-xl bg-slate-950 border border-white/[0.08] hover:border-purple-500/30 transition-all duration-200 hover:scale-[1.02] active:scale-95 flex flex-col items-center justify-center text-center gap-2 group cursor-pointer\""
    print "                      >"
    print "                         <div className=\"w-9 h-9 rounded-full bg-white border border-white/[0.05] shadow-inner flex items-center justify-center group-hover:scale-110 transition-transform overflow-hidden p-1\">"
    print "                            <img src=\"/assets/upi.svg\" alt=\"UPI\" className=\"w-6 h-6 object-contain\" />"
    print "                         </div>"
    print "                         <span className=\"font-bold text-[9px] sm:text-[10px] text-slate-300 group-hover:text-white transition-colors leading-tight\">Direct UPI</span>"
    print "                      </a>"
    
    # Skip the new block
    getline
    getline
    getline
    getline
    getline
    getline
    getline
    getline
    getline
    getline
    getline
    getline
    getline
    getline
    getline
    getline
    getline
    getline
    getline
    getline
    getline
    getline
    next
}
{ print }
' src/components/cards/CardDetailModal.tsx > reverted.tsx
mv reverted.tsx src/components/cards/CardDetailModal.tsx
