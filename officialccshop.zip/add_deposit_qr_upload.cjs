const fs = require('fs');

const file = 'src/pages/user/DepositPage.tsx';
let code = fs.readFileSync(file, 'utf8');

// 1. Add import useAuth
if (!code.includes("useAuth")) {
  code = code.replace(
    "import React, { useEffect, useState, useRef } from 'react';",
    "import React, { useEffect, useState, useRef } from 'react';\nimport { useAuth } from '../../context/AuthContext.tsx';"
  );
}

// 2. Add states inside DepositPage
const stateTarget = "  const [dynamicQrUrl, setDynamicQrUrl] = useState<string>('');";
const stateAdd = `  const [dynamicQrUrl, setDynamicQrUrl] = useState<string>('');
  const { user } = useAuth();
  const [isQrUploading, setIsQrUploading] = useState(false);
  const [adminQrMessage, setAdminQrMessage] = useState('');

  const handleAdminQrUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setIsQrUploading(true);
    setAdminQrMessage('Uploading & activating QR code...');
    const formData = new FormData();
    formData.append('qrImage', file);
    try {
      const res = await fetch('/api/settings/upload-qr', {
        method: 'POST',
        headers: {
          Authorization: \`Bearer \${localStorage.getItem('zenith_auth_token')}\`,
        },
        body: formData,
      });
      const data = await res.json();
      if (res.ok) {
        setAdminQrMessage(data.message || 'New QR code activated successfully!');
        fetchConfig();
        setTimeout(() => setAdminQrMessage(''), 4000);
      } else {
        setAdminQrMessage(data.error || 'Upload failed');
      }
    } catch {
      setAdminQrMessage('Upload error. Please try again.');
    }
    setIsQrUploading(false);
  };`;

if (!code.includes("handleAdminQrUpload")) {
  code = code.replace(stateTarget, stateAdd);
}

// 3. Add UI below AirtelUpiQrCard
const uiTarget = `qrDataUrl={(config.useStaticQr && config.staticQrUrl) ? config.staticQrUrl : (dynamicQrUrl || config.qrImagePath || '/merchant-qr.png')}
          />
        </div>`;

const uiReplacement = `qrDataUrl={(config.useStaticQr && config.staticQrUrl) ? config.staticQrUrl : (dynamicQrUrl || config.qrImagePath || '/merchant-qr.png')}
          />

          {user?.role === 'admin' && (
            <div className="mt-4 p-4 rounded-2xl bg-gradient-to-r from-purple-950/50 to-slate-900 border border-purple-500/30 text-center space-y-2.5 shadow-xl">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-purple-300 flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-purple-400" />
                  Admin: Replace Payment QR
                </span>
                <span className="text-[10px] bg-purple-500/20 text-purple-300 px-2 py-0.5 rounded-full font-mono">
                  LIVE
                </span>
              </div>
              <p className="text-[11px] text-slate-400 leading-relaxed text-left">
                Replace this payment QR code with your screenshot. Once uploaded, all users will see and pay directly to your QR.
              </p>
              <div className="flex items-center gap-2">
                <label className="flex-1 py-2 px-3 bg-purple-600 hover:bg-purple-500 text-white rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-purple-900/30">
                  <Upload className="w-3.5 h-3.5" />
                  <span>{isQrUploading ? 'Uploading QR...' : 'Upload & Set New QR'}</span>
                  <input
                    type="file"
                    accept="image/*"
                    className="hidden"
                    disabled={isQrUploading}
                    onChange={handleAdminQrUpload}
                  />
                </label>
                <button
                  type="button"
                  onClick={() => onNavigate && onNavigate('/admin/settings')}
                  className="py-2 px-3 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-semibold border border-white/10"
                >
                  Settings
                </button>
              </div>
              {adminQrMessage && (
                <div className="text-xs font-medium text-emerald-400 bg-emerald-950/40 border border-emerald-500/20 py-1.5 px-3 rounded-lg">
                  {adminQrMessage}
                </div>
              )}
            </div>
          )}
        </div>`;

if (code.includes(uiTarget)) {
  code = code.replace(uiTarget, uiReplacement);
  console.log("Added Admin QR upload UI to DepositPage.tsx");
} else {
  console.log("UI target not found in DepositPage.tsx");
}

fs.writeFileSync(file, code);
console.log("Finished updating DepositPage.tsx");
