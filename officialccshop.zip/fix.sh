#!/bin/bash
awk '
/\{\/\* 2. Amazon \*\/\}/ {
    print "                      </div>"
    print "                      {/* 2. Amazon */}"
    next
}
{ print }
' src/components/cards/CardDetailModal.tsx > fixed.tsx
mv fixed.tsx src/components/cards/CardDetailModal.tsx
