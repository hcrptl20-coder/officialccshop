const fs = require('fs');

let content = fs.readFileSync('src/pages/user/DashboardPage.tsx', 'utf8');

const target1 = `className="mt-3 px-3 py-1.5 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 text-xs font-bold transition"
              >
                Browse 100 Premium Cards
              </button>`;

const replacement1 = `className="relative mt-3 px-4 py-2 rounded-xl font-bold text-xs transition-all group border border-white/10 overflow-hidden"
              >
                <div className="absolute inset-0 bg-gradient-to-r from-pink-600 via-purple-600 to-cyan-600 opacity-80 group-hover:opacity-100 transition-opacity"></div>
                <span className="relative flex items-center justify-center gap-1.5 text-white drop-shadow-md">
                  <Sparkles className="w-3.5 h-3.5 text-pink-200" />
                  Browse 1000+ Premium Cards
                </span>
              </button>`;

content = content.replace(target1, replacement1);

// Add Sparkles import if not present
if (!content.includes('Sparkles') && content.includes('lucide-react')) {
  content = content.replace('lucide-react\';', 'Sparkles,\n} from \'lucide-react\';');
}

fs.writeFileSync('src/pages/user/DashboardPage.tsx', content);
