import { OAuth2Client } from 'google-auth-library';
import fs from 'fs';
import path from 'path';
import { db } from './db.ts';
import { auth } from './auth.ts';

const configPath = path.join(process.cwd(), 'firebase-applet-config.json');
let oAuthClientId = '';
try {
  if (fs.existsSync(configPath)) {
    const config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
    oAuthClientId = config.oAuthClientId;
  }
} catch (err) {
  console.error("Could not load Google Client ID");
}

const client = new OAuth2Client(oAuthClientId);

export async function verifyGoogleToken(token: string) {
  if (!oAuthClientId) throw new Error("Google OAuth Client ID is not configured.");
  
  const ticket = await client.verifyIdToken({
      idToken: token,
      audience: oAuthClientId,
  });
  const payload = ticket.getPayload();
  return payload;
}

export const getClientId = () => oAuthClientId;
