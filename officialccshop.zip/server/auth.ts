import crypto from 'crypto';
import bcrypt from 'bcryptjs';
import { Request, Response, NextFunction } from 'express';
import { db, StoredUser } from './db.ts';

const SESSION_COOKIE_NAME = 'zenith_session';
const CSRF_HEADER_NAME = 'x-csrf-token';

// In-memory rate limiting map: ip -> { count: number, resetAt: number }
const loginRateLimit = new Map<string, { count: number; resetAt: number }>();
const MAX_LOGIN_ATTEMPTS = 6;
const WINDOW_MS = 15 * 60 * 1000; // 15 minutes

// In-memory password reset tokens: token -> { email: string, expiresAt: number }
export const resetTokens = new Map<string, { email: string; expiresAt: number }>();

export interface AuthenticatedRequest extends Request {
  user?: StoredUser;
  sessionToken?: string;
  csrfToken?: string;
}

export const auth = {
  hashPassword(password: string): string {
    return bcrypt.hashSync(password, 10);
  },

  verifyPassword(password: string, hash: string): boolean {
    return bcrypt.compareSync(password, hash);
  },

  generateToken(): string {
    return crypto.randomBytes(32).toString('hex');
  },

  generateCsrfToken(): string {
    return crypto.randomBytes(24).toString('hex');
  },

  checkLoginRateLimit(ip: string): { allowed: boolean; waitSeconds?: number } {
    const now = Date.now();
    const record = loginRateLimit.get(ip);
    if (!record) {
      loginRateLimit.set(ip, { count: 1, resetAt: now + WINDOW_MS });
      return { allowed: true };
    }

    if (now > record.resetAt) {
      loginRateLimit.set(ip, { count: 1, resetAt: now + WINDOW_MS });
      return { allowed: true };
    }

    if (record.count >= MAX_LOGIN_ATTEMPTS) {
      const waitSeconds = Math.ceil((record.resetAt - now) / 1000);
      return { allowed: false, waitSeconds };
    }

    record.count += 1;
    return { allowed: true };
  },

  resetLoginRateLimit(ip: string) {
    loginRateLimit.delete(ip);
  },

  createPasswordResetToken(email: string): string {
    const token = crypto.randomBytes(24).toString('hex');
    resetTokens.set(token, {
      email: email.toLowerCase().trim(),
      expiresAt: Date.now() + 60 * 60 * 1000, // 1 hour
    });
    return token;
  },

  verifyPasswordResetToken(token: string): string | null {
    const record = resetTokens.get(token);
    if (!record) return null;
    if (Date.now() > record.expiresAt) {
      resetTokens.delete(token);
      return null;
    }
    return record.email;
  },

  consumePasswordResetToken(token: string) {
    resetTokens.delete(token);
  },

  setSessionCookie(res: Response, token: string) {
    res.cookie(SESSION_COOKIE_NAME, token, {
      httpOnly: true,
      secure: true,
      sameSite: 'none',
      maxAge: 7 * 24 * 60 * 60 * 1000, // 7 days
      path: '/',
    });
  },

  clearSessionCookie(res: Response) {
    res.clearCookie(SESSION_COOKIE_NAME, {
      httpOnly: true,
      secure: true,
      sameSite: 'none',
      path: '/',
    });
  },
};

// Middleware: extract session and user
export function sessionMiddleware(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  // Extract token from Authorization header first (immune to iframe cookie blocks), then cookie
  let token = '';
  if (req.headers.authorization?.startsWith('Bearer ')) {
    token = req.headers.authorization.split(' ')[1];
  }
  if (!token) {
    token = req.cookies?.[SESSION_COOKIE_NAME];
  }

  if (token) {
    const session = db.findSession(token);
    if (session) {
      const user = db.findUserById(session.userId);
      if (user && user.status === 'active') {
        req.user = user;
        req.sessionToken = token;
      } else if (user && user.status === 'suspended') {
        // user was suspended
        db.deleteSession(token);
      }
    }
  }

  next();
}

// Middleware: Require authenticated user
export function requireAuth(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  if (!req.user) {
    return res.status(401).json({ error: 'Authentication required. Please sign in.' });
  }
  next();
}

// Middleware: Require Admin role
export function requireAdmin(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  if (!req.user) {
    return res.status(401).json({ error: 'Authentication required.' });
  }
  if (req.user.role !== 'admin') {
    return res.status(403).json({ error: 'Forbidden: Administrator privileges required.' });
  }
  next();
}

// Middleware: CSRF protection for mutating requests
export function csrfProtection(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  // Safe methods pass through
  if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) {
    return next();
  }

  // Exempt auth bootstrap endpoints (login/register/forgot-password)
  const openPaths = [
    '/api/auth/login',
    '/api/auth/admin-login',
    '/api/auth/register',
    '/api/auth/forgot-password',
    '/api/auth/reset-password',
    '/api/auth/demo-login',
    '/api/auth/one-click-login',
  ];
  if (openPaths.includes(req.path)) {
    return next();
  }

  const headerCsrf = req.headers[CSRF_HEADER_NAME] || req.headers['x-csrf-token'];
  const cookieCsrf = req.cookies?.['zenith_csrf'];

  // If token is sent and matches cookie or is present for authenticated session
  if (!headerCsrf || (cookieCsrf && headerCsrf !== cookieCsrf)) {
    // Note: relaxed check if bearer token is used, but validate presence
    if (!req.headers.authorization && !headerCsrf) {
      return res.status(403).json({ error: 'Invalid or missing CSRF security token.' });
    }
  }

  next();
}
