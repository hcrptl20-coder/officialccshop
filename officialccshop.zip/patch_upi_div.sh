#!/bin/bash
sed -i 's|<div className="w-9 h-9 rounded-xl bg-gradient-to-br from-purple-500 to-indigo-600 flex items-center justify-center shadow-md p-1.5 text-white border border-white/20">|<div className="w-9 h-9 rounded-xl bg-white flex items-center justify-center shadow-md p-1 border border-white/20">|g' src/components/deposit/UpiAppLaunchers.tsx
sed -i 's|<img src="/assets/upi.svg" alt="UPI" className="w-6 h-6 object-contain filter invert opacity-90" />|<img src="/assets/upi.svg" alt="UPI" className="w-6 h-6 object-contain" />|g' src/components/deposit/UpiAppLaunchers.tsx
