#!/bin/bash
sed -i '727d' src/components/cards/CardDetailModal.tsx
