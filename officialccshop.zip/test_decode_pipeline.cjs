const { PNG } = require('pngjs');
const jsQR = require('jsqr');
const QRCode = require('qrcode');
const fs = require('fs');

async function run() {
  const buf = await QRCode.toBuffer('upi://pay?pa=hcrptl@okaxis&pn=HCR%20Shop&cu=INR');
  const png = PNG.sync.read(buf);
  const code = jsQR(new Uint8ClampedArray(png.data), png.width, png.height);
  console.log('Decoded text:', code ? code.data : 'FAILED');
}
run();
