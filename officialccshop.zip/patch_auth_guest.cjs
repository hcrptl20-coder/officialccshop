const fs = require('fs');
let content = fs.readFileSync('src/context/AuthContext.tsx', 'utf8');

const targetAutoLogin = `      } else {
        setUser(null);
      }`;

const replacementAutoLogin = `      } else {
        // Auto-authenticate as a unique guest account so there is zero verification/login barrier
        // This ensures every user gets their own isolated environment automatically!
        const auto = await apiRequest<{ user: User; token: string }>('/api/auth/guest-login', {
          method: 'POST',
        });
        if (auto.ok && auto.data?.user) {
          if (typeof window !== 'undefined' && auto.data.token) {
            localStorage.setItem('zenith_auth_token', auto.data.token);
          }
          setUser(auto.data.user);
        } else {
          setUser(null);
        }
      }`;

content = content.replace(targetAutoLogin, replacementAutoLogin);

fs.writeFileSync('src/context/AuthContext.tsx', content);
