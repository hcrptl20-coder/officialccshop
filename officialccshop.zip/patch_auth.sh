#!/bin/bash
sed -i 's/const user = db.getUserBySession(token);/const session = db.findSession(token);\n  const user = session ? db.findUserById(session.userId) : null;/g' server.ts
