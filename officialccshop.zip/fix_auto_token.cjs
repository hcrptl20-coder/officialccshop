const fs = require('fs');
let content = fs.readFileSync('server.ts', 'utf8');

content = content.replace(
  "      auth.setSessionCookie(res, token);\n      activeUser = defaultUser;",
  "      auth.setSessionCookie(res, token);\n      req.sessionToken = token;\n      activeUser = defaultUser;"
);

fs.writeFileSync('server.ts', content);
